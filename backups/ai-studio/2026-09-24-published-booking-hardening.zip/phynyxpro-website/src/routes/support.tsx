import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { useState } from "react";
import { AlertCircle, Send, HelpCircle, RotateCcw } from "lucide-react";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "Contact PhynyxPro | Support" },
      {
        name: "description",
        content:
          "Send a question about PhynyxPro or your PYRO account. This is not an emergency or guaranteed-response channel.",
      },
      { property: "og:title", content: "Contact PhynyxPro | Support" },
      {
        property: "og:description",
        content:
          "Send a question about PhynyxPro or your PYRO account. This is not an emergency or guaranteed-response channel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SupportPage,
});

function SupportPage() {
  // Visual draft only — NO backend, NO submission, NO workflow, NO message sent.
  // Preserve entered fields; show an honest unavailable state rather than fake success.
  const [website, setWebsite] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "attempting" | "unavailable">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // No server function exists in this draft. Show unavailable/retry, never "recorded".
    setStatus("attempting");
    window.setTimeout(() => setStatus("unavailable"), 600);
  };

  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px] pb-20">
        <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
          {/* Centered intro with simple question icon */}
          <div className="max-w-[640px] mx-auto text-center mb-10">
            <div className="w-12 h-12 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto mb-5">
              <HelpCircle className="w-6 h-6" />
            </div>
            <h1 className="text-[34px] sm:text-[42px] lg:text-[52px] font-bold tracking-tight text-ink leading-[1.1]">
              Contact PhynyxPro
            </h1>
            <p className="mt-5 text-base text-warm leading-relaxed">
              Send a question about PhynyxPro or your PYRO account. This is not an emergency or
              guaranteed-response channel.
            </p>
            <p className="mt-3 text-sm text-warm/80 leading-relaxed">
              Current clients with an urgent operational issue should use the contact route listed
              in their signed client agreement.
            </p>
          </div>

          {/* White stacked inquiry form */}
          <div className="max-w-[560px] mx-auto bg-white p-8 rounded-2xl border border-black/10 shadow-lg">
            {/* Honest unavailable banner — no fake "Inquiry Recorded" success */}
            {status === "unavailable" && (
              <div className="mb-6 rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-bold text-ink">Inquiry submission is not available</p>
                  <p className="text-[12px] text-warm mt-1 leading-relaxed">
                    This draft has no connected submission backend or support workflow. Your inquiry
                    was not recorded, saved, or sent. Your entered fields are preserved below so you
                    can copy them or retry once a backend is connected.
                  </p>
                  <button
                    type="button"
                    onClick={() => setStatus("idle")}
                    className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Retry
                  </button>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Hidden honeypot — never shown to visitors; stays empty. Real inquiries are
                  never silently discarded in this draft because no submission occurs at all. */}
              <input
                type="text"
                name="website"
                tabIndex={-1}
                autoComplete="off"
                aria-hidden="true"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="absolute opacity-0 pointer-events-none -z-10 h-0 w-0"
              />

              <div>
                <label
                  htmlFor="support-name"
                  className="block text-xs font-semibold text-ink mb-1.5"
                >
                  Name *
                </label>
                <input
                  id="support-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm bg-ivory/40 focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix"
                />
              </div>
              <div>
                <label
                  htmlFor="support-email"
                  className="block text-xs font-semibold text-ink mb-1.5"
                >
                  Email *
                </label>
                <input
                  id="support-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm bg-ivory/40 focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix"
                />
              </div>
              <div>
                <label
                  htmlFor="support-subject"
                  className="block text-xs font-semibold text-ink mb-1.5"
                >
                  Subject
                </label>
                <input
                  id="support-subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm bg-ivory/40 focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix"
                />
              </div>
              <div>
                <label
                  htmlFor="support-message"
                  className="block text-xs font-semibold text-ink mb-1.5"
                >
                  Message *
                </label>
                <textarea
                  id="support-message"
                  rows={5}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm bg-ivory/40 resize-none focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix"
                ></textarea>
              </div>
              <button
                type="submit"
                disabled={status === "attempting"}
                className="w-full py-3.5 bg-phoenix hover:bg-ember disabled:opacity-60 text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {status === "attempting" ? "Sending…" : "Submit Inquiry"}
                {status !== "attempting" && <Send className="w-4 h-4" />}
              </button>
            </form>

            <p className="mt-6 text-xs text-warm/80 leading-relaxed">
              This is an unpublished draft: no submission backend or support workflow is connected,
              so submitting this form does not record, save, or send your inquiry, does not record
              marketing consent, and does not guarantee a response. Your information is handled
              according to our{" "}
              <Link to="/privacy-policy" className="text-phoenix font-semibold hover:underline">
                Privacy Policy
              </Link>
              .
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

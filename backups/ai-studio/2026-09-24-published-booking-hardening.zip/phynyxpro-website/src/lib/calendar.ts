/**
 * Calendar availability + booking helpers for the /schedule Growth Call flow.
 *
 * Connects the custom Phynyx slot-picker UI to the existing 30-minute
 * round-robin calendar "Phynyx Website - Assessment" (NX2pJFAx51yOcaNIdNjL)
 * behind the branded UI — no iframe, no stock calendar widget.
 */

const BOOKING_API_URL = "https://backend.leadconnectorhq.com";
const VIBE_API_URL = "https://backend.leadconnectorhq.com/vibe-ai";

// Existing verified active calendar for this location.
export const CALENDAR_ID = "NX2pJFAx51yOcaNIdNjL";
export const LOCATION_ID = "DsRnzA2tcoiwklSgjBtR";

// Registered custom-field IDs (non-standard submitted values).
// Unified with the Growth Snapshot intake: appointment-text consent and CTA
// source use the SAME field IDs and value vocabulary across both surfaces.
// appointmentTextConsent: Consented / Not consented (not Yes/No).
// ctaSource: the validated attribution token string.
export const CUSTOM_FIELDS = {
  appointmentTextConsent: "xNnkLEk8FCUI7XSbeElK",
  ctaSource: "CVSuXDCFaJslF3bIuRvI",
} as const;

export type CustomFieldValue = { id: string; field_value: string };

export type BookingPayload = {
  locationId: string;
  calendarId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  selectedSlot: string;
  selectedTimezone?: string;
  /**
   * Stable booking-attempt/session key. The caller owns this value and must
   * reuse it across retries so the provider can deduplicate attempts.
   * It is NOT generated here — the caller supplies it.
   */
  sessionId: string;
  customFields?: CustomFieldValue[];
} & Partial<
  Record<
    | "notes"
    | "address1"
    | "city"
    | "state"
    | "postalCode"
    | "country"
    | "companyName"
    | "website"
    | "gender"
    | "dateOfBirth"
    | "timezone",
    string
  >
>;

export const getBrowserTimezone = () => Intl.DateTimeFormat().resolvedOptions().timeZone;

/** Clamp an availability range to today-or-later and a 31-day max window. */
export const clampAvailabilityRange = (startMs: number, endMs: number) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const startDate = Math.max(startMs, today.getTime());
  const maxEndDate = startDate + 31 * 24 * 60 * 60 * 1000;
  const endDate = Math.min(Math.max(endMs, startDate), maxEndDate);

  return { startDate, endDate };
};

/**
 * Raw free-slots response keyed by date string, each containing slot ISO strings.
 * e.g. { "2026-09-22": { slots: ["2026-09-22T15:30:00-07:00"] } }
 */
export type FreeSlotsResponse = Record<string, { slots: string[] }>;

export const fetchCalendarFreeSlots = async (
  calendarId: string,
  startMs: number,
  endMs: number,
): Promise<FreeSlotsResponse> => {
  const { startDate, endDate } = clampAvailabilityRange(startMs, endMs);
  const params = new URLSearchParams({
    startDate: String(startDate),
    endDate: String(endDate),
    timezone: getBrowserTimezone(),
  });

  const response = await fetch(`${BOOKING_API_URL}/calendars/${calendarId}/free-slots?${params}`);
  if (!response.ok) {
    throw new Error("Failed to fetch calendar availability");
  }
  return response.json() as Promise<FreeSlotsResponse>;
};

/**
 * Flatten a free-slots response into a Set of exact ISO slot strings, for
 * fast "is this slot still open?" membership checks at commit time.
 */
export const slotsToSet = (slots: FreeSlotsResponse): Set<string> => {
  const out = new Set<string>();
  for (const day of Object.values(slots)) {
    for (const iso of day?.slots ?? []) out.add(iso);
  }
  return out;
};

export type BookingResult =
  | { ok: true; appointmentId: string; bookedStart: string }
  | { ok: false; reason: "unavailable" | "error"; message: string };

/**
 * Submit a booking. A success result is returned ONLY when the provider
 * returns HTTP 2xx AND a non-empty appointment ID AND a confirmed booked
 * start time. We never fabricate an appointment ID (no random UUID fallback)
 * after a 2xx — a missing provider ID is treated as a hard error.
 *
 * NOTE on idempotency: the booking endpoint does not document server-side
 * idempotency guarantees. The stable `sessionId` is sent on every attempt,
 * but we cannot assert the provider deduplicates by it. Treat each POST as
 * a distinct booking attempt unless the provider confirms otherwise.
 */
export const submitCalendarBooking = async (payload: BookingPayload): Promise<BookingResult> => {
  if (!payload.sessionId) {
    return {
      ok: false,
      reason: "error",
      message: "Missing booking session identifier. Please try again.",
    };
  }

  try {
    const response = await fetch(`${VIBE_API_URL}/booking/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        selectedTimezone: payload.selectedTimezone ?? getBrowserTimezone(),
        // sessionId is required and caller-managed (no random generation here).
        sessionId: payload.sessionId,
        customFields: payload.customFields ?? [],
      }),
    });

    if (!response.ok) {
      // 409 / conflict-style failures usually mean the slot was taken.
      const reason = response.status === 409 ? "unavailable" : "error";
      return {
        ok: false,
        reason,
        message:
          reason === "unavailable"
            ? "That time was just taken. Please choose another slot."
            : "Booking submission failed. Please try again.",
      };
    }

    const data = (await response.json()) as {
      appointmentId?: string;
      bookedStart?: string;
      start?: string;
      startTime?: string;
      id?: string;
    };

    // Require a NON-EMPTY provider appointment ID. Never fabricate one.
    const appointmentId = (data.appointmentId ?? data.id ?? "").trim();
    const bookedStart = (data.bookedStart ?? data.start ?? data.startTime ?? "").trim();

    if (!appointmentId || !bookedStart) {
      // Provider returned 2xx but did not confirm an appointment ID and a
      // booked start time — treat as a failure. No success UI is shown.
      return {
        ok: false,
        reason: "error",
        message: "The calendar could not confirm a booked appointment. Please try another slot.",
      };
    }

    return { ok: true, appointmentId, bookedStart };
  } catch {
    return {
      ok: false,
      reason: "error",
      message: "We couldn't reach the booking service. Please try again.",
    };
  }
};

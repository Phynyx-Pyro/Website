/**
 * Calendar availability + booking helpers for the /schedule Growth Call flow.
 *
 * Connects the custom Phynyx slot-picker UI to the existing 30-minute
 * round-robin calendar "Phynyx Website - Assessment" (NX2pJFAx51yOcaNIdNjL)
 * behind the branded UI — no iframe, no stock calendar widget.
 */

const BOOKING_API_URL = "https://backend.leadconnectorhq.com";
const VIBE_API_URL = "https://backend.leadconnectorhq.com/vibe-ai";

// Existing verified active calendar for this location.
export const CALENDAR_ID = "NX2pJFAx51yOcaNIdNjL";
export const LOCATION_ID = "DsRnzA2tcoiwklSgjBtR";

// Registered custom-field IDs (non-standard submitted values).
// Unified with the Growth Snapshot intake: appointment-text consent and CTA
// source use the SAME field IDs and value vocabulary across both surfaces.
// appointmentTextConsent: Consented / Not consented (not Yes/No).
// ctaSource: the validated attribution token string.
export const CUSTOM_FIELDS = {
  appointmentTextConsent: "xNnkLEk8FCUI7XSbeElK",
  ctaSource: "CVSuXDCFaJslF3bIuRvI",
} as const;

export type CustomFieldValue = { id: string; field_value: string };

export type BookingPayload = {
  locationId: string;
  calendarId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  selectedSlot: string;
  selectedTimezone?: string;
  /**
   * Stable booking-attempt/session key. The caller owns this value and must
   * reuse it across retries so the provider can deduplicate attempts.
   * It is NOT generated here — the caller supplies it.
   */
  sessionId: string;
  customFields?: CustomFieldValue[];
} & Partial<
  Record<
    | "notes"
    | "address1"
    | "city"
    | "state"
    | "postalCode"
    | "country"
    | "companyName"
    | "website"
    | "gender"
    | "dateOfBirth"
    | "timezone",
    string
  >
>;

export const getBrowserTimezone = () => Intl.DateTimeFormat().resolvedOptions().timeZone;

/** Clamp an availability range to today-or-later and a 31-day max window. */
export const clampAvailabilityRange = (startMs: number, endMs: number) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const startDate = Math.max(startMs, today.getTime());
  const maxEndDate = startDate + 31 * 24 * 60 * 60 * 1000;
  const endDate = Math.min(Math.max(endMs, startDate), maxEndDate);

  return { startDate, endDate };
};

/**
 * Raw free-slots response keyed by date string, each containing slot ISO strings.
 * e.g. { "2026-09-22": { slots: ["2026-09-22T15:30:00-07:00"] } }
 */
export type FreeSlotsResponse = Record<string, { slots: string[] }>;

export const fetchCalendarFreeSlots = async (
  calendarId: string,
  startMs: number,
  endMs: number,
): Promise<FreeSlotsResponse> => {
  const { startDate, endDate } = clampAvailabilityRange(startMs, endMs);
  const params = new URLSearchParams({
    startDate: String(startDate),
    endDate: String(endDate),
    timezone: getBrowserTimezone(),
  });

  const response = await fetch(`${BOOKING_API_URL}/calendars/${calendarId}/free-slots?${params}`);
  if (!response.ok) {
    throw new Error("Failed to fetch calendar availability");
  }
  return response.json() as Promise<FreeSlotsResponse>;
};

/**
 * Flatten a free-slots response into a Set of exact ISO slot strings, for
 * fast "is this slot still open?" membership checks at commit time.
 *
 * Defensive: a malformed/null response (e.g. `null`, `[]`, or a payload whose
 * values lack a `slots` array) yields an EMPTY set rather than throwing, so a
 * preflight availability recheck that decoded to bad JSON degrades to a safe
 * "slot no longer open" / retryable outcome instead of an uncaught throw.
 */
export const slotsToSet = (slots: FreeSlotsResponse | null | undefined): Set<string> => {
  const out = new Set<string>();
  if (!slots || typeof slots !== "object") return out;
  for (const day of Object.values(slots)) {
    if (!day || !Array.isArray(day.slots)) continue;
    for (const iso of day.slots) {
      if (typeof iso === "string") out.add(iso);
    }
  }
  return out;
};

export type BookingResult =
  // Fully confirmed: provider returned 2xx with a non-empty STRING appointment
  // ID AND a booked start time whose parsed instant EQUALS the instant of the
  // caller's selectedSlot. Safe to show "You're on the calendar".
  | { ok: true; status: "confirmed"; appointmentId: string; bookedStart: string }
  // Accepted but unverified: provider returned 2xx but did NOT include a valid
  // matching appointment ID + booked start. The request was likely received
  // and an appointment may have been created, but we cannot confirm it from
  // the response. Do NOT fabricate an ID, do NOT retry / re-submit.
  | { ok: true; status: "accepted-unverified" }
  // Slot conflict (409): retryable. The selected slot was taken.
  | { ok: false; reason: "unavailable"; message: string }
  // Ambiguous failure AFTER the POST (network error or 5xx). An appointment
  // may or may not have been created — do NOT encourage immediate retry.
  | { ok: false; reason: "uncertain"; message: string }
  // Hard error BEFORE the POST (e.g. missing session id, or a pre-POST
  // availability recheck failed). Retryable — no appointment was submitted.
  | { ok: false; reason: "error"; message: string };

/**
 * Parse a value to a finite epoch-ms instant, or null if it is not a valid
 * UNAMBIGUOUS instant. A string WITHOUT an explicit timezone designator
 * (a trailing `Z` or a numeric `±HH:MM` offset) is NOT an unambiguous
 * instant — `new Date()` would parse it in the runtime's local zone, which
 * is environment-dependent. Such strings must NEVER qualify as a confirmed
 * booking start; they fall back to accepted-unverified.
 */
function toInstantMs(v: string | undefined | null): number | null {
  if (typeof v !== "string") return null;
  const t = v.trim();
  if (t === "") return null;
  // Require an explicit timezone designator: a trailing "Z", or a numeric
  // ±HH:MM offset somewhere in the string.
  const hasZ = /Z$/i.test(t);
  const hasOffset = /[+-]\d{2}:\d{2}$/.test(t);
  if (!hasZ && !hasOffset) return null;
  const d = new Date(t);
  const ms = d.getTime();
  if (!Number.isFinite(ms)) return null;
  return ms;
}

/**
 * A confirmed result is returned ONLY when ALL of the following hold:
 *  - the provider returns HTTP 2xx;
 *  - the response carries a NON-EMPTY STRING appointment ID (not a guess from
 *    a nested/envelope shape);
 *  - the response carries a booked start time that parses to a valid instant
 *    AND that instant EQUALS the instant of `payload.selectedSlot`.
 *
 * Missing, malformed, or mismatched confirmation fields return
 * accepted-unverified — never a false confirmation. We never fabricate an
 * appointment ID (no random UUID fallback) after a 2xx.
 *
 * NOTE on idempotency: the booking endpoint does not document server-side
 * idempotency guarantees. The stable `sessionId` is sent on every attempt,
 * but we cannot assert the provider deduplicates by it. Treat each POST as
 * a distinct booking attempt unless the provider confirms otherwise.
 */
export const submitCalendarBooking = async (payload: BookingPayload): Promise<BookingResult> => {
  if (!payload.sessionId) {
    // Hard error BEFORE the POST — safe to retry.
    return {
      ok: false,
      reason: "error",
      message: "Missing booking session identifier. Please try again.",
    };
  }

  const selectedSlotMs = toInstantMs(payload.selectedSlot);

  try {
    const response = await fetch(`${VIBE_API_URL}/booking/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        selectedTimezone: payload.selectedTimezone ?? getBrowserTimezone(),
        // sessionId is required and caller-managed (no random generation here).
        sessionId: payload.sessionId,
        customFields: payload.customFields ?? [],
      }),
    });

    if (!response.ok) {
      if (response.status === 409) {
        // Slot conflict — retryable; the selected slot was just taken.
        return {
          ok: false,
          reason: "unavailable",
          message: "That time was just taken. Please choose another slot.",
        };
      }
      // Any other non-2xx AFTER the POST is ambiguous: an appointment may or
      // may not have been created. Do NOT encourage an immediate retry.
      return {
        ok: false,
        reason: "uncertain",
        message:
          "We sent your booking request but could not confirm it. Please check your email for a confirmation or contact us before trying again.",
      };
    }

    // 2xx — parse the provider response. A valid JSON body that is NOT a
    // flat object (e.g. literal `null` or an array) cannot carry
    // confirmation fields and must NOT throw into the network-uncertain
    // path. Coerce it to `{}` so it falls through to accepted-unverified.
    const raw = await response.json().catch(() => ({}));
    const data = (raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}) as {
      appointmentId?: string;
      bookedStart?: string;
      start?: string;
      startTime?: string;
      id?: string;
    };

    // Require a NON-EMPTY STRING appointment ID. Coerce nothing; if the
    // field is present but not a string, treat it as missing.
    const rawId = data.appointmentId ?? data.id;
    const appointmentId = typeof rawId === "string" ? rawId.trim() : "";
    const rawStart = data.bookedStart ?? data.start ?? data.startTime;
    const bookedStart = typeof rawStart === "string" ? rawStart.trim() : "";

    if (!appointmentId || !bookedStart) {
      // 2xx but the confirmation fields were missing from the response.
      return { ok: true, status: "accepted-unverified" };
    }

    // The booked start must parse to a valid instant AND that instant must
    // EQUAL the instant of the caller's selectedSlot. A mismatched, malformed,
    // or off-by-one start is NOT a confirmation — fall back to accepted-unverified.
    const bookedStartMs = toInstantMs(bookedStart);
    if (bookedStartMs === null || selectedSlotMs === null || bookedStartMs !== selectedSlotMs) {
      return { ok: true, status: "accepted-unverified" };
    }

    return { ok: true, status: "confirmed", appointmentId, bookedStart };
  } catch {
    // Network failure AFTER the POST: ambiguous. An appointment may have been
    // created server-side even though we never received the response. Do NOT
    // encourage an immediate retry.
    return {
      ok: false,
      reason: "uncertain",
      message:
        "We couldn't reach the booking service after sending your request. Your appointment may have been created — please check your email or contact us before trying again.",
    };
  }
};

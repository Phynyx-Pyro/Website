import { describe, it, expect, vi, beforeEach } from "vitest";
import { submitCalendarBooking } from "../src/lib/calendar";

let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  fetchMock = vi.fn();
  global.fetch = fetchMock as unknown as typeof global.fetch;
});

const SELECTED_SLOT = "2026-09-25T09:30:00-07:00";
const basePayload = {
  locationId: "DsRnzA2tcoiwklSgjBtR",
  calendarId: "NX2pJFAx51yOcaNIdNjL",
  firstName: "Jane",
  lastName: "Doe",
  email: "jane@test.com",
  phone: "5551234567",
  selectedSlot: SELECTED_SLOT,
  sessionId: "stable-session-1",
};

describe("submitCalendarBooking — explicit confirmed 2xx", () => {
  it("2xx with appointmentId + bookedStart matching selectedSlot => confirmed", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_123", bookedStart: SELECTED_SLOT }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("confirmed");
    }
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_123");
      expect(result.bookedStart).toBe(SELECTED_SLOT);
    }
  });

  it("2xx with id + start aliases matching selectedSlot instant => confirmed", async () => {
    // Same instant, different string representation (offset spelling).
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ id: "apt_456", start: "2026-09-25T10:30:00-06:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_456");
      expect(result.bookedStart).toBe("2026-09-25T10:30:00-06:00");
    }
  });

  it("2xx with startTime alias matching selectedSlot instant => confirmed", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_007", startTime: SELECTED_SLOT }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_007");
    }
  });
});

describe("submitCalendarBooking — 2xx mismatched start => accepted-unverified", () => {
  it("2xx with bookedStart NOT matching selectedSlot instant => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_810", bookedStart: "2026-09-26T09:30:00-07:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with bookedStart in a different timezone still mismatched => accepted-unverified", async () => {
    // 2026-09-25T10:00:00-07:00 != 2026-09-25T09:30:00-07:00
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_811", bookedStart: "2026-09-25T10:00:00-07:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });
});

describe("submitCalendarBooking — 2xx missing fields", () => {
  it("2xx with no appointment fields => accepted-unverified (NOT error)", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({}),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with appointmentId but no bookedStart => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_789" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with bookedStart but no id => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ bookedStart: SELECTED_SLOT }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with empty-string fields => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "", bookedStart: "  " }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with non-string id => accepted-unverified (no envelope guessing)", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: { nested: "apt_900" }, bookedStart: SELECTED_SLOT }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with unparseable bookedStart => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_900", bookedStart: "not-a-date" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with unparseable JSON => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => {
        throw new SyntaxError("bad json");
      },
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });
});

describe("submitCalendarBooking — 409 slot conflict", () => {
  it("409 => unavailable (retryable)", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 409 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("unavailable");
      expect(result.message).toContain("taken");
    }
  });
});

describe("submitCalendarBooking — ambiguous / uncertain failure", () => {
  it("500 after POST => uncertain (no immediate retry)", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 500 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
      expect(result.message).toContain("check your email");
    }
  });

  it("502 after POST => uncertain", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 502 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
    }
  });

  it("network error after POST => uncertain (appointment may exist)", async () => {
    fetchMock.mockRejectedValue(new Error("network timeout"));
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
      expect(result.message).toContain("check your email");
    }
  });
});

describe("submitCalendarBooking — hard pre-POST error", () => {
  it("missing sessionId => error (retryable)", async () => {
    const result = await submitCalendarBooking({ ...basePayload, sessionId: "" });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("error");
      expect(result.message).toContain("session");
    }
    // Should not have attempted a fetch.
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("confirmed result requires a matching booked start; mismatch is not confirmed", async () => {
    // Same instant, different offset — should match.
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_match", bookedStart: "2026-09-25T16:30:00+00:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("confirmed");
    }
  });
});

describe("submitCalendarBooking — offsetless (ambiguous) date strings", () => {
  it("2xx with offsetless bookedStart => accepted-unverified (not confirmed)", async () => {
    // No Z and no numeric offset — local-zone dependent, not an unambiguous instant.
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_off1", bookedStart: "2026-09-25T09:30:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with offsetless selectedSlot + offsetless bookedStart => accepted-unverified", async () => {
    // Both offsetless: toInstantMs returns null for each → not confirmed.
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_off2", bookedStart: "2026-09-25T09:30:00" }),
    });
    const result = await submitCalendarBooking({ ...basePayload, selectedSlot: "2026-09-25T09:30:00" });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with valid Z bookedStart matching selectedSlot => confirmed", async () => {
    // selectedSlot is -07:00 (16:30:00Z); bookedStart is the same instant in Z.
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_z", bookedStart: "2026-09-25T16:30:00Z" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_z");
    }
  });

  it("2xx with valid numeric-offset bookedStart matching selectedSlot => confirmed", async () => {
    // Same instant expressed as +00:00.
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_off_ok", bookedStart: "2026-09-25T16:30:00+00:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("confirmed");
    }
  });
});

describe("submitCalendarBooking — 2xx non-object JSON body", () => {
  it("2xx with literal null JSON body => accepted-unverified (not uncertain)", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => null,
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with array JSON body => accepted-unverified (not uncertain)", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ["unexpected", "array"],
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with number JSON body => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => 42,
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });
});

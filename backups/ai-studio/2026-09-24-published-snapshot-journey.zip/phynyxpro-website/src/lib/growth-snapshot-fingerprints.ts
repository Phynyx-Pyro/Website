// Deterministic fingerprints for deduplicating successful Growth Snapshot
// submissions (intake + completion). Each is computed only from the relevant
// submitted fields and is case-insensitive/trim-tolerant for identity.
//
// Attribution-only `ctaSource` is EXCLUDED from both fingerprints so that
// entering the same saved journey via a different CTA does not trigger a
// duplicate POST. The CTA source is still sent in the actual tracking event.
//
// Intake fields are serialized with JSON.stringify(array) (not join("|")) so
// delimiter-containing data cannot collide.
//
// These fingerprints are recorded ONLY after a real 2xx, persisted to
// sessionStorage, and compared on the next submit: if the current payload
// matches the last successful fingerprint, no duplicate POST is fired. A
// failed/unknown request is NEVER treated as success, and this module does
// not imply server-side idempotency.

import type { FunnelMetric } from "./growth-snapshot-calc";

/**
 * Fingerprint of the INTAKE contact payload: five identity fields and all
 * three consent booleans. ctaSource is intentionally excluded. Serialized
 * with JSON.stringify(array) for delimiter safety.
 */
export function intakeFingerprint(d: {
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  appointmentTexts: boolean;
  marketingTexts: boolean;
  aiPhoneCalls: boolean;
}): string {
  return JSON.stringify([
    d.businessName.trim().toLowerCase(),
    d.firstName.trim().toLowerCase(),
    d.lastName.trim().toLowerCase(),
    d.email.trim().toLowerCase(),
    d.phone.trim(),
    d.appointmentTexts,
    d.marketingTexts,
    d.aiPhoneCalls,
  ]);
}

/**
 * Fingerprint of the COMPLETION payload: identity, business context, free-check
 * numbers, all eight funnel metrics (with quality), and industry. ctaSource is
 * intentionally excluded. Excludes the timestamp so an unchanged snapshot
 * matches after reload.
 */
export function completionFingerprint(d: {
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  practiceName: string;
  role: string;
  locations: string;
  adSpend: string;
  avgStartValue: string;
  industry: string;
  leads: string;
  booked: string;
  showed: string;
  mInquiries: FunnelMetric;
  mContacted: FunnelMetric;
  mBooked: FunnelMetric;
  mConfirmed: FunnelMetric;
  mShowed: FunnelMetric;
  mStarted: FunnelMetric;
  mAdSpend: FunnelMetric;
  mAvgStartValue: FunnelMetric;
}): string {
  return JSON.stringify({
    i: [d.businessName, d.firstName, d.lastName, d.email, d.phone].map((s) =>
      s.trim().toLowerCase(),
    ),
    c: [d.practiceName, d.role, d.locations, d.adSpend, d.avgStartValue, d.industry],
    f: [d.leads, d.booked, d.showed],
    m: [
      d.mInquiries,
      d.mContacted,
      d.mBooked,
      d.mConfirmed,
      d.mShowed,
      d.mStarted,
      d.mAdSpend,
      d.mAvgStartValue,
    ],
  });
}

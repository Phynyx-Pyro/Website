// Growth Snapshot journey state, effects, handlers, and computed values.
// Extracted from GrowthAssessmentFunnel so the component stays a thin
// presentational layer. Owns all form state, sessionStorage persistence,
// submission-fingerprint dedup, and the free-calculator/completion math.
//
// Fingerprint dedup records a success marker ONLY after a real 2xx. A
// failed/unknown request is never treated as success, and this module does
// not imply server-side idempotency — it is same-browser progress only.

import { useEffect, useMemo, useRef, useState } from "react";
import { useSearch } from "@tanstack/react-router";
import {
  trackGrowthSnapshotIntake,
  trackGrowthSnapshotCompletion,
  type TrackingResult,
} from "../lib/growth-snapshot-tracking";
import {
  type FunnelMetric,
  EMPTY_METRIC,
  loadPersisted,
  persistState,
  clearPersisted,
  metricNum,
  metricFloat,
  freeNum,
  round1,
  pct,
  buildRates,
  costPer,
  computeScenario,
  buildSummary,
  downloadSnapshot,
  validateFunnelSequence,
  validateFreeSequence,
} from "../lib/growth-snapshot-calc";
import { useGrowthSnapshotFingerprints } from "../components/useGrowthSnapshotFingerprints";

const CTA_FALLBACK = "growth-assessment-contact";
const CTA_RE = /^[a-zA-Z0-9_-]+$/;

function parseCtaSource(raw: unknown): string {
  if (typeof raw !== "string") return CTA_FALLBACK;
  if (raw.length === 0 || raw.length > 64) return CTA_FALLBACK;
  if (!CTA_RE.test(raw)) return CTA_FALLBACK;
  return raw;
}

export type Step = "free" | "contact" | "business" | "funnel" | "snapshot";

export function useGrowthSnapshotJourney(defaultIndustry = "chiropractic") {
  const search = useSearch({ strict: false }) as Record<string, unknown>;
  const ctaSource = parseCtaSource(search["cta"]);

  const restored = useRef(loadPersisted());
  const r = (restored.current ?? {}) as Partial<NonNullable<ReturnType<typeof loadPersisted>>>;

  const [step, setStep] = useState<Step>((r.step as Step) ?? "free");

  const [leads, setLeads] = useState(r.leads ?? "");
  const [booked, setBooked] = useState(r.booked ?? "");
  const [showed, setShowed] = useState(r.showed ?? "");

  const [businessName, setBusinessName] = useState(r.businessName ?? "");
  const [firstName, setFirstName] = useState(r.firstName ?? "");
  const [lastName, setLastName] = useState(r.lastName ?? "");
  const [email, setEmail] = useState(r.email ?? "");
  const [phone, setPhone] = useState(r.phone ?? "");
  const [appointmentTexts, setAppointmentTexts] = useState(r.appointmentTexts ?? false);
  const [marketingTexts, setMarketingTexts] = useState(r.marketingTexts ?? false);
  const [aiPhoneCalls, setAiPhoneCalls] = useState(r.aiPhoneCalls ?? false);

  const [practiceName, setPracticeName] = useState(r.practiceName ?? "");
  const [role, setRole] = useState(r.role ?? "Owner / Chiropractor");
  const [locations, setLocations] = useState(r.locations ?? "1");
  const [adSpend, setAdSpend] = useState(r.adSpend ?? "$1,000 - $3,000/mo");
  const [avgStartValue, setAvgStartValue] = useState(r.avgStartValue ?? "");
  const [industry, setIndustry] = useState(r.industry ?? defaultIndustry);

  const [mInquiries, setMInquiries] = useState<FunnelMetric>(r.mInquiries ?? EMPTY_METRIC);
  const [mContacted, setMContacted] = useState<FunnelMetric>(r.mContacted ?? EMPTY_METRIC);
  const [mBooked, setMBooked] = useState<FunnelMetric>(r.mBooked ?? EMPTY_METRIC);
  const [mConfirmed, setMConfirmed] = useState<FunnelMetric>(r.mConfirmed ?? EMPTY_METRIC);
  const [mShowed, setMShowed] = useState<FunnelMetric>(r.mShowed ?? EMPTY_METRIC);
  const [mStarted, setMStarted] = useState<FunnelMetric>(r.mStarted ?? EMPTY_METRIC);
  const [mAdSpend, setMAdSpend] = useState<FunnelMetric>(r.mAdSpend ?? EMPTY_METRIC);
  const [mAvgStartValue, setMAvgStartValue] = useState<FunnelMetric>(
    r.mAvgStartValue ?? EMPTY_METRIC,
  );

  const [intakeStatus, setIntakeStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [intakeResult, setIntakeResult] = useState<TrackingResult | null>(null);
  const intakeSubmittingRef = useRef(false);

  const [completionStatus, setCompletionStatus] = useState<
    "idle" | "submitting" | "done" | "error"
  >("idle");
  const [completionResult, setCompletionResult] = useState<TrackingResult | null>(null);
  const completionSubmittingRef = useRef(false);

  const fp = useGrowthSnapshotFingerprints(
    {
      businessName,
      firstName,
      lastName,
      email,
      phone,
      appointmentTexts,
      marketingTexts,
      aiPhoneCalls,
      ctaSource,
      practiceName,
      role,
      locations,
      adSpend,
      avgStartValue,
      industry,
      leads,
      booked,
      showed,
      step,
      mInquiries,
      mContacted,
      mBooked,
      mConfirmed,
      mShowed,
      mStarted,
      mAdSpend,
      mAvgStartValue,
    },
    { intakeFingerprint: r.intakeFingerprint, completionFingerprint: r.completionFingerprint },
  );

  useEffect(() => {
    persistState({
      version: 1,
      savedAt: Date.now(),
      step,
      leads,
      booked,
      showed,
      businessName,
      firstName,
      lastName,
      email,
      phone,
      appointmentTexts,
      marketingTexts,
      aiPhoneCalls,
      practiceName,
      role,
      locations,
      adSpend,
      avgStartValue,
      industry,
      mInquiries,
      mContacted,
      mBooked,
      mConfirmed,
      mShowed,
      mStarted,
      mAdSpend,
      mAvgStartValue,
      intakeFingerprint: fp.intakeFingerprintSaved ?? undefined,
      completionFingerprint: fp.completionFingerprintSaved ?? undefined,
    });
  }, [
    step,
    leads,
    booked,
    showed,
    businessName,
    firstName,
    lastName,
    email,
    phone,
    appointmentTexts,
    marketingTexts,
    aiPhoneCalls,
    practiceName,
    role,
    locations,
    adSpend,
    avgStartValue,
    industry,
    mInquiries,
    mContacted,
    mBooked,
    mConfirmed,
    mShowed,
    mStarted,
    mAdSpend,
    mAvgStartValue,
    fp.intakeFingerprintSaved,
    fp.completionFingerprintSaved,
  ]);

  // Free-check math
  const leadsNum = freeNum(leads);
  const bookedNum = freeNum(booked);
  const showedNum = freeNum(showed);
  const hasAllThree = leadsNum !== null && bookedNum !== null && showedNum !== null;
  const bookedRate = leadsNum !== null && bookedNum !== null ? pct(bookedNum, leadsNum) : null;
  const showRate = bookedNum !== null && showedNum !== null ? pct(showedNum, bookedNum) : null;
  const dropoff =
    bookedNum !== null && showedNum !== null && showedNum <= bookedNum && bookedNum > 0
      ? round1(((bookedNum - showedNum) / bookedNum) * 100)
      : null;

  const freeSequenceIssues = useMemo(
    () => validateFreeSequence(leadsNum, bookedNum, showedNum),
    [leadsNum, bookedNum, showedNum],
  );
  const freeSequenceOk = freeSequenceIssues.length === 0;

  // Funnel metric math
  const nInquiries = metricNum(mInquiries);
  const nContacted = metricNum(mContacted);
  const nBooked = metricNum(mBooked);
  const nConfirmed = metricNum(mConfirmed);
  const nShowed = metricNum(mShowed);
  const nStarted = metricNum(mStarted);
  const nAdSpend = metricFloat(mAdSpend);
  const nAvgStartValue = metricFloat(mAvgStartValue);

  const rates = useMemo(
    () =>
      buildRates({
        inquiries: nInquiries,
        contacted: nContacted,
        booked: nBooked,
        confirmed: nConfirmed,
        showed: nShowed,
        started: nStarted,
      }),
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed, nStarted],
  );
  const validRates = rates.filter((rr) => rr.rate !== null);
  const trackedCount = [
    nInquiries,
    nContacted,
    nBooked,
    nConfirmed,
    nShowed,
    nStarted,
    nAdSpend,
    nAvgStartValue,
  ].filter((n) => n !== null).length;
  const weakest =
    validRates.length > 0
      ? validRates.reduce((min, rr) => (rr.rate! < min.rate! ? rr : min))
      : null;
  const sequenceIssues = useMemo(
    () =>
      validateFunnelSequence({
        inquiries: nInquiries,
        contacted: nContacted,
        booked: nBooked,
        confirmed: nConfirmed,
        showed: nShowed,
        started: nStarted,
      }),
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed, nStarted],
  );
  const scenario = computeScenario(
    rates,
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed],
    nStarted,
  );
  const cpl = costPer(nInquiries, nAdSpend);
  const cpb = costPer(nBooked, nAdSpend);
  const cps = costPer(nShowed, nAdSpend);
  const cpStart = costPer(nStarted, nAdSpend);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Unchanged payload after a prior successful 2xx — advance without a
    // duplicate POST. Changed details/consent submit a new event.
    if (fp.intakeAlreadySaved) {
      setStep("business");
      return;
    }
    if (intakeSubmittingRef.current) return;
    intakeSubmittingRef.current = true;
    setIntakeStatus("submitting");
    setIntakeResult(null);
    const result = await trackGrowthSnapshotIntake({
      businessName,
      firstName,
      lastName,
      email,
      phone,
      appointmentTexts,
      marketingTexts,
      aiPhoneCalls,
      ctaSource,
    });
    setIntakeResult(result);
    intakeSubmittingRef.current = false;
    if (result.ok) {
      fp.recordIntakeSuccess(result);
      setIntakeStatus("idle");
      setStep("business");
    } else {
      setIntakeStatus("error");
    }
  };

  const handleShowSnapshot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (fp.completionAlreadySaved) {
      setCompletionStatus("done");
      return;
    }
    if (completionSubmittingRef.current) return;
    completionSubmittingRef.current = true;
    setCompletionStatus("submitting");
    setCompletionResult(null);

    const summary = buildSummary({
      industry,
      businessName,
      practiceName,
      firstName,
      lastName,
      email,
      phone,
      role,
      locations,
      adSpend,
      avgStartValue,
      leadsNum,
      bookedNum,
      showedNum,
      bookedRate,
      showRate,
      dropoff,
      metrics: [
        ["Inquiries", nInquiries, mInquiries.quality],
        ["Contacted", nContacted, mContacted.quality],
        ["Booked", nBooked, mBooked.quality],
        ["Confirmed", nConfirmed, mConfirmed.quality],
        ["Showed", nShowed, mShowed.quality],
        ["Started (care)", nStarted, mStarted.quality],
        ["Ad spend", nAdSpend, mAdSpend.quality],
        ["Avg start value", nAvgStartValue, mAvgStartValue.quality],
      ],
      rates,
      cpl,
      cpb,
      cps,
      cpStart,
      weakest,
      scenario,
      sequenceIssues,
    });

    const result = await trackGrowthSnapshotCompletion({
      businessName: businessName || practiceName,
      firstName,
      lastName,
      email,
      phone,
      ctaSource,
      status: "Completed",
      completedAt: new Date().toISOString(),
      summary,
      industry,
      primaryChallenge: weakest
        ? `${weakest.label} (${weakest.from}→${weakest.to}) at ${weakest.rate}%`
        : "Not enough data to identify",
    });
    setCompletionResult(result);
    if (result.ok) fp.recordCompletionSuccess(result);
    setCompletionStatus(result.ok ? "done" : "error");
    completionSubmittingRef.current = false;
  };

  const handleDownload = () =>
    downloadSnapshot({
      industry,
      leadsNum,
      bookedNum,
      showedNum,
      bookedRate,
      showRate,
      dropoff,
      nInquiries,
      nContacted,
      nBooked,
      nConfirmed,
      nShowed,
      nStarted,
      nAdSpend,
      nAvgStartValue,
      mInquiries,
      mContacted,
      mBooked,
      mConfirmed,
      mShowed,
      mStarted,
      mAdSpend,
      mAvgStartValue,
      rates,
      cpl,
      cpb,
      cps,
      cpStart,
      weakest,
      scenario,
      sequenceIssues,
    });

  const handleStartOver = () => {
    clearPersisted();
    fp.resetFingerprints();
    setStep("free");
    setLeads("");
    setBooked("");
    setShowed("");
    setBusinessName("");
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
    setAppointmentTexts(false);
    setMarketingTexts(false);
    setAiPhoneCalls(false);
    setPracticeName("");
    setRole("Owner / Chiropractor");
    setLocations("1");
    setAdSpend("$1,000 - $3,000/mo");
    setAvgStartValue("");
    setIndustry(defaultIndustry);
    setMInquiries(EMPTY_METRIC);
    setMContacted(EMPTY_METRIC);
    setMBooked(EMPTY_METRIC);
    setMConfirmed(EMPTY_METRIC);
    setMShowed(EMPTY_METRIC);
    setMStarted(EMPTY_METRIC);
    setMAdSpend(EMPTY_METRIC);
    setMAvgStartValue(EMPTY_METRIC);
    setIntakeStatus("idle");
    setIntakeResult(null);
    setCompletionStatus("idle");
    setCompletionResult(null);
  };

  return {
    // attribution
    ctaSource,
    // step
    step,
    setStep,
    // free check
    leads,
    setLeads,
    booked,
    setBooked,
    showed,
    setShowed,
    leadsNum,
    bookedNum,
    showedNum,
    hasAllThree,
    bookedRate,
    showRate,
    dropoff,
    freeSequenceIssues,
    freeSequenceOk,
    // contact
    businessName,
    setBusinessName,
    firstName,
    setFirstName,
    lastName,
    setLastName,
    email,
    setEmail,
    phone,
    setPhone,
    appointmentTexts,
    setAppointmentTexts,
    marketingTexts,
    setMarketingTexts,
    aiPhoneCalls,
    setAiPhoneCalls,
    // business
    practiceName,
    setPracticeName,
    role,
    setRole,
    locations,
    setLocations,
    adSpend,
    setAdSpend,
    avgStartValue,
    setAvgStartValue,
    industry,
    setIndustry,
    // funnel metrics
    mInquiries,
    setMInquiries,
    mContacted,
    setMContacted,
    mBooked,
    setMBooked,
    mConfirmed,
    setMConfirmed,
    mShowed,
    setMShowed,
    mStarted,
    setMStarted,
    mAdSpend,
    setMAdSpend,
    mAvgStartValue,
    setMAvgStartValue,
    nInquiries,
    nContacted,
    nBooked,
    nConfirmed,
    nShowed,
    nStarted,
    nAdSpend,
    nAvgStartValue,
    // computed
    rates,
    validRates,
    trackedCount,
    weakest,
    sequenceIssues,
    scenario,
    cpl,
    cpb,
    cps,
    cpStart,
    // submission
    intakeStatus,
    intakeResult,
    handleContactSubmit,
    completionStatus,
    completionResult,
    completionAlreadySaved: fp.completionAlreadySaved,
    handleShowSnapshot,
    handleDownload,
    handleStartOver,
  };
}

export type GrowthSnapshotJourney = ReturnType<typeof useGrowthSnapshotJourney>;

import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Clock,
  Activity,
  ShieldX,
  Globe,
  Download,
  AlertCircle,
  Loader2,
  TrendingUp,
  CheckCircle2,
} from "lucide-react";
import {
  MetaItem,
  FreeInput,
  RateStat,
  Field,
  SelectField,
  ConsentCheck,
  MetricInput,
  KpiTile,
  SequenceIssueBanner,
  ErrorBanner,
  Card,
  PRIMARY_BUTTON,
  FULL_BUTTON,
} from "./growth-snapshot-ui";
import { useGrowthSnapshotJourney } from "../hooks/use-growth-snapshot-journey";
import { formatMoney, formatRate } from "../lib/growth-snapshot-calc";

const CONSENT_TEXT = {
  appointment:
    "I agree to non-marketing texts from PhynyxPro about diagnostic appointment confirmations, reminders, and changes. Frequency varies. Message and data rates may apply. Reply STOP to opt out, HELP for help.",
  marketing:
    "I agree to automated marketing texts from PhynyxPro about its services, my snapshot, and booking a diagnostic at the number provided. Frequency varies. Message and data rates may apply. Reply STOP to opt out, HELP for help. Consent is not required to buy.",
  aiVoice:
    "I agree to marketing calls from PhynyxPro at the number provided about its services, my snapshot, and diagnostic, using an automated system and an artificial or AI-generated voice. Consent is not required to buy. Ask us to stop anytime.",
};

const STEP_LABEL = {
  contact: "Step 1 of 4",
  business: "Step 2 of 4",
  funnel: "Step 3 of 4",
  snapshot: "Step 4 of 4",
} as const;

const STEP_SUB = {
  contact: "Save your snapshot",
  business: "Business context",
  funnel: "Funnel numbers",
  snapshot: "Your snapshot",
} as const;

const STEP_WIDTH = {
  contact: "25%",
  business: "50%",
  funnel: "75%",
  snapshot: "100%",
} as const;

export function GrowthAssessmentFunnel({
  defaultIndustry = "chiropractic",
}: {
  defaultIndustry?: string;
}) {
  const j = useGrowthSnapshotJourney(defaultIndustry);

  const scheduleLink = (
    <Link
      to="/schedule"
      search={{ cta: "growth-snapshot-complete" }}
      className="inline-flex items-center gap-2 px-6 py-3.5 bg-phoenix hover:bg-ember text-white font-semibold text-sm rounded-lg transition-colors shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)]"
    >
      Schedule My Growth Call <ArrowRight className="w-4 h-4" />
    </Link>
  );

  return (
    <div className="mx-auto w-full max-w-[720px]">
      {j.step === "free" ? (
        <div className="text-center mb-12 lg:mb-14">
          <h1 className="text-3xl sm:text-4xl lg:text-[52px] font-bold tracking-tight leading-[1.08]">
            See Where Demand <span className="text-phoenix">Stops Moving</span>
          </h1>
          <p className="mt-5 text-base text-warm leading-relaxed max-w-xl mx-auto">
            Use three numbers from a recent 30-day period to see two handoffs in your acquisition
            funnel. Try it free, without sharing contact details.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-warm">
            <MetaItem icon={Clock} label="About 30 seconds" />
            <MetaItem icon={Activity} label="Live conversion math" />
            <MetaItem icon={ShieldX} label="No performance guarantee" />
          </div>
        </div>
      ) : (
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl lg:text-[52px] font-bold tracking-tight leading-[1.08]">
            Build Your Acquisition <span className="text-phoenix">Growth Snapshot</span>
          </h1>
          <p className="mt-5 text-base text-warm leading-relaxed max-w-xl mx-auto">
            Use your most recent complete 30-day period. Exact numbers are best, estimates are
            useful, and &ldquo;not tracked&rdquo; is a valid answer.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-warm">
            <MetaItem icon={Clock} label="About 3 minutes" />
            <MetaItem icon={Activity} label="Immediate KPI snapshot" />
            <MetaItem icon={ShieldX} label="No performance guarantee" />
            <MetaItem icon={Globe} label="Website" />
          </div>
          <div className="mt-8 max-w-md mx-auto text-left">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-widest text-warm mb-2">
              <span>{STEP_LABEL[j.step]}</span>
              <span>{STEP_SUB[j.step]}</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-linen overflow-hidden">
              <div
                className="h-full rounded-full bg-phoenix transition-all"
                style={{ width: STEP_WIDTH[j.step] }}
              />
            </div>
          </div>
        </div>
      )}

      {j.step === "free" && (
        <Card className="p-6 lg:p-8 mx-auto w-full max-w-[720px]">
          <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix mb-3">
            Free Funnel Check
          </p>
          <h2 className="text-[22px] font-bold tracking-tight text-ink leading-[1.2]">
            Your last complete 30 days
          </h2>
          <p className="mt-3 text-sm text-warm leading-relaxed">
            Estimates are fine. Leave these blank if you do not track them yet.
          </p>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <FreeInput
              id="free-leads"
              label="New Leads & Inquiries"
              hint="Calls, forms, chats, and other new leads"
              placeholder="80"
              value={j.leads}
              onChange={j.setLeads}
            />
            <FreeInput
              id="free-booked"
              label="Appointments Booked"
              hint="New prospects who selected a time"
              placeholder="28"
              value={j.booked}
              onChange={j.setBooked}
            />
            <FreeInput
              id="free-showed"
              label="Showed"
              hint="Booked prospects who actually showed up"
              placeholder="20"
              value={j.showed}
              onChange={j.setShowed}
            />
          </div>
          <div className="mt-5">
            {j.hasAllThree && j.freeSequenceOk ? (
              <div className="rounded-xl bg-night text-white grain-dark p-4 border border-white/10 grid grid-cols-3 gap-3 text-center">
                <RateStat label="Booked Rate" value={j.bookedRate} sub="Inquiry → Booked" />
                <RateStat label="Show Rate" value={j.showRate} sub="Booked → Attended" />
                <RateStat label="Drop-off" value={j.dropoff} sub="Booked → Show gap" />
              </div>
            ) : j.hasAllThree && !j.freeSequenceOk ? (
              <SequenceIssueBanner
                title="Check your counts"
                issues={j.freeSequenceIssues}
                footer="Rates are hidden until the sequence is valid (Showed ≤ Booked ≤ Leads)."
              />
            ) : (
              <p className="text-sm text-warm leading-relaxed">
                Enter all three counts to see your conversion rates. No contact details are needed.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={() => j.setStep("contact")}
            className={`mt-6 ${FULL_BUTTON}`}
          >
            Continue Without Numbers <ArrowRight className="w-4 h-4" />
          </button>
          <p className="mt-4 text-[12px] text-warm/80 leading-relaxed text-center">
            This calculation stays in your browser until you choose to continue. It is not a
            forecast or performance guarantee.
          </p>
        </Card>
      )}

      {j.step === "contact" && (
        <form onSubmit={j.handleContactSubmit} className="space-y-5 p-6 lg:p-8">
          <Card className="p-6 lg:p-8 space-y-5">
            <div>
              <h2 className="text-lg font-bold text-ink">Your Contact Details</h2>
              <p className="mt-1 text-[12px] text-warm leading-relaxed">
                Tell us about you and your business so we can save your progress and continue your
                snapshot.
              </p>
            </div>
            {j.intakeStatus === "error" && j.intakeResult && !j.intakeResult.ok && (
              <ErrorBanner
                title="Your details could not be saved"
                message={j.intakeResult.message}
                detail="Your entries are preserved. You can retry without losing progress."
              />
            )}
            <Field
              id="snap-business"
              label="Business Name"
              required
              value={j.businessName}
              onChange={j.setBusinessName}
              type="text"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field
                id="snap-first"
                label="First Name"
                required
                value={j.firstName}
                onChange={j.setFirstName}
                type="text"
              />
              <Field
                id="snap-last"
                label="Last Name"
                required
                value={j.lastName}
                onChange={j.setLastName}
                type="text"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field
                id="snap-email"
                label="Work Email"
                required
                value={j.email}
                onChange={j.setEmail}
                type="email"
              />
              <Field
                id="snap-phone"
                label="Phone"
                required
                value={j.phone}
                onChange={j.setPhone}
                type="tel"
              />
            </div>
            <div className="pt-2">
              <p className="text-[11px] font-bold text-warm uppercase tracking-wider">
                Stay in touch (optional)
              </p>
              <p className="mt-1 text-[12px] text-warm leading-relaxed">
                Choose any, or skip and continue.
              </p>
              <div className="mt-3 space-y-3">
                <ConsentCheck
                  title="Appointment texts"
                  checked={j.appointmentTexts}
                  onChange={j.setAppointmentTexts}
                  text={CONSENT_TEXT.appointment}
                />
                <ConsentCheck
                  title="Marketing texts"
                  checked={j.marketingTexts}
                  onChange={j.setMarketingTexts}
                  text={CONSENT_TEXT.marketing}
                />
                <ConsentCheck
                  title="AI phone calls"
                  checked={j.aiPhoneCalls}
                  onChange={j.setAiPhoneCalls}
                  text={CONSENT_TEXT.aiVoice}
                />
              </div>
            </div>
            <p className="text-[11px] text-warm/80 leading-relaxed pt-1">
              Your results are downloadable on this page. You can book a growth call to discuss
              them.{" "}
              <Link to="/privacy-policy" className="underline hover:text-ink">
                Privacy Policy
              </Link>{" "}
              ·{" "}
              <Link to="/terms" className="underline hover:text-ink">
                Terms
              </Link>
            </p>
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => j.setStep("free")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to free check
            </button>
            <button
              type="submit"
              disabled={j.intakeStatus === "submitting"}
              className={PRIMARY_BUTTON}
            >
              {j.intakeStatus === "submitting" ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Saving…
                </>
              ) : (
                <>
                  Continue to Practice Baseline <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {j.step === "business" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            j.setStep("funnel");
          }}
          className="space-y-5"
        >
          <Card className="p-6 lg:p-8 space-y-5">
            <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
              Step 2 of 4 · Business context
            </p>
            <h2 className="text-lg font-bold text-ink">Practice & Readiness Details</h2>
            <Field
              id="snap-practice-name"
              label="Practice Name"
              required
              value={j.practiceName}
              onChange={j.setPracticeName}
              type="text"
            />
            <div>
              <label htmlFor="snap-industry" className="block text-xs font-semibold text-ink mb-1">
                Industry
              </label>
              <select
                id="snap-industry"
                value={j.industry}
                onChange={(e) => j.setIndustry(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix bg-white"
              >
                <option value="chiropractic">Chiropractic</option>
                <option value="home-services">Home Services</option>
                <option value="dental-medspa">Dental & Medspa</option>
                <option value="other-service">Other Service Business</option>
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <SelectField
                id="snap-role"
                label="Role"
                value={j.role}
                onChange={j.setRole}
                options={[
                  "Owner / Chiropractor",
                  "Practice Manager",
                  "Marketing Director",
                  "Other Staff",
                ]}
              />
              <SelectField
                id="snap-locations"
                label="Locations"
                value={j.locations}
                onChange={j.setLocations}
                options={["1", "2-3", "4+"]}
              />
              <SelectField
                id="snap-adspend"
                label="Monthly Ad Budget"
                value={j.adSpend}
                onChange={j.setAdSpend}
                options={[
                  "Under $1,000/mo",
                  "$1,000 - $3,000/mo",
                  "$3,000 - $5,000/mo",
                  "$5,000+/mo",
                ]}
              />
            </div>
            <Field
              id="snap-avg-start"
              label="Average start-of-care / service value (optional)"
              value={j.avgStartValue}
              onChange={j.setAvgStartValue}
              type="text"
            />
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => j.setStep("contact")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to contact
            </button>
            <button type="submit" className={PRIMARY_BUTTON}>
              Continue to Funnel Numbers <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {j.step === "funnel" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void j.handleShowSnapshot(e);
            j.setStep("snapshot");
          }}
          className="space-y-5"
        >
          <Card className="p-6 lg:p-8 space-y-5">
            <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
              Step 3 of 4 · Funnel numbers
            </p>
            <h2 className="text-lg font-bold text-ink">Your Recent 30-Day Metrics</h2>
            <p className="text-[12px] text-warm leading-relaxed">
              Enter what you track. Each field accepts a number plus whether it is Exact, an
              Estimate, or Not tracked. Missing data is valid and part of what we&rsquo;ll map.
            </p>
            <div className="space-y-4">
              <MetricInput
                label="Inquiries"
                hint="Calls, forms, chats, and other new leads"
                metric={j.mInquiries}
                onChange={j.setMInquiries}
              />
              <MetricInput
                label="Contacted"
                hint="Leads you actually reached/responded to"
                metric={j.mContacted}
                onChange={j.setMContacted}
              />
              <MetricInput
                label="Booked"
                hint="Prospects who selected a time"
                metric={j.mBooked}
                onChange={j.setMBooked}
              />
              <MetricInput
                label="Confirmed"
                hint="Booked appointments with a confirmed time"
                metric={j.mConfirmed}
                onChange={j.setMConfirmed}
              />
              <MetricInput
                label="Showed"
                hint="Confirmed appointments that were attended"
                metric={j.mShowed}
                onChange={j.setMShowed}
              />
              <MetricInput
                label="Started (care/services)"
                hint="New patients/clients who started care or service"
                metric={j.mStarted}
                onChange={j.setMStarted}
              />
              <MetricInput
                label="Ad Spend ($)"
                hint="Total media spend in the period (decimals allowed)"
                metric={j.mAdSpend}
                onChange={j.setMAdSpend}
              />
              <MetricInput
                label="Average Start Value ($)"
                hint="Average revenue per start of care/service (decimals allowed)"
                metric={j.mAvgStartValue}
                onChange={j.setMAvgStartValue}
              />
            </div>
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => j.setStep("business")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to business context
            </button>
            <button type="submit" className={PRIMARY_BUTTON}>
              Show My Growth Snapshot <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {j.step === "snapshot" && (
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 space-y-6">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
                Step 4 of 4 · Your snapshot
              </p>
              <h2 className="text-2xl font-bold text-ink mt-2">Your Growth Snapshot</h2>
              <p className="mt-2 text-sm text-warm leading-relaxed">
                Live KPIs from the numbers you entered. Missing or inconsistent data shows as
                &ldquo;Not enough data&rdquo; — we never invent numbers.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <KpiTile label="Metrics Tracked" value={`${j.trackedCount}/8`} />
              <KpiTile label="Valid Rates" value={`${j.validRates.length}/5`} />
              <KpiTile label="Cost / Lead" value={formatMoney(j.cpl)} />
              <KpiTile label="Cost / Start" value={formatMoney(j.cpStart)} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-ink mb-3">Conversion Rates</h3>
              <div className="space-y-2">
                {j.rates.map((rr) => (
                  <div
                    key={rr.label}
                    className="flex items-center justify-between rounded-lg bg-ivory/60 px-4 py-2.5 border border-black/5"
                  >
                    <div>
                      <p className="text-sm font-semibold text-ink">{rr.label}</p>
                      <p className="text-[11px] text-warm">
                        {rr.from} → {rr.to}
                      </p>
                    </div>
                    <p
                      className={`text-lg font-bold ${rr.rate === null ? "text-warm/50" : "text-phoenix"}`}
                    >
                      {formatRate(rr.rate)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-ink mb-3">Cost Metrics</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <KpiTile label="Cost / Lead" value={formatMoney(j.cpl)} />
                <KpiTile label="Cost / Booked" value={formatMoney(j.cpb)} />
                <KpiTile label="Cost / Show" value={formatMoney(j.cps)} />
                <KpiTile label="Cost / Start" value={formatMoney(j.cpStart)} />
              </div>
            </div>
            {j.sequenceIssues.length > 0 && (
              <SequenceIssueBanner
                title="Check your funnel counts"
                issues={j.sequenceIssues}
                footer="Rates for inconsistent stages are hidden. Fix the counts and the scenario will update."
              />
            )}
            <div className="rounded-xl bg-linen border border-black/10 p-4">
              <p className="text-[11px] font-bold uppercase tracking-wider text-warm mb-1">
                Primary Challenge
              </p>
              {j.weakest ? (
                <p className="text-sm text-ink">
                  <span className="font-bold">{j.weakest.label}</span> ({j.weakest.from} →{" "}
                  {j.weakest.to}) at{" "}
                  <span className="text-phoenix font-bold">{j.weakest.rate}%</span> — the weakest
                  observed handoff.
                </p>
              ) : (
                <p className="text-sm text-warm">
                  Not enough data to identify a primary challenge. Add more tracked metrics to see
                  this.
                </p>
              )}
            </div>
            <div className="rounded-xl bg-night text-white grain-dark border border-white/10 p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-flame" />
                <p className="text-[11px] font-bold uppercase tracking-wider text-white/70">
                  Illustrative Scenario
                </p>
              </div>
              {j.scenario ? (
                <div className="space-y-1.5 text-sm">
                  <p>
                    If <span className="font-bold text-flame">{j.scenario.stage}</span> improved by{" "}
                    <span className="font-bold">+10 percentage points</span> (to{" "}
                    {j.scenario.improvedRate}%), propagating your observed downstream conversion:
                  </p>
                  {j.scenario.additionalStarts !== null ? (
                    <p className="text-white/90">
                      Estimated additional starts of care:{" "}
                      <span className="font-bold text-flame">{j.scenario.additionalStarts}</span>
                    </p>
                  ) : (
                    <p className="text-white/70">
                      Start count not tracked — scenario shows rate impact only.
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-sm text-white/70">
                  Not enough data to compute a scenario. Track more adjacent stages to see an
                  illustrative improvement.
                </p>
              )}
              <p className="mt-3 text-[11px] text-white/50 leading-relaxed">
                This is a conservative, illustrative scenario — not a forecast or performance
                guarantee. Inputs marked Estimate are approximations.
              </p>
            </div>
            <button
              type="button"
              onClick={j.handleDownload}
              className="w-full px-6 py-3.5 bg-ink hover:bg-night text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> Download My Snapshot
            </button>
            <p className="text-[11px] text-warm/70 text-center -mt-3">
              A readable .txt of your actual results, generated in your browser. No emailed PDF.
            </p>
          </Card>

          <Card className="p-6 lg:p-8 space-y-5">
            {j.completionAlreadySaved ? (
              <div className="text-center space-y-4">
                <div className="w-12 h-12 bg-phoenix/10 text-phoenix rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-ink">Snapshot Saved</h2>
                  <p className="text-sm text-warm mt-2 max-w-md mx-auto">
                    Your growth snapshot was submitted successfully, {j.firstName || "there"}. Your
                    results are downloadable on this page — book a growth call to discuss them.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={j.handleStartOver}
                    className="text-[12px] font-semibold text-warm hover:text-ink underline"
                  >
                    ← Start over
                  </button>
                  {scheduleLink}
                </div>
              </div>
            ) : (
              <>
                <div>
                  <h2 className="text-lg font-bold text-ink">Save Your Completed Snapshot</h2>
                  <p className="mt-1 text-[12px] text-warm leading-relaxed">
                    Submit your snapshot to record your results on this page. Your contact details
                    from Step 1 are included; consent selections are not re-sent. You can download
                    your results and optionally book a growth call to discuss them.
                  </p>
                </div>
                {j.completionStatus === "error" && j.completionResult && !j.completionResult.ok && (
                  <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-bold text-ink">Snapshot not yet saved</p>
                      <p className="text-[12px] text-warm mt-1 leading-relaxed">
                        {j.completionResult.message}
                      </p>
                      <p className="text-[12px] text-warm mt-1">
                        Your calculated results above are still visible and downloadable. Retry the
                        save when you&rsquo;re ready — booking and download remain available.
                      </p>
                    </div>
                  </div>
                )}
                <button
                  type="button"
                  onClick={j.handleShowSnapshot}
                  disabled={j.completionStatus === "submitting"}
                  className={FULL_BUTTON}
                >
                  {j.completionStatus === "submitting" ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Saving Snapshot…
                    </>
                  ) : j.completionStatus === "error" ? (
                    <>
                      <AlertCircle className="w-4 h-4" /> Retry Save
                    </>
                  ) : (
                    <>
                      Submit My Snapshot <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-black/10">
                  <button
                    type="button"
                    onClick={() => j.setStep("funnel")}
                    className="text-[12px] font-semibold text-warm hover:text-ink"
                  >
                    ← Back to funnel numbers
                  </button>
                  <Link
                    to="/schedule"
                    search={{ cta: "growth-snapshot-complete" }}
                    className="text-[12px] font-semibold text-phoenix hover:underline"
                  >
                    Skip to Schedule My Growth Call →
                  </Link>
                </div>
              </>
            )}
          </Card>
          <p className="text-[11px] text-warm/70 text-center leading-relaxed">
            Your progress is saved in this browser tab for 24 hours so an accidental reload resumes
            where you left off. This is same-browser progress, not cross-device retrieval.
          </p>
        </div>
      )}
    </div>
  );
}

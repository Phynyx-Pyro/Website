// Fingerprint state + persisted-state helpers for the Growth Snapshot journey.
// Extracted from GrowthAssessmentFunnel to keep the component lean.
//
// - persistSnapshotState: writes the full snapshot + fingerprint markers to
//   sessionStorage (24h TTL, same-browser only).
// - useGrowthSnapshotFingerprints: persisted success fingerprints + current
//   payload fingerprints for dedup. Records ONLY after a real 2xx; never treats
//   a failed/unknown request as success. Does not imply server-side idempotency.
//
// ctaSource is EXCLUDED from both fingerprints (attribution does not change the
// submitted data). The fields object still carries ctaSource for tracking use.

import { useMemo, useState } from "react";
import { intakeFingerprint, completionFingerprint } from "../lib/growth-snapshot-fingerprints";
import { persistState, type PersistedState, type FunnelMetric } from "../lib/growth-snapshot-calc";
import type { TrackingResult } from "../lib/growth-snapshot-tracking";

export interface SnapshotFields {
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  appointmentTexts: boolean;
  marketingTexts: boolean;
  aiPhoneCalls: boolean;
  ctaSource: string;
  practiceName: string;
  role: string;
  locations: string;
  adSpend: string;
  avgStartValue: string;
  industry: string;
  leads: string;
  booked: string;
  showed: string;
  step: string;
  mInquiries: FunnelMetric;
  mContacted: FunnelMetric;
  mBooked: FunnelMetric;
  mConfirmed: FunnelMetric;
  mShowed: FunnelMetric;
  mStarted: FunnelMetric;
  mAdSpend: FunnelMetric;
  mAvgStartValue: FunnelMetric;
  intakeFingerprintSaved: string | null;
  completionFingerprintSaved: string | null;
}

/** Persist the full snapshot state to sessionStorage (called from a useEffect). */
export function persistSnapshotState(f: SnapshotFields) {
  persistState({
    version: 1,
    savedAt: Date.now(),
    step: f.step,
    leads: f.leads,
    booked: f.booked,
    showed: f.showed,
    businessName: f.businessName,
    firstName: f.firstName,
    lastName: f.lastName,
    email: f.email,
    phone: f.phone,
    appointmentTexts: f.appointmentTexts,
    marketingTexts: f.marketingTexts,
    aiPhoneCalls: f.aiPhoneCalls,
    practiceName: f.practiceName,
    role: f.role,
    locations: f.locations,
    adSpend: f.adSpend,
    avgStartValue: f.avgStartValue,
    industry: f.industry,
    mInquiries: f.mInquiries,
    mContacted: f.mContacted,
    mBooked: f.mBooked,
    mConfirmed: f.mConfirmed,
    mShowed: f.mShowed,
    mStarted: f.mStarted,
    mAdSpend: f.mAdSpend,
    mAvgStartValue: f.mAvgStartValue,
    intakeFingerprint: f.intakeFingerprintSaved ?? undefined,
    completionFingerprint: f.completionFingerprintSaved ?? undefined,
  } as PersistedState);
}

export interface Persisted {
  intakeFingerprint?: string | undefined;
  completionFingerprint?: string | undefined;
}

/**
 * Manages persisted success fingerprints and computes the current-payload
 * fingerprints for dedup. Call `recordIntakeSuccess(result)` and
 * `recordCompletionSuccess(result)` only after a real 2xx. Call
 * `resetFingerprints()` from Start Over.
 */
export function useGrowthSnapshotFingerprints(
  fields: Omit<SnapshotFields, "intakeFingerprintSaved" | "completionFingerprintSaved">,
  restored: Persisted,
) {
  const [intakeFingerprintSaved, setIntakeFingerprintSaved] = useState<string | null>(
    restored.intakeFingerprint ?? null,
  );
  const [completionFingerprintSaved, setCompletionFingerprintSaved] = useState<string | null>(
    restored.completionFingerprint ?? null,
  );

  const currentIntakeFp = useMemo(
    () =>
      intakeFingerprint({
        businessName: fields.businessName,
        firstName: fields.firstName,
        lastName: fields.lastName,
        email: fields.email,
        phone: fields.phone,
        appointmentTexts: fields.appointmentTexts,
        marketingTexts: fields.marketingTexts,
        aiPhoneCalls: fields.aiPhoneCalls,
      }),
    [
      fields.businessName,
      fields.firstName,
      fields.lastName,
      fields.email,
      fields.phone,
      fields.appointmentTexts,
      fields.marketingTexts,
      fields.aiPhoneCalls,
    ],
  );

  const currentCompletionFp = useMemo(
    () =>
      completionFingerprint({
        businessName: fields.businessName,
        firstName: fields.firstName,
        lastName: fields.lastName,
        email: fields.email,
        phone: fields.phone,
        practiceName: fields.practiceName,
        role: fields.role,
        locations: fields.locations,
        adSpend: fields.adSpend,
        avgStartValue: fields.avgStartValue,
        industry: fields.industry,
        leads: fields.leads,
        booked: fields.booked,
        showed: fields.showed,
        mInquiries: fields.mInquiries,
        mContacted: fields.mContacted,
        mBooked: fields.mBooked,
        mConfirmed: fields.mConfirmed,
        mShowed: fields.mShowed,
        mStarted: fields.mStarted,
        mAdSpend: fields.mAdSpend,
        mAvgStartValue: fields.mAvgStartValue,
      }),
    [
      fields.businessName,
      fields.firstName,
      fields.lastName,
      fields.email,
      fields.phone,
      fields.practiceName,
      fields.role,
      fields.locations,
      fields.adSpend,
      fields.avgStartValue,
      fields.industry,
      fields.leads,
      fields.booked,
      fields.showed,
      fields.mInquiries,
      fields.mContacted,
      fields.mBooked,
      fields.mConfirmed,
      fields.mShowed,
      fields.mStarted,
      fields.mAdSpend,
      fields.mAvgStartValue,
    ],
  );

  const completionAlreadySaved =
    completionFingerprintSaved !== null && completionFingerprintSaved === currentCompletionFp;

  const intakeAlreadySaved =
    intakeFingerprintSaved !== null && intakeFingerprintSaved === currentIntakeFp;

  function recordIntakeSuccess(result: TrackingResult) {
    if (result.ok) setIntakeFingerprintSaved(currentIntakeFp);
  }

  function recordCompletionSuccess(result: TrackingResult) {
    if (result.ok) setCompletionFingerprintSaved(currentCompletionFp);
  }

  function resetFingerprints() {
    setIntakeFingerprintSaved(null);
    setCompletionFingerprintSaved(null);
  }

  return {
    intakeFingerprintSaved,
    completionFingerprintSaved,
    currentIntakeFp,
    currentCompletionFp,
    completionAlreadySaved,
    intakeAlreadySaved,
    recordIntakeSuccess,
    recordCompletionSuccess,
    resetFingerprints,
  };
}

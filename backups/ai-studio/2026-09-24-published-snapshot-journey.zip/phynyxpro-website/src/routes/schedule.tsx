import { createFileRoute, useSearch } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ScheduleForm } from "../components/ScheduleForm";
import { Link } from "@tanstack/react-router";
import { Clock, CalendarCheck, ShieldCheck } from "lucide-react";

const CTA_FALLBACK = "schedule-page";
const CTA_RE = /^[a-zA-Z0-9_-]+$/;

/** Validate the `cta` search param as a short safe attribution token. */
function parseCtaSource(raw: unknown): string {
  if (typeof raw !== "string") return CTA_FALLBACK;
  if (raw.length === 0 || raw.length > 64) return CTA_FALLBACK;
  if (!CTA_RE.test(raw)) return CTA_FALLBACK;
  return raw;
}

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule My Growth Call | PhynyxPro" },
      {
        name: "description",
        content:
          "Book first. Revenue, ad budget, capacity, and funnel details can be discussed on the call. About 30 minutes.",
      },
      { property: "og:title", content: "Schedule My Growth Call — PhynyxPro" },
      {
        property: "og:description",
        content:
          "Pick a time now with only your contact and practice details. No long application before booking.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SchedulePage,
});

const POINTS = [
  { icon: Clock, title: "About 30 minutes" },
  { icon: CalendarCheck, title: "Choose the time that works for you" },
  { icon: ShieldCheck, title: "No long application before booking" },
];

function SchedulePage() {
  // `strict: false` returns an untyped `{}`; cast to a safe record so we can
  // read the optional `cta` attribution token without a TS2339.
  const search = useSearch({ strict: false }) as Record<string, unknown>;
  const ctaSource = parseCtaSource(search["cta"]);

  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px]">
        <section className="py-12 lg:py-20 bg-ivory">
          {/* Source: outer ~1050px centered (left≈435), columns 1fr 548px, gap≈68px,
              card lands ~x925, heading wraps 2 lines. */}
          <div className="mx-auto max-w-[1050px] px-5 lg:px-0 grid grid-cols-1 lg:grid-cols-[1fr_548px] gap-10 lg:gap-[68px] items-start">
            {/* Left column */}
            <div className="lg:pt-4">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                Direct scheduling
              </p>
              <h1 className="text-4xl lg:text-[56px] font-bold tracking-tight text-ink leading-[1.05]">
                Schedule My
                <br />
                Growth Call
              </h1>
              <p className="mt-5 text-base text-warm leading-relaxed max-w-md">
                Book first. Revenue, ad budget, capacity, and funnel details can be discussed on the
                call.
              </p>

              {/* Compact plain icon/text meta list — not bold rows with tinted tiles */}
              <ul className="mt-7 space-y-4">
                {POINTS.map((p) => (
                  <li key={p.title} className="flex items-center gap-3">
                    <p.icon className="w-4 h-4 text-phoenix shrink-0" />
                    <span className="text-sm text-warm">{p.title}</span>
                  </li>
                ))}
              </ul>

              {/* Snapshot link near y≈565, not y≈630 */}
              <p className="mt-7 text-sm text-warm">
                Prefer numbers first?{" "}
                <Link
                  to="/growth-assessment"
                  search={{ cta: "schedule-alternative", industry: "chiropractic" }}
                  className="font-semibold text-phoenix underline"
                >
                  Get the free snapshot
                </Link>
              </p>
            </div>

            {/* Right column — form card, source width ≈548 */}
            <ScheduleForm ctaSource={ctaSource} />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

import { describe, it, expect } from "vitest";
import {
  intakeFingerprint,
  completionFingerprint,
} from "../src/lib/growth-snapshot-fingerprints";
import { EMPTY_METRIC, type FunnelMetric } from "../src/lib/growth-snapshot-calc";

const metric = (value: string, quality: FunnelMetric["quality"] = "exact"): FunnelMetric => ({
  value,
  quality,
});

const baseIntake = {
  businessName: "Test Clinic",
  firstName: "Jane",
  lastName: "Doe",
  email: "Jane@Example.com",
  phone: "555-123-4567",
  appointmentTexts: false,
  marketingTexts: false,
  aiPhoneCalls: false,
};

const baseCompletion = {
  businessName: "Test Clinic",
  firstName: "Jane",
  lastName: "Doe",
  email: "Jane@Example.com",
  phone: "555-123-4567",
  practiceName: "Test Clinic LLC",
  role: "Owner / Chiropractor",
  locations: "1",
  adSpend: "$1,000 - $3,000/mo",
  avgStartValue: "",
  industry: "chiropractic",
  leads: "80",
  booked: "28",
  showed: "20",
  mInquiries: metric("80", "exact"),
  mContacted: metric("60", "estimate"),
  mBooked: metric("28", "exact"),
  mConfirmed: metric("24", "exact"),
  mShowed: metric("20", "exact"),
  mStarted: metric("10", "exact"),
  mAdSpend: metric("2500", "estimate"),
  mAvgStartValue: EMPTY_METRIC,
};

describe("intakeFingerprint — canonicalization", () => {
  it("is deterministic for identical input", () => {
    expect(intakeFingerprint(baseIntake)).toBe(intakeFingerprint({ ...baseIntake }));
  });

  it("is case-insensitive and trim-tolerant for identity fields", () => {
    expect(
      intakeFingerprint({
        ...baseIntake,
        businessName: "  Test Clinic  ",
        firstName: "  jane  ",
        lastName: "  DOE  ",
        email: "  JANE@EXAMPLE.COM  ",
      }),
    ).toBe(intakeFingerprint(baseIntake));
  });

  it("changes when a consent toggle flips", () => {
    const fp1 = intakeFingerprint(baseIntake);
    const fp2 = intakeFingerprint({ ...baseIntake, appointmentTexts: true });
    expect(fp1).not.toBe(fp2);
  });

  it("changes when phone differs", () => {
    const fp1 = intakeFingerprint(baseIntake);
    const fp2 = intakeFingerprint({ ...baseIntake, phone: "555-999-0000" });
    expect(fp1).not.toBe(fp2);
  });

  it("is delimiter-safe: a pipe in a field cannot collide with a different field", () => {
    // With join("|"), "a|b" in one field could collide with "a" + "|" + "b".
    // JSON.stringify(array) prevents this.
    const fp1 = intakeFingerprint({ ...baseIntake, businessName: "A|B" });
    const fp2 = intakeFingerprint({ ...baseIntake, businessName: "A", firstName: "B" });
    expect(fp1).not.toBe(fp2);
  });
});

describe("intakeFingerprint — ctaSource excluded", () => {
  it("does NOT change when ctaSource differs (attribution excluded)", () => {
    // ctaSource is not a param of intakeFingerprint anymore, so the same
    // identity + consent always produces the same fingerprint regardless of
    // which CTA link the visitor used to enter the journey.
    expect(intakeFingerprint(baseIntake)).toBe(intakeFingerprint({ ...baseIntake }));
  });
});

describe("completionFingerprint — canonicalization", () => {
  it("is deterministic for identical input", () => {
    expect(completionFingerprint(baseCompletion)).toBe(
      completionFingerprint({ ...baseCompletion }),
    );
  });

  it("is case-insensitive for identity", () => {
    expect(
      completionFingerprint({
        ...baseCompletion,
        businessName: "  TEST CLINIC  ",
        firstName: "  jane  ",
        email: "  JANE@example.com  ",
      }),
    ).toBe(completionFingerprint(baseCompletion));
  });

  it("changes when a funnel metric value changes", () => {
    const fp1 = completionFingerprint(baseCompletion);
    const fp2 = completionFingerprint({
      ...baseCompletion,
      mBooked: metric("30", "exact"),
    });
    expect(fp1).not.toBe(fp2);
  });

  it("changes when a metric quality changes", () => {
    const fp1 = completionFingerprint(baseCompletion);
    const fp2 = completionFingerprint({
      ...baseCompletion,
      mBooked: metric("28", "estimate"),
    });
    expect(fp1).not.toBe(fp2);
  });

  it("changes when industry changes", () => {
    const fp1 = completionFingerprint(baseCompletion);
    const fp2 = completionFingerprint({ ...baseCompletion, industry: "home-services" });
    expect(fp1).not.toBe(fp2);
  });

  it("is stable regardless of timestamp (timestamp excluded)", () => {
    expect(completionFingerprint(baseCompletion)).toBe(completionFingerprint(baseCompletion));
  });

  it("changes when free-check numbers change", () => {
    const fp1 = completionFingerprint(baseCompletion);
    const fp2 = completionFingerprint({ ...baseCompletion, leads: "90" });
    expect(fp1).not.toBe(fp2);
  });
});

describe("completionFingerprint — ctaSource excluded", () => {
  it("does NOT change when ctaSource would differ (attribution excluded)", () => {
    // ctaSource is not a param of completionFingerprint anymore.
    expect(completionFingerprint(baseCompletion)).toBe(
      completionFingerprint({ ...baseCompletion }),
    );
  });
});

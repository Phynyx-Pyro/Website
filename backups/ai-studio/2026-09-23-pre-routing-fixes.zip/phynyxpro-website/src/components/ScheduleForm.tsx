import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, Check, Clock, AlertCircle, RotateCcw, Loader2 } from "lucide-react";
import {
  CALENDAR_ID,
  LOCATION_ID,
  CUSTOM_FIELDS,
  fetchCalendarFreeSlots,
  slotsToSet,
  submitCalendarBooking,
  type FreeSlotsResponse,
  type BookingResult,
} from "../lib/calendar";
import { trackGrowthCallBookingIntake } from "../lib/growth-snapshot-tracking";

/**
 * Custom scheduling form + slot-selection UI.
 * Native-looking (no iframe, no embedded calendar).
 * Wired to the existing "Phynyx Website - Assessment" calendar behind the branded UI.
 */

type DayGroup = { dateKey: string; label: string; sub: string; slots: string[] };

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/** Format an ISO slot into a friendly time label in the visitor's timezone. */
function formatTimeLabel(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  } catch {
    return iso;
  }
}

/** Convert the raw free-slots response into ordered day groups. */
function toDayGroups(slots: FreeSlotsResponse): DayGroup[] {
  return Object.entries(slots)
    .filter(([, v]) => v?.slots?.length)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([dateKey, v]) => {
      const d = new Date(`${dateKey}T00:00:00`);
      const label = WEEKDAYS[d.getDay()] ?? "";
      const sub = d.toLocaleDateString([], { month: "short", day: "numeric" });
      return { dateKey, label, sub, slots: v.slots };
    });
}

// RFC 5322-ish email pattern — sufficient for client-side validation.
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Accepts +, (), -, spaces, and 7+ digits.
const PHONE_RE = /^[+()\-\s\d]{7,}$/;

export function ScheduleForm({ ctaSource = "schedule-page" }: { ctaSource?: string }) {
  const [step, setStep] = useState<"contact" | "slot" | "done">("contact");
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  // contact fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [business, setBusiness] = useState("");
  const [consent, setConsent] = useState(false);

  // inline validation (shown after blur/submit attempt)
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [submitAttempted, setSubmitAttempted] = useState(false);

  // availability state
  const [dayGroups, setDayGroups] = useState<DayGroup[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsError, setSlotsError] = useState<string | null>(null);

  // booking state
  const [booking, setBooking] = useState(false);
  const [bookingResult, setBookingResult] = useState<BookingResult | null>(null);

  // Early contact-capture intake state (Growth Call Booking Intake).
  // Fired on "Choose My Appointment Time" BEFORE slot selection so a lead who
  // abandons slot selection is still captured. Awaited; preserves input + retry
  // on network/non-2xx failure.
  const [intakeSubmitting, setIntakeSubmitting] = useState(false);
  const [intakeError, setIntakeError] = useState<string | null>(null);

  // Fingerprint of the last successfully-submitted contact payload, so
  // edit-back-and-forward with UNCHANGED details does not emit twice.
  // Changed details produce a new fingerprint and may submit a new event.
  const intakeFingerprintRef = useRef<string | null>(null);
  // Guard against double-click while a submission is pending.
  const intakePendingRef = useRef(false);

  /** Build a stable fingerprint of the contact details for dedup. */
  const contactFingerprint = (n: string, e: string, p: string, b: string, c: boolean) =>
    [n.trim().toLowerCase(), e.trim().toLowerCase(), p.trim(), b.trim().toLowerCase(), c].join("|");

  /**
   * Stable booking-attempt/session key, created once per form mount and reused
   * across every retry. The provider does not document server-side idempotency,
   * so this is sent as a best-effort dedup key only — each POST is still a
   * distinct attempt unless the provider confirms deduplication.
   */
  const sessionIdRef = useRef<string>("");
  if (!sessionIdRef.current) {
    sessionIdRef.current = crypto.randomUUID();
  }

  const emailValid = EMAIL_RE.test(email.trim());
  const phoneValid = PHONE_RE.test(phone.trim());
  const contactValid =
    name.trim().length > 0 && business.trim().length > 0 && emailValid && phoneValid;

  // Split a full name into first/last for the booking payload.
  const nameParts = useMemo(() => {
    const trimmed = name.trim();
    const idx = trimmed.indexOf(" ");
    if (idx === -1) return { firstName: trimmed, lastName: "" };
    return { firstName: trimmed.slice(0, idx), lastName: trimmed.slice(idx + 1) };
  }, [name]);

  // Fetch availability for the next ~14 days when entering the slot step.
  useEffect(() => {
    if (step !== "slot") return;
    let cancelled = false;

    const load = async () => {
      setSlotsLoading(true);
      setSlotsError(null);
      try {
        const now = new Date();
        const startMs = now.getTime();
        const endMs = startMs + 14 * 24 * 60 * 60 * 1000;
        const data = await fetchCalendarFreeSlots(CALENDAR_ID, startMs, endMs);
        if (!cancelled) {
          setDayGroups(toDayGroups(data));
          if (Object.keys(data).length === 0) {
            setSlotsError(
              "No open times were found in the next two weeks. Please check back soon.",
            );
          }
        }
      } catch {
        if (!cancelled) {
          setSlotsError("We couldn't load available times right now. Please try again.");
        }
      } finally {
        if (!cancelled) setSlotsLoading(false);
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [step]);

  const selectedGroup = dayGroups.find((g) => g.dateKey === selectedDay) ?? null;

  const handleConfirm = async () => {
    if (!selectedTime) return;
    setBooking(true);
    setBookingResult(null);

    try {
      // 1) RECHECK AT COMMIT — re-fetch current availability and require the
      //    exact selected ISO slot to still be open before POSTing a booking.
      const now = new Date();
      const startMs = now.getTime();
      const endMs = startMs + 14 * 24 * 60 * 60 * 1000;
      const fresh = await fetchCalendarFreeSlots(CALENDAR_ID, startMs, endMs);
      const stillOpen = slotsToSet(fresh).has(selectedTime);

      if (!stillOpen) {
        // Slot is no longer available — refresh the visible list, clear the
        // selection, and show a real unavailable/retry state. No POST made.
        setDayGroups(toDayGroups(fresh));
        setSelectedTime(null);
        setSelectedDay(null);
        setBookingResult({
          ok: false,
          reason: "unavailable",
          message: "That time was just taken. Please choose another slot.",
        });
        setBooking(false);
        return;
      }

      // 2) Re-validate contact details right before submission.
      if (!contactValid) {
        setBooking(false);
        setStep("contact");
        setSubmitAttempted(true);
        return;
      }

      // 3) Submit with the stable session key (reused across retries).
      // Unified with Growth Snapshot intake: Consented/Not consented vocabulary.
      // Only appointment-text consent is sent from /schedule — no marketing or
      // AI voice consent fields are written here.
      const customFields = [
        {
          id: CUSTOM_FIELDS.appointmentTextConsent,
          field_value: consent ? "Consented" : "Not consented",
        },
        { id: CUSTOM_FIELDS.ctaSource, field_value: ctaSource },
      ];

      const result = await submitCalendarBooking({
        locationId: LOCATION_ID,
        calendarId: CALENDAR_ID,
        firstName: nameParts.firstName,
        lastName: nameParts.lastName,
        email: email.trim(),
        phone: phone.trim(),
        companyName: business.trim(),
        selectedSlot: selectedTime,
        sessionId: sessionIdRef.current,
        customFields,
      });

      setBookingResult(result);

      if (result.ok) {
        setStep("done");
      } else if (result.reason === "unavailable") {
        // Slot conflict reported by provider — refresh + force a re-pick.
        setSelectedTime(null);
        setSelectedDay(null);
        setStep("slot");
      }
    } catch {
      setBookingResult({
        ok: false,
        reason: "error",
        message: "We couldn't reach the booking service. Please try again.",
      });
    } finally {
      setBooking(false);
    }
  };

  const showFieldError = (key: string) =>
    (touched[key] || submitAttempted) &&
    !(key === "email"
      ? emailValid
      : key === "phone"
        ? phoneValid
        : key === "name"
          ? name.trim().length > 0
          : key === "business"
            ? business.trim().length > 0
            : true);

  return (
    <div className="w-full max-w-[548px] rounded-2xl bg-white border border-black/10 shadow-2xl overflow-hidden">
      <div className="p-6 lg:p-8">
        {/* STEP 1: CONTACT */}
        {step === "contact" && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setSubmitAttempted(true);
              if (!contactValid) return;

              // Guard double-click while a submission is pending.
              if (intakePendingRef.current || intakeSubmitting) return;

              const fp = contactFingerprint(name, email, phone, business, consent);
              // Skip re-emitting if the same contact payload already succeeded.
              if (intakeFingerprintRef.current === fp) {
                setIntakeError(null);
                setStep("slot");
                return;
              }

              intakePendingRef.current = true;
              setIntakeSubmitting(true);
              setIntakeError(null);

              const result = await trackGrowthCallBookingIntake({
                firstName: nameParts.firstName,
                lastName: nameParts.lastName,
                email: email.trim(),
                phone: phone.trim(),
                businessName: business.trim(),
                appointmentTexts: consent,
                ctaSource,
              });

              intakePendingRef.current = false;
              setIntakeSubmitting(false);

              if (!result.ok) {
                // Preserve input; show retry. Do NOT advance to slot step.
                setIntakeError(result.message);
                return;
              }

              // Success — record fingerprint so unchanged details don't re-emit.
              intakeFingerprintRef.current = fp;
              setStep("slot");
            }}
            className="space-y-5"
            noValidate
          >
            <div>
              {/* Source heading ~24px, H2 semantics */}
              <h2 className="text-[24px] font-bold text-ink leading-tight">
                Tell us where to send the invite.
              </h2>
              <p className="mt-1.5 text-sm text-warm leading-relaxed">
                Four details, then choose your appointment time.
              </p>
            </div>

            <div className="space-y-5" style={{ paddingTop: "17px" }}>
              <Field
                id="schedule-name"
                label="Name"
                required
                error={showFieldError("name") ? "Please enter your name." : undefined}
              >
                <input
                  id="schedule-name"
                  type="text"
                  required
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                  className={inputClass(showFieldError("name"))}
                  placeholder="Your name"
                  aria-invalid={showFieldError("name") || undefined}
                />
              </Field>
              <Field
                id="schedule-email"
                label="Email"
                required
                error={showFieldError("email") ? "Please enter a valid email address." : undefined}
              >
                <input
                  id="schedule-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                  className={inputClass(showFieldError("email"))}
                  placeholder="you@practice.com"
                  aria-invalid={showFieldError("email") || undefined}
                />
              </Field>
              <Field
                id="schedule-phone"
                label="Mobile number"
                required
                error={showFieldError("phone") ? "Please enter a valid mobile number." : undefined}
              >
                <input
                  id="schedule-phone"
                  type="tel"
                  required
                  autoComplete="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, phone: true }))}
                  className={inputClass(showFieldError("phone"))}
                  placeholder="(555) 123-4567"
                  aria-invalid={showFieldError("phone") || undefined}
                />
              </Field>
              <Field
                id="schedule-business"
                label="Business / practice name"
                required
                error={showFieldError("business") ? "Please enter your business name." : undefined}
              >
                <input
                  id="schedule-business"
                  type="text"
                  required
                  autoComplete="organization"
                  value={business}
                  onChange={(e) => setBusiness(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, business: true }))}
                  className={inputClass(showFieldError("business"))}
                  placeholder="Practice name"
                  aria-invalid={showFieldError("business") || undefined}
                />
              </Field>
            </div>

            {/* Consent — simple unchecked checkbox with disclosure text on white (no tinted panel) */}
            <label
              className="flex items-start gap-3 cursor-pointer pt-2"
              style={{ paddingBottom: "13px" }}
            >
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-1 w-4 h-4 accent-phoenix shrink-0"
              />
              <span className="text-[11.5px] text-warm leading-snug">
                I agree to receive appointment confirmations and reminders by text from PhynyxPro.
                Message frequency varies. Message and data rates may apply. Reply STOP to opt out or
                HELP for help.
              </span>
            </label>

            {intakeError && (
              <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-bold text-ink">Couldn't save your details</p>
                  <p className="text-[12px] text-warm mt-1 leading-relaxed">{intakeError}</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={!contactValid || intakeSubmitting}
              className="w-full px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/30 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
            >
              {intakeSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Saving your details…
                </>
              ) : (
                <>
                  Choose My Appointment Time
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <p className="text-[11px] text-warm leading-relaxed pt-3 border-t border-black/5">
              No revenue, ad-budget, capacity, or funnel questions before booking.
            </p>
          </form>
        )}

        {/* STEP 2: SLOT SELECTION — real availability */}
        {step === "slot" && (
          <div className="space-y-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                Choose the time that works for you
              </p>

              {slotsLoading && (
                <div className="flex items-center gap-2 text-sm text-warm py-6">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Loading available times…
                </div>
              )}

              {slotsError && !slotsLoading && (
                <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-bold text-ink">Couldn't load times</p>
                    <p className="text-[12px] text-warm mt-1 leading-relaxed">{slotsError}</p>
                    <button
                      type="button"
                      onClick={() => setStep("slot")}
                      className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Retry
                    </button>
                  </div>
                </div>
              )}

              {!slotsLoading && !slotsError && dayGroups.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {dayGroups.map((g) => (
                    <button
                      key={g.dateKey}
                      type="button"
                      onClick={() => {
                        setSelectedDay(g.dateKey);
                        setSelectedTime(null);
                      }}
                      className={`rounded-xl border p-3 text-center transition-colors ${
                        selectedDay === g.dateKey
                          ? "border-phoenix bg-phoenix/5"
                          : "border-black/10 bg-white hover:border-phoenix/40"
                      }`}
                    >
                      <p className="text-[11px] font-bold uppercase tracking-wider text-warm">
                        {g.label}
                      </p>
                      <p className="text-sm font-bold text-ink mt-0.5">{g.sub}</p>
                    </button>
                  ))}
                </div>
              )}

              {!slotsLoading && !slotsError && dayGroups.length === 0 && (
                <p className="text-sm text-warm py-4">
                  No open times were found in the next two weeks. Please check back soon.
                </p>
              )}
            </div>

            {selectedGroup && (
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                  Available times — {selectedGroup.label} {selectedGroup.sub}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {selectedGroup.slots.map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setSelectedTime(t)}
                      className={`rounded-lg border px-3 py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                        selectedTime === t
                          ? "border-phoenix bg-phoenix text-white"
                          : "border-black/10 bg-white text-ink hover:border-phoenix/40"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      {formatTimeLabel(t)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Booking failure banner (unavailable or error) */}
            {bookingResult && !bookingResult.ok && (
              <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-bold text-ink">
                    {bookingResult.reason === "unavailable"
                      ? "That time is no longer available"
                      : "Booking didn't go through"}
                  </p>
                  <p className="text-[12px] text-warm mt-1 leading-relaxed">
                    {bookingResult.message}
                  </p>
                  <button
                    type="button"
                    onClick={() => setBookingResult(null)}
                    className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Choose another time
                  </button>
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-black/10">
              <button
                type="button"
                onClick={() => {
                  setStep("contact");
                  setSelectedDay(null);
                  setSelectedTime(null);
                  setBookingResult(null);
                }}
                className="text-xs font-semibold text-warm hover:text-ink underline"
              >
                ← Edit contact details
              </button>
              <button
                type="button"
                disabled={!selectedTime || booking}
                onClick={handleConfirm}
                className="w-full sm:w-auto px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/30 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
              >
                {booking ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Confirming…
                  </>
                ) : (
                  <>
                    Confirm
                    {selectedGroup && selectedTime
                      ? ` · ${selectedGroup.label} ${formatTimeLabel(selectedTime)}`
                      : ""}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: DONE — only after a confirmed appointment ID + booked start */}
        {step === "done" && bookingResult?.ok && (
          <div className="text-center py-8">
            <div className="w-14 h-14 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto">
              <Check className="w-7 h-7" />
            </div>
            <h2 className="mt-5 text-xl font-bold text-ink">You're on the calendar</h2>
            <p className="mt-2 text-sm text-warm leading-relaxed max-w-md mx-auto">
              We'll send a confirmation to <span className="font-semibold text-ink">{email}</span>{" "}
              {consent && (
                <>
                  and text <span className="font-semibold text-ink">{phone}</span>{" "}
                </>
              )}
              for your booked time
              {selectedGroup && selectedTime ? (
                <>
                  {" "}
                  (
                  <span className="font-semibold text-ink">
                    {selectedGroup.label} {selectedGroup.sub} at {formatTimeLabel(selectedTime)}
                  </span>
                  )
                </>
              ) : null}
              .
            </p>
            <p className="mt-3 text-[11px] text-warm/70 leading-relaxed">
              Appointment reference: {bookingResult.appointmentId}
            </p>
            <button
              type="button"
              onClick={() => {
                setStep("contact");
                setSelectedDay(null);
                setSelectedTime(null);
                setName("");
                setEmail("");
                setPhone("");
                setBusiness("");
                setConsent(false);
                setBookingResult(null);
              }}
              className="mt-6 text-xs font-semibold text-warm hover:text-ink underline"
            >
              Book another time
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const inputClass = (hasError?: boolean) =>
  `w-full px-4 py-3.5 rounded-lg border text-sm focus:outline-none focus:border-phoenix bg-ivory h-[53px] ${
    hasError ? "border-phoenix ring-1 ring-phoenix" : "border-black/15"
  }`;

function Field({
  id,
  label,
  required,
  error,
  children,
}: {
  id: string;
  label: string;
  required?: boolean;
  // Use `string | undefined` (not `?`) so callers may pass `undefined`
  // explicitly under `exactOptionalPropertyTypes`.
  error: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1.5">
        {label} {required && <span className="text-phoenix">*</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} className="mt-1 text-[11px] text-phoenix" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

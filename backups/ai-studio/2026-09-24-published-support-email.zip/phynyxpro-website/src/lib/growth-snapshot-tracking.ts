// Form tracking helpers for the Growth Snapshot journey.
//
// Two distinct tracked forms:
//  1. "Get My Free Growth Snapshot Intake" — first contact checkpoint (awaited).
//  2. "Growth Snapshot Assessment Completed" — final completion (awaited, returns success/error).
//
// The completion form is NEVER fired on the first contact step, and the intake
// form is NEVER fired on completion. Consent fields are only sent on intake.

type StandardTrackingFieldKey = string;
type RegisteredCustomFieldId = string;
type TrackingCustomField = { value?: unknown; label: string };
type TrackingFileField = { file?: File; label: string };
type TrackingImageDataField = { dataUrl?: string; label: string };

const TRACKING_ENDPOINT = "https://backend.leadconnectorhq.com/external-tracking/events";

// Integration IDs from the connected form-tracking integration.
export const GROWTH_SNAPSHOT_TRACKING_ID = "tk_82ef560d06d74a06987702f8cfae1770";
export const GROWTH_SNAPSHOT_LOCATION_ID = "DsRnzA2tcoiwklSgjBtR";
export const GROWTH_SNAPSHOT_PROJECT_ID = "1789733833642057228";

// ---- Intake form (first contact checkpoint) ----
export const GROWTH_SNAPSHOT_INTAKE_FORM_ID = "get-my-free-growth-snapshot-intake";
export const GROWTH_SNAPSHOT_INTAKE_FORM_NAME = "Get My Free Growth Snapshot Intake";

// ---- Completion form (final submit) ----
export const GROWTH_SNAPSHOT_COMPLETION_FORM_ID = "growth-snapshot-assessment-completed";
export const GROWTH_SNAPSHOT_COMPLETION_FORM_NAME = "Growth Snapshot Assessment Completed";

// ---- Growth Call Booking Intake form (/schedule early contact capture) ----
// Fired on "Choose My Appointment Time" BEFORE slot selection, so a lead who
// abandons slot selection is still captured. Distinct from the snapshot
// intake/completion forms — never reuses those form IDs.
export const GROWTH_CALL_BOOKING_INTAKE_FORM_ID = "growth-call-booking-intake";
export const GROWTH_CALL_BOOKING_INTAKE_FORM_NAME = "Growth Call Booking Intake";

// Intake custom-field IDs (consent + attribution).
// Unified with /schedule: appointment-text consent and CTA source use the
// SAME field IDs and value vocabulary across both surfaces.
export const CF_APPOINTMENT_SMS_CONSENT = "xNnkLEk8FCUI7XSbeElK";
export const CF_MARKETING_SMS_CONSENT = "L9qgFekI6X0yft7rmv50";
export const CF_AI_VOICE_CONSENT = "0NLcCYvWRdO55I3SbsAK";
export const CF_CTA_SOURCE = "CVSuXDCFaJslF3bIuRvI";

// Completion custom-field IDs (registered via register_custom_field).
export const CF_SNAPSHOT_STATUS = "eWAPSJxjIdKGRYl1tAsf";
export const CF_SNAPSHOT_COMPLETED_AT = "gTAfWVxXl5wwsj0nCLnS";
export const CF_SNAPSHOT_SUMMARY = "0e6E7g2puq4ggIVaHjra";
export const CF_SNAPSHOT_INDUSTRY = "osRX36q241vxO4b83yvg";
export const CF_SNAPSHOT_PRIMARY_CHALLENGE = "IWBm4n8GZAfCglUGTShH";

const postTrackingEvent = (
  trackingPayload: Record<string, unknown> & {
    formData: Record<StandardTrackingFieldKey, unknown>;
    formLabels: Record<StandardTrackingFieldKey, string>;
  },
  options: {
    customFields?: Record<RegisteredCustomFieldId, TrackingCustomField>;
    fileFields?: Record<RegisteredCustomFieldId, TrackingFileField>;
    imageDataFields?: Record<RegisteredCustomFieldId, TrackingImageDataField>;
  } = {},
) => {
  const { customFields = {}, fileFields = {}, imageDataFields = {} } = options;
  const eventPayload = {
    ...trackingPayload,
    formData: { ...trackingPayload.formData },
    formLabels: { ...trackingPayload.formLabels },
  };
  const body = new FormData();

  for (const [key, field] of Object.entries(customFields)) {
    if (field.value === undefined) continue;
    eventPayload.formData[key] = field.value;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(imageDataFields)) {
    const dataUrl = field.dataUrl;
    if (!dataUrl) continue;
    if (!dataUrl.startsWith("data:image/")) {
      throw new Error("Image data field must be a data:image/* base64 string");
    }
    eventPayload.formData[key] = dataUrl;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(fileFields)) {
    const file = field.file;
    if (!file) continue;
    if (file.size > 50 * 1024 * 1024) {
      throw new Error("File must be 50 MB or smaller");
    }
    eventPayload.formData[key] = {
      filename: file.name,
      size: file.size,
      type: file.type || "application/octet-stream",
    };
    eventPayload.formLabels[key] = field.label;
    body.append(key, file, file.name);
  }

  for (const key of Object.keys(eventPayload.formData)) {
    eventPayload.formLabels[key] ||= key;
  }

  body.append("event", JSON.stringify(eventPayload));

  return fetch(TRACKING_ENDPOINT, {
    method: "POST",
    headers: {
      version: "2021-07-28",
    },
    body,
  });
};

export interface GrowthSnapshotIntake {
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  appointmentTexts: boolean;
  marketingTexts: boolean;
  aiPhoneCalls: boolean;
  ctaSource: string;
}

export type TrackingResult = { ok: true } | { ok: false; message: string };

/**
 * Fires the native form-tracking event for the growth snapshot INTAKE contact
 * checkpoint. Awaited — returns a real success/error result so the UI can
 * show retry on failure and only advance after a confirmed 2xx. Never
 * silently fire-and-forgets.
 */
export async function trackGrowthSnapshotIntake(
  data: GrowthSnapshotIntake,
): Promise<TrackingResult> {
  if (typeof window === "undefined") {
    return { ok: false, message: "Tracking is only available in the browser." };
  }

  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: GROWTH_SNAPSHOT_INTAKE_FORM_ID,
    formData: {
      first_name: data.firstName,
      last_name: data.lastName,
      email: data.email,
      phone: data.phone,
      organization: data.businessName,
    },
    formLabels: {
      first_name: "First Name",
      last_name: "Last Name",
      email: "Work Email",
      phone: "Phone",
      organization: "Business Name",
    },
    url: window.location.href,
    title: document.title,
    path: window.location.pathname,
    userAgent: navigator.userAgent,
    trackingId: GROWTH_SNAPSHOT_TRACKING_ID,
    locationId: GROWTH_SNAPSHOT_LOCATION_ID,
    projectId: GROWTH_SNAPSHOT_PROJECT_ID,
    sessionId: crypto.randomUUID(),
    properties: {
      deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
      source: "ai_studio",
      projectId: GROWTH_SNAPSHOT_PROJECT_ID,
      formName: GROWTH_SNAPSHOT_INTAKE_FORM_NAME,
    },
  };

  try {
    const response = await postTrackingEvent(trackingPayload, {
      customFields: {
        [CF_APPOINTMENT_SMS_CONSENT]: {
          value: data.appointmentTexts ? "Consented" : "Not consented",
          label: "Appointment texts",
        },
        [CF_MARKETING_SMS_CONSENT]: {
          value: data.marketingTexts ? "Consented" : "Not consented",
          label: "Marketing texts",
        },
        [CF_AI_VOICE_CONSENT]: {
          value: data.aiPhoneCalls ? "Consented" : "Not consented",
          label: "AI phone calls",
        },
        [CF_CTA_SOURCE]: {
          value: data.ctaSource,
          label: "CTA Source",
        },
      },
    });

    if (!response.ok) {
      return {
        ok: false,
        message: `Your details could not be saved (status ${response.status}). Your entries are preserved — please retry.`,
      };
    }
    return { ok: true };
  } catch {
    return {
      ok: false,
      message: "We couldn't reach the snapshot service. Your entries are preserved — please retry.",
    };
  }
}

export interface GrowthSnapshotCompletion {
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  ctaSource: string;
  // Completion-only custom fields (no consent resend).
  status: string; // "Completed"
  completedAt: string; // ISO timestamp
  summary: string; // readable long text
  industry: string;
  primaryChallenge: string;
}

/**
 * Fires the native form-tracking event for the growth snapshot COMPLETION.
 * Awaited — returns a real success/error result so the UI can show retry on
 * failure and never falsely claim a CRM save. Does NOT resend consent fields
 * and does NOT fire the intake form.
 */
export async function trackGrowthSnapshotCompletion(
  data: GrowthSnapshotCompletion,
): Promise<TrackingResult> {
  if (typeof window === "undefined") {
    return { ok: false, message: "Tracking is only available in the browser." };
  }

  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: GROWTH_SNAPSHOT_COMPLETION_FORM_ID,
    formData: {
      first_name: data.firstName,
      last_name: data.lastName,
      email: data.email,
      phone: data.phone,
      organization: data.businessName,
    },
    formLabels: {
      first_name: "First Name",
      last_name: "Last Name",
      email: "Work Email",
      phone: "Phone",
      organization: "Business Name",
    },
    url: window.location.href,
    title: document.title,
    path: window.location.pathname,
    userAgent: navigator.userAgent,
    trackingId: GROWTH_SNAPSHOT_TRACKING_ID,
    locationId: GROWTH_SNAPSHOT_LOCATION_ID,
    projectId: GROWTH_SNAPSHOT_PROJECT_ID,
    sessionId: crypto.randomUUID(),
    properties: {
      deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
      source: "ai_studio",
      projectId: GROWTH_SNAPSHOT_PROJECT_ID,
      formName: GROWTH_SNAPSHOT_COMPLETION_FORM_NAME,
    },
  };

  try {
    const response = await postTrackingEvent(trackingPayload, {
      customFields: {
        [CF_SNAPSHOT_STATUS]: { value: data.status, label: "Snapshot Status" },
        [CF_SNAPSHOT_COMPLETED_AT]: { value: data.completedAt, label: "Snapshot Completed At" },
        [CF_SNAPSHOT_SUMMARY]: { value: data.summary, label: "Snapshot Summary" },
        [CF_SNAPSHOT_INDUSTRY]: { value: data.industry, label: "Snapshot Industry" },
        [CF_SNAPSHOT_PRIMARY_CHALLENGE]: {
          value: data.primaryChallenge,
          label: "Snapshot Primary Challenge",
        },
      },
    });

    if (!response.ok) {
      return {
        ok: false,
        message: `The snapshot could not be saved (status ${response.status}). Your entries are preserved — please retry.`,
      };
    }
    return { ok: true };
  } catch {
    return {
      ok: false,
      message: "We couldn't reach the snapshot service. Your entries are preserved — please retry.",
    };
  }
}

export interface GrowthCallBookingIntake {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  businessName: string;
  appointmentTexts: boolean;
  ctaSource: string;
}

/**
 * Fires the native form-tracking event for the /schedule Growth Call Booking
 * Intake — the EARLY contact capture on "Choose My Appointment Time", before
 * slot selection. Awaited — returns a real success/error result so the UI can
 * preserve input + show retry on network/non-2xx failure.
 *
 * Sends ONLY appointment-text consent (Consented/Not consented) and CTA Source.
 * NEVER sends marketing or AI voice consent from /schedule. NEVER uses the
 * snapshot intake or completion form IDs.
 *
 * This event does NOT claim a booking — it only captures the lead's contact
 * details so a lead who abandons slot selection is not lost.
 */
export async function trackGrowthCallBookingIntake(
  data: GrowthCallBookingIntake,
): Promise<TrackingResult> {
  if (typeof window === "undefined") {
    return { ok: false, message: "Tracking is only available in the browser." };
  }

  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: GROWTH_CALL_BOOKING_INTAKE_FORM_ID,
    formData: {
      first_name: data.firstName,
      last_name: data.lastName,
      email: data.email,
      phone: data.phone,
      organization: data.businessName,
    },
    formLabels: {
      first_name: "First Name",
      last_name: "Last Name",
      email: "Email",
      phone: "Mobile number",
      organization: "Business / practice name",
    },
    url: window.location.href,
    title: document.title,
    path: window.location.pathname,
    userAgent: navigator.userAgent,
    trackingId: GROWTH_SNAPSHOT_TRACKING_ID,
    locationId: GROWTH_SNAPSHOT_LOCATION_ID,
    projectId: GROWTH_SNAPSHOT_PROJECT_ID,
    sessionId: crypto.randomUUID(),
    properties: {
      deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
      source: "ai_studio",
      projectId: GROWTH_SNAPSHOT_PROJECT_ID,
      formName: GROWTH_CALL_BOOKING_INTAKE_FORM_NAME,
    },
  };

  try {
    const response = await postTrackingEvent(trackingPayload, {
      customFields: {
        [CF_APPOINTMENT_SMS_CONSENT]: {
          value: data.appointmentTexts ? "Consented" : "Not consented",
          label: "Appointment texts",
        },
        [CF_CTA_SOURCE]: {
          value: data.ctaSource,
          label: "CTA Source",
        },
      },
    });

    if (!response.ok) {
      return {
        ok: false,
        message: `Your details could not be saved (status ${response.status}). Your entries are preserved — please retry.`,
      };
    }
    return { ok: true };
  } catch {
    return {
      ok: false,
      message: "We couldn't reach the booking service. Your entries are preserved — please retry.",
    };
  }
}

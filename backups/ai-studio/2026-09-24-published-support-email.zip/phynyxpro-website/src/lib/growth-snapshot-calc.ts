// Growth Snapshot calculations, persistence, and download helpers.
// Pure functions shared by the GrowthAssessmentFunnel component.

export type DataQuality = "exact" | "estimate" | "not-tracked";

export interface FunnelMetric {
  value: string;
  quality: DataQuality;
}

export const EMPTY_METRIC: FunnelMetric = { value: "", quality: "not-tracked" };

// sessionStorage persistence (same-browser, 24h expiry). No personal data in URL.
const STORAGE_KEY = "phynyx-growth-snapshot-v1";
const STORAGE_TTL_MS = 24 * 60 * 60 * 1000;

export interface PersistedState {
  version: number;
  savedAt: number;
  step: string;
  leads: string;
  booked: string;
  showed: string;
  businessName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  appointmentTexts: boolean;
  marketingTexts: boolean;
  aiPhoneCalls: boolean;
  practiceName: string;
  role: string;
  locations: string;
  adSpend: string;
  avgStartValue: string;
  industry: string;
  mInquiries: FunnelMetric;
  mContacted: FunnelMetric;
  mBooked: FunnelMetric;
  mConfirmed: FunnelMetric;
  mShowed: FunnelMetric;
  mStarted: FunnelMetric;
  mAdSpend: FunnelMetric;
  mAvgStartValue: FunnelMetric;
}

export function loadPersisted(): Partial<PersistedState> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedState;
    if (!parsed || typeof parsed !== "object") return null;
    if (Date.now() - (parsed.savedAt ?? 0) > STORAGE_TTL_MS) {
      window.sessionStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function persistState(state: PersistedState) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore quota errors
  }
}

export function clearPersisted() {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

/**
 * Parse a count metric value to a non-negative INTEGER, or null if
 * blank/invalid/not-tracked. Rejects non-integer input (e.g. 12.5).
 */
export function metricNum(m: FunnelMetric): number | null {
  if (m.quality === "not-tracked") return null;
  const v = m.value.trim();
  if (v === "") return null;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return null;
  if (!Number.isInteger(n)) return null;
  return n;
}

/**
 * Parse a money/value metric to a non-negative DECIMAL, or null if
 * blank/invalid/not-tracked. Used for ad spend and average start value.
 * Uses Number() (not parseFloat) so malformed strings like "abc" or
 * "12abc" are rejected rather than partially parsed.
 */
export function metricFloat(m: FunnelMetric): number | null {
  if (m.quality === "not-tracked") return null;
  const v = m.value.trim();
  if (v === "") return null;
  // Number("") === 0, so guard blank explicitly above. Number("12abc") === NaN.
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return null;
  return n;
}

/** Parse a free-check field to a non-negative integer, or null if blank. */
export function freeNum(v: string): number | null {
  const t = v.trim();
  if (t === "") return null;
  const n = Number(t);
  if (!Number.isFinite(n) || n < 0) return null;
  if (!Number.isInteger(n)) return null;
  return n;
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/**
 * Safe percentage: returns null unless both values are finite, the
 * numerator is non-negative, the denominator is > 0, AND the numerator
 * does not exceed the denominator. Invalid/inconsistent pairs return null
 * so the UI can show "Not enough data" or an actionable correction rather
 * than a rate > 100%.
 */
export function pct(n: number, d: number): number | null {
  if (!Number.isFinite(n) || !Number.isFinite(d)) return null;
  if (n < 0 || d <= 0) return null;
  if (n > d) return null;
  return round1((n / d) * 100);
}

export interface RateResult {
  label: string;
  from: string;
  to: string;
  rate: number | null;
}

/**
 * Build the five adjacent conversion rates. Each pair returns null if
 * EITHER input is null (unknown is NOT zero). pct() additionally guards
 * numerator>denominator, so inconsistent sequences yield null rates.
 */
export function buildRates(metrics: {
  inquiries: number | null;
  contacted: number | null;
  booked: number | null;
  confirmed: number | null;
  showed: number | null;
  started: number | null;
}): RateResult[] {
  const { inquiries, contacted, booked, confirmed, showed, started } = metrics;
  return [
    {
      label: "Contacted Rate",
      from: "Inquiries",
      to: "Contacted",
      rate: inquiries === null || contacted === null ? null : pct(contacted, inquiries),
    },
    {
      label: "Booked Rate",
      from: "Contacted",
      to: "Booked",
      rate: contacted === null || booked === null ? null : pct(booked, contacted),
    },
    {
      label: "Confirmed Rate",
      from: "Booked",
      to: "Confirmed",
      rate: booked === null || confirmed === null ? null : pct(confirmed, booked),
    },
    {
      label: "Show Rate",
      from: "Confirmed",
      to: "Showed",
      rate: confirmed === null || showed === null ? null : pct(showed, confirmed),
    },
    {
      label: "Start Rate",
      from: "Showed",
      to: "Started",
      rate: showed === null || started === null ? null : pct(started, showed),
    },
  ];
}

export function costPer(n: number | null, spend: number | null): number | null {
  if (n === null || spend === null || n <= 0) return null;
  return round1(spend / n);
}

export function formatMoney(n: number | null): string {
  if (n === null) return "—";
  if (n >= 100) return `$${Math.round(n).toLocaleString()}`;
  return `$${n.toFixed(2)}`;
}

export function formatNum(n: number | null): string {
  if (n === null) return "—";
  return n.toLocaleString();
}

export function formatRate(r: number | null): string {
  if (r === null) return "—";
  return `${r}%`;
}

export interface SequenceIssue {
  field: string;
  message: string;
}

/**
 * Validate that the funnel sequence is non-increasing (each stage <= the
 * previous). Returns actionable issues for any stage that exceeds its
 * predecessor. Missing (null) values are skipped — missing data is valid.
 */
export function validateFunnelSequence(counts: {
  inquiries: number | null;
  contacted: number | null;
  booked: number | null;
  confirmed: number | null;
  showed: number | null;
  started: number | null;
}): SequenceIssue[] {
  const issues: SequenceIssue[] = [];
  const seq: [string, number | null][] = [
    ["Inquiries", counts.inquiries],
    ["Contacted", counts.contacted],
    ["Booked", counts.booked],
    ["Confirmed", counts.confirmed],
    ["Showed", counts.showed],
    ["Started", counts.started],
  ];
  for (let i = 1; i < seq.length; i++) {
    const prev = seq[i - 1];
    const cur = seq[i];
    if (!prev || !cur) continue;
    const [, prevVal] = prev;
    const [curLabel, curVal] = cur;
    if (prevVal !== null && curVal !== null && curVal > prevVal) {
      issues.push({
        field: curLabel,
        message: `${curLabel} (${curVal}) cannot exceed ${seq[i - 1]![0]} (${prevVal}). Please check your counts.`,
      });
    }
  }
  return issues;
}

/**
 * Validate the free-check three-number sequence: showed <= booked <= leads.
 */
export function validateFreeSequence(
  leads: number | null,
  booked: number | null,
  showed: number | null,
): SequenceIssue[] {
  const issues: SequenceIssue[] = [];
  if (booked !== null && leads !== null && booked > leads) {
    issues.push({
      field: "Appointments Booked",
      message: `Appointments Booked (${booked}) cannot exceed New Leads & Inquiries (${leads}). Please check your counts.`,
    });
  }
  if (showed !== null && booked !== null && showed > booked) {
    issues.push({
      field: "Showed",
      message: `Showed (${showed}) cannot exceed Appointments Booked (${booked}). Please check your counts.`,
    });
  }
  return issues;
}

export interface ScenarioResult {
  stage: string;
  from: string;
  to: string;
  currentRate: number;
  improvedRate: number;
  additionalStarts: number | null;
}

/**
 * Illustrative conservative +10pp improvement at the weakest valid handoff,
 * propagating ALL downstream conversion to starts. Capped at 100%.
 *
 * Strict requirements (no invented starts):
 *  - If ANY downstream rate (after the weakest stage) is null, return null
 *    additionalStarts ("Not enough data"). We do NOT skip/jump missing stages.
 *  - If nStarted is null, return null additionalStarts.
 *  - If any sequence inconsistency exists (a non-null rate that pct() rejected),
 *    return null — no scenario from impossible data.
 *
 * Calculation (round only the final additionalStarts to one decimal):
 *   uplift = fromCount * ((improvedRate - currentRate) / 100)
 *            * product(downstream rates / 100)
 *   additionalStarts = round1(uplift)
 * If improvedRate is already capped (currentRate >= 90), the effective gain is
 * (100 - currentRate), i.e. 5pp at 95%, not 10pp.
 */
export function computeScenario(
  rates: RateResult[],
  fromCounts: (number | null)[],
  nStarted: number | null,
): ScenarioResult | null {
  const validRates = rates.filter((r) => r.rate !== null);
  if (validRates.length === 0) return null;

  // If any rate is null but its inputs were provided (inconsistency), abort.
  // A null rate with null inputs is just "missing" — allowed for non-weakest
  // stages only if they are downstream (handled below) or upstream.
  // Detect inconsistency: a rate is null but both its fromCounts are non-null.
  for (let i = 0; i < rates.length; i++) {
    if (rates[i]!.rate === null) {
      const from = fromCounts[i] ?? null;
      const to = fromCounts[i + 1] ?? null;
      if (from !== null && to !== null) {
        // Both inputs present but rate null => inconsistent (num>den). No scenario.
        return null;
      }
    }
  }

  const weakest = validRates.reduce((min, r) => (r.rate! < min.rate! ? r : min));
  if (weakest.rate === null) return null;

  const idx = rates.findIndex((r) => r.label === weakest.label);
  const fromCount = fromCounts[idx] ?? null;
  if (fromCount === null) return null;

  const improvedRate = Math.min(100, weakest.rate + 10);
  const gain = improvedRate - weakest.rate; // 10pp, or less if capped at 100

  // ALL downstream rates must be non-null to propagate. No skipping.
  const downstream = rates.slice(idx + 1);
  for (const dr of downstream) {
    if (dr.rate === null) {
      // Missing downstream handoff — cannot project to starts.
      return {
        stage: weakest.label,
        from: weakest.from,
        to: weakest.to,
        currentRate: weakest.rate,
        improvedRate,
        additionalStarts: null,
      };
    }
  }

  if (nStarted === null) {
    return {
      stage: weakest.label,
      from: weakest.from,
      to: weakest.to,
      currentRate: weakest.rate,
      improvedRate,
      additionalStarts: null,
    };
  }

  // Product of all downstream rates (as fractions).
  let downstreamProduct = 1;
  for (const dr of downstream) {
    downstreamProduct *= dr.rate! / 100;
  }

  // Uplift in additional starts. Round ONLY the final value to one decimal.
  const uplift = fromCount * (gain / 100) * downstreamProduct;
  const additionalStarts = Math.max(0, round1(uplift));

  return {
    stage: weakest.label,
    from: weakest.from,
    to: weakest.to,
    currentRate: weakest.rate,
    improvedRate,
    additionalStarts,
  };
}

/**
 * Build the readable long-text summary for the CRM Snapshot Summary field.
 */
export function buildSummary(opts: {
  industry: string;
  businessName: string;
  practiceName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
  locations: string;
  adSpend: string;
  avgStartValue: string;
  leadsNum: number | null;
  bookedNum: number | null;
  showedNum: number | null;
  bookedRate: number | null;
  showRate: number | null;
  dropoff: number | null;
  metrics: [string, number | null, DataQuality][];
  rates: RateResult[];
  cpl: number | null;
  cpb: number | null;
  cps: number | null;
  cpStart: number | null;
  weakest: RateResult | null;
  scenario: ScenarioResult | null;
  sequenceIssues: SequenceIssue[];
}): string {
  const {
    industry,
    businessName,
    practiceName,
    firstName,
    lastName,
    email,
    phone,
    role,
    locations,
    adSpend,
    avgStartValue,
    leadsNum,
    bookedNum,
    showedNum,
    bookedRate,
    showRate,
    dropoff,
    metrics,
    rates,
    cpl,
    cpb,
    cps,
    cpStart,
    weakest,
    scenario,
    sequenceIssues,
  } = opts;

  const lines: string[] = [];
  lines.push("GROWTH SNAPSHOT SUMMARY");
  lines.push(`Completed: ${new Date().toISOString()}`);
  lines.push(`Industry: ${industry}`);
  lines.push(`Business: ${businessName || practiceName || "—"}`);
  lines.push(`Contact: ${firstName} ${lastName} · ${email} · ${phone}`);
  lines.push("");
  lines.push("BUSINESS CONTEXT");
  lines.push(`Role: ${role}`);
  lines.push(`Locations: ${locations}`);
  lines.push(`Ad spend tier: ${adSpend}`);
  lines.push(`Avg start value: ${avgStartValue || "—"}`);
  lines.push("");
  lines.push("FREE CHECK (30-day)");
  lines.push(`Inquiries: ${leadsNum ?? "—"}`);
  lines.push(`Booked: ${bookedNum ?? "—"}`);
  lines.push(`Showed: ${showedNum ?? "—"}`);
  if (bookedRate !== null) lines.push(`Booked rate: ${bookedRate}%`);
  if (showRate !== null) lines.push(`Show rate: ${showRate}%`);
  if (dropoff !== null) lines.push(`Booked-to-show dropoff: ${dropoff}%`);
  lines.push("");
  lines.push("FUNNEL METRICS (30-day, with data quality)");
  for (const [label, val, q] of metrics) {
    lines.push(`${label}: ${val ?? "not tracked"} (${q})`);
  }
  lines.push("");
  lines.push("CONVERSION RATES");
  for (const r of rates) {
    lines.push(`${r.label} (${r.from}→${r.to}): ${formatRate(r.rate)}`);
  }
  lines.push("");
  lines.push("COST METRICS");
  lines.push(`Cost per lead: ${formatMoney(cpl)}`);
  lines.push(`Cost per booked: ${formatMoney(cpb)}`);
  lines.push(`Cost per show: ${formatMoney(cps)}`);
  lines.push(`Cost per start: ${formatMoney(cpStart)}`);
  lines.push("");
  if (sequenceIssues.length > 0) {
    lines.push("SEQUENCE VALIDATION ISSUES");
    for (const issue of sequenceIssues) lines.push(`- ${issue.message}`);
    lines.push("");
  }
  if (weakest) {
    lines.push(
      `PRIMARY CHALLENGE: ${weakest.label} (${weakest.from}→${weakest.to}) at ${weakest.rate}%`,
    );
  } else {
    lines.push("PRIMARY CHALLENGE: Not enough data to identify");
  }
  if (scenario) {
    lines.push("");
    lines.push("ILLUSTRATIVE SCENARIO (not a forecast or guarantee)");
    lines.push(`If ${scenario.stage} improved by +10pp (to ${scenario.improvedRate}%)`);
    if (scenario.additionalStarts !== null) {
      lines.push(`Estimated additional starts: ${scenario.additionalStarts}`);
    }
  }
  return lines.join("\n");
}

/**
 * Generate and download a readable .txt of the snapshot results.
 */
export function downloadSnapshot(opts: {
  industry: string;
  leadsNum: number | null;
  bookedNum: number | null;
  showedNum: number | null;
  bookedRate: number | null;
  showRate: number | null;
  dropoff: number | null;
  nInquiries: number | null;
  nContacted: number | null;
  nBooked: number | null;
  nConfirmed: number | null;
  nShowed: number | null;
  nStarted: number | null;
  nAdSpend: number | null;
  nAvgStartValue: number | null;
  mInquiries: FunnelMetric;
  mContacted: FunnelMetric;
  mBooked: FunnelMetric;
  mConfirmed: FunnelMetric;
  mShowed: FunnelMetric;
  mStarted: FunnelMetric;
  mAdSpend: FunnelMetric;
  mAvgStartValue: FunnelMetric;
  rates: RateResult[];
  cpl: number | null;
  cpb: number | null;
  cps: number | null;
  cpStart: number | null;
  weakest: RateResult | null;
  scenario: ScenarioResult | null;
  sequenceIssues: SequenceIssue[];
}) {
  const {
    industry,
    leadsNum,
    bookedNum,
    showedNum,
    bookedRate,
    showRate,
    dropoff,
    nInquiries,
    nContacted,
    nBooked,
    nConfirmed,
    nShowed,
    nStarted,
    nAdSpend,
    nAvgStartValue,
    mInquiries,
    mContacted,
    mBooked,
    mConfirmed,
    mShowed,
    mStarted,
    mAdSpend,
    mAvgStartValue,
    rates,
    cpl,
    cpb,
    cps,
    cpStart,
    weakest,
    scenario,
    sequenceIssues,
  } = opts;

  const lines: string[] = [];
  lines.push("PHYNYXPRO — MY GROWTH SNAPSHOT");
  lines.push(`Generated: ${new Date().toLocaleString()}`);
  lines.push(`Industry: ${industry}`);
  lines.push("");
  lines.push("=== FREE FUNNEL CHECK (recent 30 days) ===");
  lines.push(`New Leads & Inquiries: ${leadsNum ?? "not entered"}`);
  lines.push(`Appointments Booked: ${bookedNum ?? "not entered"}`);
  lines.push(`Showed: ${showedNum ?? "not entered"}`);
  if (bookedRate !== null) lines.push(`Booked Rate: ${bookedRate}%`);
  if (showRate !== null) lines.push(`Show Rate: ${showRate}%`);
  if (dropoff !== null) lines.push(`Booked-to-Show Dropoff: ${dropoff}%`);
  lines.push("");
  lines.push("=== FUNNEL METRICS (recent 30 days) ===");
  lines.push(`Inquiries: ${formatNum(nInquiries)} (${mInquiries.quality})`);
  lines.push(`Contacted: ${formatNum(nContacted)} (${mContacted.quality})`);
  lines.push(`Booked: ${formatNum(nBooked)} (${mBooked.quality})`);
  lines.push(`Confirmed: ${formatNum(nConfirmed)} (${mConfirmed.quality})`);
  lines.push(`Showed: ${formatNum(nShowed)} (${mShowed.quality})`);
  lines.push(`Started (care/services): ${formatNum(nStarted)} (${mStarted.quality})`);
  lines.push(`Ad Spend: ${formatNum(nAdSpend)} (${mAdSpend.quality})`);
  lines.push(`Avg Start Value: ${formatNum(nAvgStartValue)} (${mAvgStartValue.quality})`);
  lines.push("");
  lines.push("=== CONVERSION RATES ===");
  for (const r of rates) {
    lines.push(`${r.label} (${r.from} → ${r.to}): ${formatRate(r.rate)}`);
  }
  lines.push("");
  lines.push("=== COST METRICS ===");
  lines.push(`Cost per Lead: ${formatMoney(cpl)}`);
  lines.push(`Cost per Booked: ${formatMoney(cpb)}`);
  lines.push(`Cost per Show: ${formatMoney(cps)}`);
  lines.push(`Cost per Start: ${formatMoney(cpStart)}`);
  lines.push("");
  if (sequenceIssues.length > 0) {
    lines.push("=== SEQUENCE VALIDATION ISSUES ===");
    for (const issue of sequenceIssues) lines.push(`- ${issue.message}`);
    lines.push("");
  }
  if (weakest) {
    lines.push("=== PRIMARY CHALLENGE ===");
    lines.push(`${weakest.label} (${weakest.from} → ${weakest.to}) at ${weakest.rate}%`);
  }
  if (scenario) {
    lines.push("");
    lines.push("=== ILLUSTRATIVE SCENARIO (not a forecast or guarantee) ===");
    lines.push(
      `If ${scenario.stage} improved by +10 percentage points (to ${scenario.improvedRate}%):`,
    );
    if (scenario.additionalStarts !== null) {
      lines.push(`Estimated additional starts of care: ${scenario.additionalStarts}`);
    }
  }
  lines.push("");
  lines.push("Note: Inputs marked Estimate are approximations. Missing/Not tracked data is valid.");
  lines.push(
    "The scenario is illustrative and conservative, not a forecast or performance guarantee.",
  );

  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "my-growth-snapshot.txt";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

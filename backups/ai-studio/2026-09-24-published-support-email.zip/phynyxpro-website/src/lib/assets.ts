// Project-owned brand assets (downloaded from get.phynyxpro.com into cloud storage)
// Centralized so every component references the same owned URLs.

export const ASSETS = {
  logoDark:
    "https://vibe.filesafe.space/1789733833642057228/assets/9769c1be-efab-4a66-a9e6-120ca3af2230.png",
  logoLight:
    "https://vibe.filesafe.space/1789733833642057228/assets/6bae1b73-ebc6-4d01-a9a5-67a05a8f50c0.png",
  heroChiro:
    "https://vibe.filesafe.space/1789733833642057228/assets/17720665-ad65-4cc0-81f1-a6fc2072ed00.jpg",
  adCreative:
    "https://vibe.filesafe.space/1789733833642057228/assets/f14530e1-5f7e-4780-9c25-aabb3f2263b5.jpg",
  emberHuman:
    "https://vibe.filesafe.space/1789733833642057228/assets/3633094e-60b3-4343-b256-ba9ffa12d8e6.png",
  receptionist:
    "https://vibe.filesafe.space/1789733833642057228/assets/c5e21164-3e0b-4ea0-9218-818651a6cd22.jpg",
  businessOwner:
    "https://vibe.filesafe.space/1789733833642057228/assets/4d93d2dd-1001-42d0-a04a-b07521e773e6.jpg",
  industryChiro:
    "https://vibe.filesafe.space/1789733833642057228/assets/2d2c5a07-b30d-4e86-9ef2-7518f650c764.jpg",
  industryHome:
    "https://vibe.filesafe.space/1789733833642057228/assets/32113d8b-be7d-47da-aa76-33de190324a5.jpg",
  industryDental:
    "https://vibe.filesafe.space/1789733833642057228/assets/fbcb2396-22a6-4a4a-a46d-8136e66b0bc7.jpg",
  industryOther:
    "https://vibe.filesafe.space/1789733833642057228/assets/82bf95b0-5e7f-4dc4-a25d-efe2e96de37c.jpg",
  chiropractor:
    "https://vibe.filesafe.space/1789733833642057228/assets/22f35b54-21aa-4fdf-a069-9b87a22d3519.jpg",
  homeServices:
    "https://vibe.filesafe.space/1789733833642057228/assets/0e634acd-26a3-48dd-aafd-1902da9cf83a.jpg",
  dental:
    "https://vibe.filesafe.space/1789733833642057228/assets/d449ed65-6537-43b1-ab5e-975644b589ce.jpg",
  pyroIcon:
    "https://vibe.filesafe.space/1789733833642057228/assets/bdddc103-5061-46de-b4ff-40a21f1a8caf.png",
  emberAvatar:
    "https://vibe.filesafe.space/1789733833642057228/assets/9468c158-7f2e-4d87-bab5-c034de67d219.png",
  clientTeam:
    "https://vibe.filesafe.space/1789733833642057228/assets/55aea625-8f1f-4d60-a9d8-ccb4727d71a4.jpg",
  emberExtended:
    "https://vibe.filesafe.space/1789733833642057228/assets/c1c0091f-0938-46d6-8211-db676570acd4.png",
  emberHeroBgDesktop:
    "https://vibe.filesafe.space/1789733833642057228/assets/3c872f7e-3e87-45df-ad17-f1b0ec9ea348.png",
  emberHeroBgMobile:
    "https://vibe.filesafe.space/1789733833642057228/assets/9576f28b-83c9-45b0-afd9-616697a062ba.png",
  emberTallTransparent:
    "https://vibe.filesafe.space/1789733833642057228/assets/29af9687-9313-4dd8-b2bd-40d39fab4951.png",
} as const;

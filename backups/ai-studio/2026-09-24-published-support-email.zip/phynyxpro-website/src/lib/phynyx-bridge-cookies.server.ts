/**
 * Server-only cookie handling for the /api/phynyx-bridge proxy.
 *
 * UNPUBLISHED DRAFT. Extracted from phynyx-bridge.server.ts so the main
 * handler module stays lean. All logic here is server-only (this file is
 * blocked from client bundles by the *.server.* filename convention).
 */

import type { BridgeAction, BridgeError } from "./phynyx-bridge.server";

// ---------------------------------------------------------------------------
// Constants (mirrored from the main module — kept in sync intentionally)
// ---------------------------------------------------------------------------

export const INTAKE_COOKIE = "__Host-phynyx_intake";
export const BOOKING_COOKIE = "phynyx_booking";
const COOKIE_VALUE_RE = /^[0-9a-f]{64}$/;

const EXPECTED_SET_COOKIE_ATTRS = new Set(["path", "httponly", "samesite", "max-age", "secure"]);

// ---------------------------------------------------------------------------
// Forwarded (incoming) cookies
// ---------------------------------------------------------------------------

export interface ForwardedCookies {
  intake?: string;
  booking?: string;
  error?: BridgeError;
}

/**
 * Extract only the allowed intake/booking cookies from the incoming Cookie
 * header. Rejects duplicate occurrences of either name and any malformed
 * (non-64-hex) value.
 */
export function extractForwardedCookies(cookieHeader: string | null): ForwardedCookies {
  if (!cookieHeader) return {};
  const intakeValues: string[] = [];
  const bookingValues: string[] = [];
  for (const part of cookieHeader.split(";")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;
    const name = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (name === INTAKE_COOKIE) intakeValues.push(value);
    else if (name === BOOKING_COOKIE) bookingValues.push(value);
  }
  // Reject duplicate occurrences of either allowed cookie name.
  if (intakeValues.length > 1 || bookingValues.length > 1) {
    return { error: { error: "Duplicate cookie.", code: "INVALID_COOKIE" } };
  }
  const intake = intakeValues[0];
  const booking = bookingValues[0];
  if (intake !== undefined && !COOKIE_VALUE_RE.test(intake)) {
    return { error: { error: "Invalid intake cookie.", code: "INVALID_COOKIE" } };
  }
  if (booking !== undefined && !COOKIE_VALUE_RE.test(booking)) {
    return { error: { error: "Invalid booking cookie.", code: "INVALID_COOKIE" } };
  }
  const result: ForwardedCookies = {};
  if (intake !== undefined) result.intake = intake;
  if (booking !== undefined) result.booking = booking;
  return result;
}

/**
 * Build the action-aware forwarded Cookie header.
 *  - intake:      intake only (if present)
 *  - assessment:  intake only (required present, checked elsewhere)
 *  - booking:     intake then booking (both required, checked elsewhere)
 *  - support:     always empty (the Worker rejects any cookie for support)
 */
export function buildForwardedCookieHeader(
  action: BridgeAction,
  cookies: ForwardedCookies,
): string {
  if (action === "support") return "";
  const parts: string[] = [];
  if (cookies.intake) parts.push(`${INTAKE_COOKIE}=${cookies.intake}`);
  if (action === "booking" && cookies.booking) {
    parts.push(`${BOOKING_COOKIE}=${cookies.booking}`);
  }
  return parts.join("; ");
}

// ---------------------------------------------------------------------------
// Set-Cookie parsing & validation (action-aware, exact-shape enforcement)
// ---------------------------------------------------------------------------

interface ParsedSetCookie {
  name: string;
  value: string;
  attrs: Map<string, string>;
}

function parseSetCookie(header: string): ParsedSetCookie | null {
  const parts = header
    .split(";")
    .map((p) => p.trim())
    .filter((p) => p.length > 0);
  if (parts.length === 0) return null;
  const first = parts[0]!;
  const eqIdx = first.indexOf("=");
  if (eqIdx === -1) return null;
  const name = first.slice(0, eqIdx).trim();
  const value = first.slice(eqIdx + 1).trim();
  const attrs = new Map<string, string>();
  for (let i = 1; i < parts.length; i++) {
    const part = parts[i]!;
    const idx = part.indexOf("=");
    if (idx === -1) {
      attrs.set(part.toLowerCase(), "");
    } else {
      attrs.set(part.slice(0, idx).toLowerCase(), part.slice(idx + 1).trim());
    }
  }
  return { name, value, attrs };
}

/**
 * Exact shape a required Set-Cookie must match for a given outcome.
 *  - valueMustBeEmpty=true  → value must be "" (a clear), e.g. booking claim.
 *  - valueMustBeEmpty=false → value must be 64 lower hex (a real session id).
 */
interface RequiredCookieSpec {
  name: string;
  maxAge: number;
  valueMustBeEmpty: boolean;
}

function matchesSpec(header: string, spec: RequiredCookieSpec): boolean {
  const parsed = parseSetCookie(header);
  if (!parsed) return false;
  if (parsed.name !== spec.name) return false;

  // Value validation.
  if (spec.valueMustBeEmpty) {
    if (parsed.value !== "") return false;
  } else {
    if (!COOKIE_VALUE_RE.test(parsed.value)) return false;
  }

  const attrs = parsed.attrs;

  // Exact attribute set — reject unexpected attributes (e.g. Domain, Expires).
  for (const key of attrs.keys()) {
    if (!EXPECTED_SET_COOKIE_ATTRS.has(key)) return false;
  }
  // All required attributes present.
  for (const expected of EXPECTED_SET_COOKIE_ATTRS) {
    if (!attrs.has(expected)) return false;
  }

  // Attribute values.
  if (attrs.get("path") !== "/") return false;
  if (attrs.get("samesite")?.toLowerCase() !== "strict") return false;
  // HttpOnly and Secure are flags (present with empty value).
  if (attrs.get("httponly") !== "") return false;
  if (attrs.get("secure") !== "") return false;
  const maxAgeRaw = attrs.get("max-age");
  if (maxAgeRaw === undefined) return false;
  const maxAge = Number(maxAgeRaw);
  if (!Number.isInteger(maxAge) || maxAge !== spec.maxAge) return false;

  return true;
}

/**
 * Determine whether the response JSON marks a qualified (booking-ready)
 * assessment, which is the only assessment outcome that sets a booking cookie.
 */
function bookingReadyFromJson(json: unknown): boolean {
  if (typeof json !== "object" || json === null || Array.isArray(json)) return false;
  return (json as Record<string, unknown>)["bookingReady"] === true;
}

export type SetCookieResult = { ok: true; cookies: string[] } | { ok: false; error: BridgeError };

/**
 * Validate backend Set-Cookie headers against the exact shape allowed for the
 * action + outcome. Returns the cookies to relay, or an error to fail closed.
 *
 * Cookie-requirement rules (valid zero-cookie outcomes are allowed):
 *  - intake 2xx:     if no incoming intake cookie, require exactly one valid
 *                    intake Set-Cookie (Max-Age=7200, 64-hex). If an incoming
 *                    intake cookie exists, accept EITHER zero cookies (the
 *                    Worker reused the existing session) OR exactly one valid
 *                    intake replacement cookie (the Worker found the existing
 *                    token expired/unknown and issued a fresh one).
 *  - assessment 2xx: require a booking cookie (Max-Age=900, 64-hex) ONLY when
 *                    the response JSON has bookingReady:true. Partial /
 *                    foundation / honeypot-ignored assessments return none.
 *  - booking 2xx:   require a booking clear cookie (empty value, Max-Age=0)
 *                    for a successful booking-session claim.
 *  - booking 401:    the Worker returns 401 BOOKING_SESSION_UNAVAILABLE with a
 *                    booking clear cookie (empty value, Max-Age=0) to clear an
 *                    expired booking session. Accept and relay exactly that.
 *  - support:        never any cookie.
 *  - non-2xx:        never any cookie (except the booking 401 clear above).
 *
 * Still rejects ANY malformed, unexpected, duplicate, or wrong-action cookie.
 * Fails closed if getSetCookie is unavailable when a cookie is required.
 */
export function validateSetCookies(
  action: BridgeAction,
  status: number,
  setCookies: string[] | null,
  hasIncomingIntake: boolean,
  resJson: unknown,
): SetCookieResult {
  const is2xx = status >= 200 && status < 300;

  // Determine the required cookie spec for this outcome.
  //  - "required"  : exactly one cookie of this spec must be present.
  //  - "optional"  : zero OR exactly one cookie of this spec is allowed.
  //  - null        : no cookie may be present.
  let required: RequiredCookieSpec | null = null;
  let optional: RequiredCookieSpec | null = null;

  if (is2xx) {
    if (action === "intake") {
      if (!hasIncomingIntake) {
        // No incoming intake → Worker must issue a fresh intake cookie.
        required = { name: INTAKE_COOKIE, maxAge: 7200, valueMustBeEmpty: false };
      } else {
        // Incoming intake present → Worker may reuse (zero cookies) or replace
        // (one valid intake cookie) the session.
        optional = { name: INTAKE_COOKIE, maxAge: 7200, valueMustBeEmpty: false };
      }
    } else if (action === "assessment") {
      // Only a qualified (booking-ready) assessment sets a booking cookie.
      if (bookingReadyFromJson(resJson)) {
        required = { name: BOOKING_COOKIE, maxAge: 900, valueMustBeEmpty: false };
      }
    } else if (action === "booking") {
      // Successful booking-session claim clears the booking cookie.
      required = { name: BOOKING_COOKIE, maxAge: 0, valueMustBeEmpty: true };
    }
    // support: never required/optional.
  } else if (action === "booking" && status === 401) {
    // The Worker deliberately returns 401 BOOKING_SESSION_UNAVAILABLE with a
    // booking clear cookie to clear an expired booking session. Accept and
    // relay exactly that clear cookie; any other non-2xx cookie is rejected.
    required = { name: BOOKING_COOKIE, maxAge: 0, valueMustBeEmpty: true };
  }

  // getSetCookie unavailable.
  if (setCookies === null) {
    if (required !== null) {
      return {
        ok: false,
        error: { error: "Set-Cookie header unavailable.", code: "SET_COOKIE_UNAVAILABLE" },
      };
    }
    // optional with no headers available → zero cookies, allowed.
    return { ok: true, cookies: [] };
  }

  // No cookie expected for this outcome → any present cookie is unexpected.
  if (required === null && optional === null) {
    if (setCookies.length > 0) {
      return {
        ok: false,
        error: { error: "Unexpected Set-Cookie.", code: "UNEXPECTED_SET_COOKIE" },
      };
    }
    return { ok: true, cookies: [] };
  }

  // Optional mode: zero or exactly one matching cookie.
  if (required === null && optional !== null) {
    if (setCookies.length === 0) {
      return { ok: true, cookies: [] };
    }
    if (setCookies.length !== 1) {
      return {
        ok: false,
        error: { error: "Unexpected Set-Cookie.", code: "UNEXPECTED_SET_COOKIE" },
      };
    }
    const sc = setCookies[0]!;
    if (!matchesSpec(sc, optional)) {
      return {
        ok: false,
        error: { error: "Unexpected Set-Cookie.", code: "UNEXPECTED_SET_COOKIE" },
      };
    }
    return { ok: true, cookies: setCookies };
  }

  // Required mode: exactly one must be present.
  if (setCookies.length !== 1) {
    return {
      ok: false,
      error: { error: "Missing required Set-Cookie.", code: "MISSING_SET_COOKIE" },
    };
  }

  const sc = setCookies[0]!;
  if (!matchesSpec(sc, required!)) {
    return {
      ok: false,
      error: { error: "Unexpected Set-Cookie.", code: "UNEXPECTED_SET_COOKIE" },
    };
  }

  return { ok: true, cookies: setCookies };
}

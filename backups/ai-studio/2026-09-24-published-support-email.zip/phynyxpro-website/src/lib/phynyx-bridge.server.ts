/**
 * Server-only submission bridge helper for /api/phynyx-bridge.
 *
 * UNPUBLISHED DRAFT. The paired backend endpoint (Cloudflare Worker PR #8) is
 * NOT deployed. This module is fail-closed: every code path that lacks a fully
 * configured, verified environment returns a stable error and forwards
 * nothing to any external service.
 *
 * All key material is read from process.env INSIDE handler functions only.
 * Nothing here is ever VITE_-prefixed or shipped to the client bundle.
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type BridgeAction = "intake" | "assessment" | "booking" | "support";

const ALLOWED_ACTIONS: ReadonlySet<BridgeAction> = new Set([
  "intake",
  "assessment",
  "booking",
  "support",
]);

/** Stable JSON error body returned to the browser. Never leaks secrets. */
export interface BridgeError {
  error: string;
  code: string;
}

/** Successful relay result (status + JSON body + allowed Set-Cookie lines). */
export interface BridgeRelayResult {
  status: number;
  json: unknown;
  setCookie: string[];
}

export type BridgeOutcome =
  { ok: true; result: BridgeRelayResult } | { ok: false; status: number; body: BridgeError };

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PROTOCOL = "https:";
const BRIDGE_PATH = "/api/studio-bridge";

const MAX_BODY_BYTES = 24 * 1024; // 24 KiB raw request body cap
const MAX_RESPONSE_BYTES = 64 * 1024; // 64 KiB backend response cap

// Cookie handling lives in phynyx-bridge-cookies.server.ts (server-only).
import {
  extractForwardedCookies,
  buildForwardedCookieHeader,
  validateSetCookies,
  type ForwardedCookies,
} from "./phynyx-bridge-cookies.server";

// ---------------------------------------------------------------------------
// Env validation (called inside the handler)
// ---------------------------------------------------------------------------

interface BridgeEnv {
  secret: string;
  publicOrigin: string;
  bridgeUrl: string;
  trustCfConnectingIp: boolean;
}

function readEnv(): BridgeEnv | null {
  const secret = process.env["STUDIO_BRIDGE_SECRET"];
  const publicOrigin = process.env["STUDIO_PUBLIC_ORIGIN"];
  const bridgeUrl = process.env["STUDIO_BRIDGE_URL"];
  const trustFlag = process.env["STUDIO_TRUST_CF_CONNECTING_IP"];

  if (typeof secret !== "string") return null;
  // TextEncoder byte length — portable across runtimes (no Node Buffer).
  if (new TextEncoder().encode(secret).length < 32) return null;
  if (typeof publicOrigin !== "string" || typeof bridgeUrl !== "string") return null;

  // Validate publicOrigin: exact HTTPS origin (scheme://host), no
  // credentials, path, query, or fragment.
  let originUrl: URL;
  try {
    originUrl = new URL(publicOrigin);
  } catch {
    return null;
  }
  if (originUrl.protocol !== PROTOCOL) return null;
  if (originUrl.username !== "" || originUrl.password !== "") return null;
  if (originUrl.pathname !== "/") return null;
  if (originUrl.search !== "" || originUrl.hash !== "") return null;
  const canonicalOrigin = `${originUrl.protocol}//${originUrl.host}`;
  if (canonicalOrigin !== publicOrigin) return null;

  // Validate bridgeUrl: exact HTTPS URL ending in /api/studio-bridge, no
  // credentials, query, or fragment.
  let bridgeUrlObj: URL;
  try {
    bridgeUrlObj = new URL(bridgeUrl);
  } catch {
    return null;
  }
  if (bridgeUrlObj.protocol !== PROTOCOL) return null;
  if (bridgeUrlObj.username !== "" || bridgeUrlObj.password !== "") return null;
  if (bridgeUrlObj.search !== "" || bridgeUrlObj.hash !== "") return null;
  if (bridgeUrlObj.pathname !== BRIDGE_PATH) return null;
  if (bridgeUrlObj.href !== bridgeUrl) return null;

  const trustCfConnectingIp = trustFlag === "true";

  return {
    secret,
    publicOrigin: canonicalOrigin,
    bridgeUrl: bridgeUrlObj.href,
    trustCfConnectingIp,
  };
}

// ---------------------------------------------------------------------------
// Crypto helpers (Web Crypto — available on the edge runtime)
// ---------------------------------------------------------------------------

async function sha256Hex(data: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", data as BufferSource);
  return bufferToHex(new Uint8Array(digest));
}

async function hmacSha256Hex(key: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(key) as BufferSource,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(message) as BufferSource);
  return bufferToHex(new Uint8Array(sig));
}

function bufferToHex(buf: Uint8Array): string {
  let out = "";
  for (let i = 0; i < buf.length; i++) {
    out += buf[i]!.toString(16).padStart(2, "0");
  }
  return out;
}

function randomNonceHex(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return bufferToHex(bytes);
}

// ---------------------------------------------------------------------------
// Request validation
// ---------------------------------------------------------------------------

/**
 * Validate origin: request URL origin AND Origin header must BOTH be present
 * and equal the configured Studio origin. A missing Origin header is rejected.
 * Sec-Fetch-Site, when present, must be same-origin.
 */
function validateOrigin(request: Request, env: BridgeEnv): BridgeError | null {
  const reqUrl = new URL(request.url);
  const reqOrigin = `${reqUrl.protocol}//${reqUrl.host}`;

  if (reqOrigin !== env.publicOrigin) {
    return { error: "Origin mismatch.", code: "ORIGIN_MISMATCH" };
  }

  const originHeader = request.headers.get("origin");
  if (originHeader === null || originHeader !== env.publicOrigin) {
    return { error: "Origin mismatch.", code: "ORIGIN_MISMATCH" };
  }

  const secFetchSite = request.headers.get("sec-fetch-site");
  if (secFetchSite !== null && secFetchSite !== "same-origin") {
    return { error: "Cross-site request rejected.", code: "CROSS_SITE_REJECTED" };
  }

  return null;
}

/**
 * Derive the trusted client address ONLY from a platform-overwritten edge
 * header. Browser-supplied X-Forwarded-For is never trusted. Since AI Studio
 * edge provenance is unverified, CF-Connecting-IP requires an explicit
 * STUDIO_TRUST_CF_CONNECTING_IP=true flag (not set yet) — otherwise fail.
 */
function deriveClientAddress(request: Request, env: BridgeEnv): string | BridgeError {
  if (env.trustCfConnectingIp) {
    const cf = request.headers.get("cf-connecting-ip");
    if (cf && isValidIp(cf)) return cf.trim();
  }
  return {
    error: "Trusted client address unavailable.",
    code: "TRUSTED_ADDRESS_UNAVAILABLE",
  };
}

function isValidIp(value: string): boolean {
  const v = value.trim();
  if (!v) return false;
  if (v.includes(",") || v.includes(" ")) return false;
  return /^[0-9a-fA-F.:]+$/.test(v);
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

export async function handlePhynyxBridge(request: Request): Promise<Response> {
  const noStore = { "Cache-Control": "no-store" };

  // 1) Environment must be fully configured.
  const env = readEnv();
  if (!env) {
    return jsonError(
      503,
      { error: "Bridge not configured.", code: "BRIDGE_NOT_CONFIGURED" },
      noStore,
    );
  }

  // 2) POST only.
  if (request.method !== "POST") {
    return jsonError(405, { error: "Method not allowed.", code: "METHOD_NOT_ALLOWED" }, noStore);
  }

  // 3) Content-Type must be application/json (charset allowed, normalized).
  const contentType = request.headers.get("content-type");
  const normalizedReqCt = normalizeJsonContentType(contentType);
  if (normalizedReqCt === null) {
    return jsonError(
      415,
      { error: "Unsupported media type.", code: "UNSUPPORTED_MEDIA_TYPE" },
      noStore,
    );
  }

  // 4) Origin / Sec-Fetch-Site validation.
  const originErr = validateOrigin(request, env);
  if (originErr) return jsonError(403, originErr, noStore);

  // 5) Action header.
  const action = request.headers.get("x-phynyx-action");
  if (!action || !ALLOWED_ACTIONS.has(action as BridgeAction)) {
    return jsonError(400, { error: "Invalid action.", code: "INVALID_ACTION" }, noStore);
  }
  const typedAction = action as BridgeAction;

  // 6) Bound raw body (24 KiB) BEFORE parsing/signing — keep exact bytes.
  const rawBytes = await readBoundedBytes(request, MAX_BODY_BYTES);
  if (rawBytes === null) {
    return jsonError(413, { error: "Request body too large.", code: "BODY_TOO_LARGE" }, noStore);
  }

  // 7) Parse JSON body from the exact raw bytes.
  let parsedBody: unknown;
  try {
    parsedBody = JSON.parse(new TextDecoder().decode(rawBytes));
  } catch {
    return jsonError(400, { error: "Invalid JSON body.", code: "INVALID_JSON" }, noStore);
  }

  // 8) Action-specific cookie extraction + requirements.
  //
  // support is independent of any ambient intake/booking cookie: skip
  // extraction/validation entirely so a stale or malformed session cookie
  // cannot block a valid support request. The forwarded Cookie header is
  // signed/forwarded as empty (see buildForwardedCookieHeader).
  const cookieHeader = request.headers.get("cookie");
  let cookies: ForwardedCookies = {};
  if (typedAction !== "support") {
    cookies = extractForwardedCookies(cookieHeader);
    if (cookies.error) return jsonError(400, cookies.error, noStore);
  }

  if (typedAction === "assessment") {
    if (!cookies.intake) {
      return jsonError(400, { error: "Intake cookie required.", code: "INTAKE_REQUIRED" }, noStore);
    }
  } else if (typedAction === "booking") {
    if (!cookies.intake || !cookies.booking) {
      return jsonError(
        400,
        { error: "Intake and booking cookies required.", code: "COOKIES_REQUIRED" },
        noStore,
      );
    }
    if (!isExactlyEmptyObject(parsedBody)) {
      return jsonError(
        400,
        { error: "Booking body must be empty object.", code: "INVALID_BOOKING_BODY" },
        noStore,
      );
    }
  }

  // 9) Trusted client address.
  const clientAddrOrErr = deriveClientAddress(request, env);
  if (typeof clientAddrOrErr !== "string") {
    return jsonError(503, clientAddrOrErr, noStore);
  }
  const trustedClientAddress = clientAddrOrErr;

  // 10) Visitor origin (validated to equal configured origin).
  const visitorOrigin = env.publicOrigin;

  // 11) Build signature over the exact raw body bytes.
  const timestamp = String(Date.now());
  if (timestamp.length !== 13) {
    return jsonError(500, { error: "Timestamp error.", code: "TIMESTAMP_ERROR" }, noStore);
  }
  const nonce = randomNonceHex();
  const bodyHash = await sha256Hex(rawBytes);
  const filteredCookieHeader = buildForwardedCookieHeader(typedAction, cookies);

  const signatureMessage = JSON.stringify([
    "phynyx-studio-bridge-v1",
    timestamp,
    nonce,
    typedAction,
    visitorOrigin,
    trustedClientAddress,
    filteredCookieHeader,
    normalizedReqCt,
    bodyHash,
  ]);

  const signature = await hmacSha256Hex(env.secret, signatureMessage);

  // 12) Forward to fixed backend URL with the exact raw bytes.
  const forwardHeaders: Record<string, string> = {
    "Content-Type": "application/json",
    Origin: visitorOrigin,
    "X-Phynyx-Bridge-Action": typedAction,
    "X-Phynyx-Bridge-Timestamp": timestamp,
    "X-Phynyx-Bridge-Nonce": nonce,
    "X-Phynyx-Bridge-Signature": signature,
    "X-Phynyx-Bridge-Visitor-Origin": visitorOrigin,
    "X-Phynyx-Bridge-Client-Address": trustedClientAddress,
  };
  if (filteredCookieHeader) {
    forwardHeaders["Cookie"] = filteredCookieHeader;
  }

  let backendRes: Response;
  try {
    backendRes = await fetch(env.bridgeUrl, {
      method: "POST",
      headers: forwardHeaders,
      body: rawBytes as BodyInit,
      redirect: "manual",
      cache: "no-store",
    });
  } catch {
    // Never leak fetch error details.
    return jsonError(502, { error: "Backend unreachable.", code: "BACKEND_UNREACHABLE" }, noStore);
  }

  // 13) Reject redirects.
  if (backendRes.status >= 300 && backendRes.status < 400) {
    return jsonError(
      502,
      { error: "Backend redirect rejected.", code: "BACKEND_REDIRECT" },
      noStore,
    );
  }

  // 14) Reject non-JSON responses (charset allowed, normalized).
  const resContentType = backendRes.headers.get("content-type");
  if (normalizeJsonContentType(resContentType) === null) {
    return jsonError(
      502,
      { error: "Backend returned non-JSON.", code: "BACKEND_NON_JSON" },
      noStore,
    );
  }

  // 15) Bound response (64 KiB) — keep exact bytes.
  const resBytes = await readBoundedBytes(backendRes, MAX_RESPONSE_BYTES);
  if (resBytes === null) {
    return jsonError(
      502,
      { error: "Backend response too large.", code: "BACKEND_RESPONSE_TOO_LARGE" },
      noStore,
    );
  }

  let resJson: unknown;
  try {
    resJson = JSON.parse(new TextDecoder().decode(resBytes));
  } catch {
    return jsonError(
      502,
      { error: "Backend returned invalid JSON.", code: "BACKEND_INVALID_JSON" },
      noStore,
    );
  }

  // 16) Validate Set-Cookie headers against the exact action shape.
  let setCookies: string[] | null;
  const getSetCookie = backendRes.headers.getSetCookie;
  if (typeof getSetCookie === "function") {
    setCookies = getSetCookie.call(backendRes.headers);
  } else {
    setCookies = null;
  }

  const scResult = validateSetCookies(
    typedAction,
    backendRes.status,
    setCookies,
    Boolean(cookies.intake),
    resJson,
  );
  if (!scResult.ok) {
    return jsonError(502, scResult.error, noStore);
  }

  // 17) Relay status + JSON + allowed Set-Cookie. No secret/signature/body leak.
  const response = new Response(JSON.stringify(resJson), {
    status: backendRes.status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });

  for (const sc of scResult.cookies) {
    response.headers.append("Set-Cookie", sc);
  }

  return response;
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

/**
 * Normalize a Content-Type header to "application/json" for the signed Worker
 * tuple (matching Worker lib/studio-bridge.ts). Accepts an optional charset
 * parameter (e.g. "application/json; charset=utf-8") and normalizes it to the
 * bare media type. Returns null for missing or non-JSON content types.
 *
 * Raw request bytes are never modified — only the content-type string used in
 * the signature tuple is normalized.
 */
function normalizeJsonContentType(header: string | null): string | null {
  if (header === null) return null;
  const semi = header.indexOf(";");
  const mediaType = (semi === -1 ? header : header.slice(0, semi)).trim().toLowerCase();
  if (mediaType !== "application/json") return null;
  return "application/json";
}

/**
 * Read a bounded number of raw bytes from a Request/Response stream.
 * Returns the exact bytes (no decode/re-encode round-trip) so signing and
 * forwarding operate on identical bytes, or null if the cap is exceeded.
 */
async function readBoundedBytes(
  source: Request | Response,
  maxBytes: number,
): Promise<Uint8Array | null> {
  const reader = source.body?.getReader();
  if (!reader) return new Uint8Array(0);
  const chunks: Uint8Array[] = [];
  let received = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!value) continue;
    received += value.byteLength;
    if (received > maxBytes) {
      try {
        await reader.cancel();
      } catch {
        /* ignore */
      }
      return null;
    }
    chunks.push(value);
  }
  const out = new Uint8Array(received);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.byteLength;
  }
  return out;
}

function isExactlyEmptyObject(value: unknown): boolean {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  return Object.keys(value).length === 0;
}

function jsonError(
  status: number,
  body: BridgeError,
  extraHeaders?: Record<string, string>,
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      ...extraHeaders,
    },
  });
}

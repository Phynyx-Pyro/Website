import { Link } from "@tanstack/react-router";
import { ArrowRight, Calendar, Play } from "lucide-react";
import { ASSETS } from "../lib/assets";

const STAGES = [
  { num: "01", label: "Lead" },
  { num: "02", label: "Appointment request" },
  { num: "03", label: "Confirmed" },
  { num: "04", label: "Day 1 show" },
  { num: "05", label: "Start care" },
];

export function HomepageHero() {
  return (
    <section className="relative w-full overflow-hidden bg-ivory grain">
      {/* Full-width two-column composition */}
      <div className="relative grid grid-cols-1 lg:grid-cols-2 min-h-[560px] lg:min-h-[640px]">
        {/* Left: copy */}
        <div className="relative z-10 flex items-center px-6 sm:px-10 lg:px-[112px] py-14 lg:py-20">
          <div className="max-w-[560px]">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Patient acquisition for chiropractic practices
            </p>
            <h1 className="text-[40px] sm:text-5xl lg:text-[69px] font-bold tracking-tight text-ink leading-[1.02]">
              From Ad Click to
              <br />
              First Visit
            </h1>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-xl">
              We run your Meta ads and connect rapid response, booking, reminders, and team
              handoffs. Track each lead from campaign source through confirmed appointments, first
              visits, and starts of care.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4">
              <Link
                to="/schedule"
                search={{ cta: "home-hero" }}
                className="group inline-flex items-center justify-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                <Calendar className="w-4 h-4" />
                Schedule My Growth Call
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/growth-assessment"
                search={{ cta: "home-hero", industry: "chiropractic" }}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-phoenix/40 text-phoenix px-6 py-3.5 text-sm font-semibold hover:bg-phoenix/5 transition-colors"
              >
                Get My Free Growth Snapshot
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href="#system-walkthrough"
                className="inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3.5 text-sm font-semibold text-ink/70 hover:text-phoenix transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                See How It Works
              </a>
            </div>

            <div className="mt-8 space-y-1.5 text-sm text-warm">
              <p>
                See where your new-patient journey is losing momentum and what improving it could
                mean. About 3 minutes.
              </p>
              <p>Bring the numbers you have. Missing data is part of what we'll map.</p>
              <p className="flex items-center gap-2 text-sm text-ink">
                <span className="inline-flex w-4 h-4 rounded-full bg-phoenix/15 text-phoenix items-center justify-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-phoenix" />
                </span>
                Operator-led by Andrew Higdon, DC, a practicing chiropractor.
              </p>
            </div>
          </div>
        </div>

        {/* Right: full-bleed photo to viewport edge */}
        <div className="relative lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <img
            src={ASSETS.heroChiro}
            alt="Chiropractic practice new-patient visit"
            className="w-full h-[300px] lg:h-full object-cover object-center"
            loading="eager"
          />
          {/* Soft ivory fade on left + bottom edges */}
          <div className="pointer-events-none absolute inset-0 lg:bg-linear-to-r from-ivory via-ivory/0 to-transparent" />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-linear-to-t from-ivory to-transparent" />

          {/* Five-stage dark charcoal panel overlaying mid/lower-right of photo */}
          <div className="absolute bottom-6 right-6 lg:bottom-10 lg:right-10 z-10 w-[340px] sm:w-[440px] lg:w-[570px] rounded-2xl bg-coal/95 backdrop-blur-sm border border-white/10 shadow-2xl p-5 lg:p-7 grain-dark">
            <p className="text-[11px] font-bold uppercase tracking-widest text-white/60">
              PHYNYXPRO
            </p>
            <p className="text-base lg:text-lg font-bold text-white mt-1">
              Patient acquisition operating system
            </p>
            <p className="text-xs lg:text-sm text-white/60 mt-0.5">One connected journey</p>

            <div className="mt-4 flex items-center justify-between gap-1.5">
              {STAGES.map((s, i) => (
                <div key={s.num} className="flex items-center gap-1.5 flex-1">
                  <div className="flex flex-col items-center text-center min-w-0">
                    <span className="w-8 h-8 lg:w-9 lg:h-9 rounded-full bg-phoenix/15 text-flame text-[11px] lg:text-xs font-bold flex items-center justify-center">
                      {s.num}
                    </span>
                    <span className="mt-1.5 text-[9px] lg:text-[10px] font-semibold text-white/85 leading-tight">
                      {s.label}
                    </span>
                  </div>
                  {i < STAGES.length - 1 && (
                    <div className="h-[2px] flex-1 bg-phoenix/25 dashline min-w-[8px]" />
                  )}
                </div>
              ))}
            </div>
            <p className="mt-4 text-[11px] lg:text-xs text-white/60 leading-snug">
              Campaign source stays attached while your team verifies show and start-care outcomes.
            </p>
          </div>
        </div>
      </div>

      {/* Full-width dark bar immediately beneath hero */}
      <div className="w-full bg-ink text-white grain-dark">
        <div className="mx-auto max-w-[1320px] px-5 lg:px-10 py-3 text-center">
          <p className="text-[11px] font-bold uppercase tracking-widest text-flame">
            Designed around the handoffs that decide patient acquisition
          </p>
        </div>
      </div>
    </section>
  );
}

import { Link } from "@tanstack/react-router";
import { ArrowRight, Calendar } from "lucide-react";

type Props = {
  variant?: "light" | "dark";
  align?: "left" | "center";
  ctaSource?: string;
  className?: string;
};

/**
 * Dual CTA block used across home + results.
 * Primary: "Schedule My Growth Call" -> /schedule
 * Secondary: "Get My Free Growth Snapshot" -> /growth-assessment
 */
export function DualCta({
  variant = "light",
  align = "center",
  ctaSource = "dual-cta",
  className = "",
}: Props) {
  const isDark = variant === "dark";
  const alignClass = align === "center" ? "justify-center text-center" : "justify-start text-left";

  return (
    <div
      className={`flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 ${alignClass} ${className}`}
    >
      <Link
        to="/schedule"
        search={{ cta: ctaSource }}
        className="group inline-flex items-center justify-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
      >
        <Calendar className="w-4 h-4" />
        Schedule My Growth Call
        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
      </Link>
      <Link
        to="/growth-assessment"
        search={{ cta: ctaSource, industry: "chiropractic" }}
        className={`inline-flex items-center justify-center gap-2 rounded-lg border px-6 py-3.5 text-sm font-semibold transition-colors ${
          isDark
            ? "border-white/30 text-white hover:bg-white/10"
            : "border-phoenix/40 text-phoenix hover:bg-phoenix/5"
        }`}
      >
        Get My Free Growth Snapshot
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}

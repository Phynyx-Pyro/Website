import { PillarsSection } from "./sections/PillarsSection";
import { ReframeSection } from "./sections/ReframeSection";
import { JourneySection } from "./sections/JourneySection";
import { ThreeJobsSection } from "./sections/ThreeJobsSection";
import { ResponsibilitiesSection } from "./sections/ResponsibilitiesSection";
import { TimelineSection } from "./sections/TimelineSection";
import { PyroEmberSection } from "./sections/PyroEmberSection";
import { FounderSection } from "./sections/FounderSection";
import { SelectiveFitSection } from "./sections/SelectiveFitSection";
import { FaqSection } from "./sections/FaqSection";
import { FinalCtaSection } from "./sections/FinalCtaSection";

export function HomepageSystemSections() {
  return (
    <>
      <PillarsSection />
      <ReframeSection />
      <JourneySection />
      <ThreeJobsSection />
      <ResponsibilitiesSection />
      <TimelineSection />
      <PyroEmberSection />
      <FounderSection />
      <SelectiveFitSection />
      <FaqSection />
      <FinalCtaSection />
    </>
  );
}

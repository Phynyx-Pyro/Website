import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Calendar } from "lucide-react";

/**
 * Mobile-only fixed bottom CTA bar.
 * Source: appears on the homepage after the user scrolls roughly one viewport.
 * Hidden at scrollY=0, slides into view after scrolling.
 * lg:hidden — desktop never shows it.
 * Links to the custom /schedule route (no iframe).
 */
export function MobileStickyCta() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      // Visible after roughly one viewport of scroll.
      setVisible(window.scrollY > window.innerHeight * 0.9);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className="lg:hidden fixed inset-x-0 bottom-0 z-40 transition-transform duration-300 ease-out"
      style={{
        transform: visible ? "translateY(0)" : "translateY(100%)",
        paddingBottom: "env(safe-area-inset-bottom, 0px)",
      }}
      aria-hidden={!visible}
      // When hidden, make the entire bar (and its link) non-focusable and
      // non-interactive so keyboard/AT users cannot activate it. Restored
      // automatically once `visible` becomes true.
      inert={!visible}
    >
      <div className="bg-charcoal grain-charcoal border-t border-white/10 shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.5)]">
        <div className="mx-auto max-w-[420px] px-4 py-3 flex items-center gap-3">
          <Link
            to="/schedule"
            search={{ cta: "homepage_mobile_sticky" }}
            data-ui-placement="homepage_mobile_sticky"
            className="flex-1 min-w-0 inline-flex items-center justify-center gap-2 rounded-lg bg-phoenix px-4 py-2.5 text-[13px] font-semibold text-white shadow-lg transition-colors hover:bg-ember"
          >
            <Calendar className="w-4 h-4 shrink-0" />
            <span className="truncate">Schedule My Growth Call</span>
            <ArrowRight className="w-4 h-4 shrink-0" />
          </Link>
        </div>
      </div>
    </div>
  );
}

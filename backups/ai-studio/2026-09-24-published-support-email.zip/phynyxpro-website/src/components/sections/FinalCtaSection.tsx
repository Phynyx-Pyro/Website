import { DualCta } from "../DualCta";

export function FinalCtaSection() {
  return (
    <section className="py-16 lg:py-24 bg-phoenix text-white">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10 text-center">
        <p className="text-xs font-bold uppercase tracking-widest text-white/70 mb-3">
          Choose your next step
        </p>
        <h2 className="text-3xl lg:text-[44px] font-bold tracking-tight leading-tight max-w-3xl mx-auto">
          Ready to Talk? Book the Call First.
        </h2>
        <p className="mt-5 text-base text-white/80 leading-relaxed max-w-2xl mx-auto">
          Pick a time now with only your contact and practice details. We can gather revenue, ad
          budget, capacity, and funnel data after your call is booked.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row flex-wrap justify-center gap-3 sm:gap-4">
          <DualCta variant="dark" ctaSource="home-final" align="center" />
        </div>
        <p className="mt-8 text-sm text-white/70">
          Not a chiropractic practice? Explore{" "}
          <a href="/industries/home-services" className="underline hover:text-white">
            Home Services
          </a>{" "}
          or{" "}
          <a href="/industries/dental-medspa" className="underline hover:text-white">
            Dental & Medspa
          </a>
          .
        </p>
      </div>
    </section>
  );
}

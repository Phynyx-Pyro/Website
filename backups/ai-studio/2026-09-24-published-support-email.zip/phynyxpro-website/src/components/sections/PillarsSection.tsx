export function PillarsSection() {
  const pillars = [
    { kicker: "Chiropractic-first", title: "Built around the new-patient journey" },
    { kicker: "Full-funnel view", title: "From campaign source to start of care" },
    { kicker: "Operator-led", title: "A system shaped by practice reality" },
    { kicker: "Human handoff", title: "Your team steps in when it should" },
  ];
  return (
    <section className="py-16 lg:py-20 bg-linen border-y border-black/10">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
          Designed around the handoffs that decide patient acquisition
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {pillars.map((p) => (
            <div key={p.kicker} className="bg-white rounded-xl border border-black/10 p-5">
              <p className="text-sm font-bold text-phoenix">{p.kicker}</p>
              <p className="mt-2 text-sm text-ink leading-snug">{p.title}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 font-hand text-xl text-phoenix">this is where ad budget leaks →</p>
      </div>
    </section>
  );
}

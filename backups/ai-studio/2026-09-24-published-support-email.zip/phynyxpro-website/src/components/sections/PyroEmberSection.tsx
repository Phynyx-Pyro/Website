import { ASSETS } from "../../lib/assets";

function Bubble({ who, text, right }: { who: string; text: string; right?: boolean }) {
  return (
    <div className={`flex ${right ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm ${
          right
            ? "bg-flame/20 border border-flame/30 text-white"
            : "bg-white/10 border border-white/10 text-white/90"
        }`}
      >
        <p className="text-[10px] font-bold uppercase tracking-wider text-white/50 mb-0.5">{who}</p>
        {text}
      </div>
    </div>
  );
}

export function PyroEmberSection() {
  return (
    <section className="py-16 lg:py-24 bg-ink text-white grain-dark">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-flame mb-3">PYRO + Ember</p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight leading-tight max-w-3xl">
          PYRO Runs the Workflow. Ember Handles the Conversation
        </h2>
        <p className="mt-5 text-base text-white/70 leading-relaxed max-w-2xl">
          PYRO is the platform connecting response, qualification, appointment requests,
          confirmations, reminders, and reporting. Ember is the AI receptionist inside PYRO, with
          human handoff when your team should take over.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-12 items-start">
          <div className="lg:col-span-4">
            <div className="rounded-2xl bg-white/5 border border-white/10 p-6 flex items-center justify-center min-h-[280px]">
              <img
                src={ASSETS.emberHuman}
                alt="Ember AI receptionist with human handoff"
                className="max-h-[260px] w-auto object-contain"
                loading="lazy"
              />
            </div>
            <p className="mt-3 text-[11px] text-white/50 leading-relaxed">
              Illustrative workflow — not a promise of availability or autonomous booking. Scripts,
              escalation rules, calendar logic, and confirmation behavior are configured for each
              business.
            </p>
          </div>

          <div className="lg:col-span-8 space-y-4">
            <div className="rounded-xl bg-white/5 border border-white/10 p-5">
              <p className="text-[11px] font-bold uppercase tracking-wider text-flame">
                Active Inquiry
              </p>
              <p className="mt-1 text-sm text-white/80">Ember · AI receptionist</p>
            </div>

            <div className="rounded-xl bg-white/5 border border-white/10 p-5 space-y-4">
              <p className="text-[11px] font-bold uppercase tracking-wider text-flame">
                Qualification
              </p>
              <Bubble who="Ember" text="Are you looking to request a new-patient appointment?" />
              <Bubble who="Caller" text="Yes—mornings are usually best." right />
              <Bubble
                who="Ember"
                text="I can capture that preference for the team. Is there a day that works best?"
              />
              <p className="pt-2 text-[11px] font-bold uppercase tracking-wider text-flame">
                Appointment Request
              </p>
              <Bubble who="Caller" text="Thursday morning works." right />
              <Bubble
                who="Ember"
                text="I've captured Thursday morning as your preference. The team can confirm the available time."
              />
              <p className="pt-1 text-xs font-semibold text-flame">Appointment Request Captured</p>
            </div>

            <div className="rounded-xl bg-white/5 border border-white/10 p-5">
              <p className="text-[11px] font-bold uppercase tracking-wider text-flame">
                CRM Update
              </p>
              <div className="mt-3 space-y-2 text-xs">
                {[
                  "Lead record created",
                  "Campaign source retained",
                  "Request status updated",
                  "Staff confirmation handoff started",
                  "Handoff owner assigned",
                ].map((r) => (
                  <div key={r} className="flex items-center justify-between">
                    <span className="text-white/70">{r}</span>
                    <span className="text-flame font-semibold">Updated</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-flame/30 bg-flame/5 p-5">
              <p className="text-[11px] font-bold uppercase tracking-wider text-flame">Handoff</p>
              <p className="mt-2 text-sm text-white/80">
                Your team takes over when human judgment is needed
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

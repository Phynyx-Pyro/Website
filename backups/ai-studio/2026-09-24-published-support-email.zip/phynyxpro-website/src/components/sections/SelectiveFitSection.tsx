export function SelectiveFitSection() {
  return (
    <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
          Selective Fit
        </p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight max-w-3xl">
          Built for Practices Ready to Turn More Inquiries Into Patients
        </h2>
        <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl">
          Revenue matters, but readiness also depends on capacity, decision access, follow-up
          ownership, implementation timing, and the ability to track what happens after each
          inquiry.
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12">
          <div className="rounded-2xl bg-white border border-black/10 p-6 lg:p-8">
            <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
              Strong fit signals
            </p>
            <ul className="mt-5 space-y-3 text-sm text-ink leading-relaxed">
              <li className="flex gap-3">
                <span className="text-phoenix">✓</span>Capacity for additional new-patient
                evaluations
              </li>
              <li className="flex gap-3">
                <span className="text-phoenix">✓</span>Decision-maker access and intent to act
                within 90 days
              </li>
              <li className="flex gap-3">
                <span className="text-phoenix">✓</span>A consistent paid-media budget and realistic
                growth expectations
              </li>
              <li className="flex gap-3">
                <span className="text-phoenix">✓</span>A human owner for follow-up and outcome
                tracking
              </li>
            </ul>
          </div>
          <div className="rounded-2xl bg-white border border-black/10 p-6 lg:p-8">
            <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
              What usually needs to be in place first
            </p>
            <ul className="mt-5 space-y-3 text-sm text-ink leading-relaxed">
              <li className="flex gap-3">
                <span className="text-warm">•</span>No room on the calendar for new-patient
                evaluations
              </li>
              <li className="flex gap-3">
                <span className="text-warm">•</span>The goal is only the cheapest possible lead
              </li>
              <li className="flex gap-3">
                <span className="text-warm">•</span>No one can own escalations and outcome updates
              </li>
              <li className="flex gap-3">
                <span className="text-warm">•</span>Researching without access to the decision maker
              </li>
            </ul>
          </div>
        </div>
        <p className="mt-8 font-hand text-xl text-phoenix">fit protects both sides</p>
      </div>
    </section>
  );
}

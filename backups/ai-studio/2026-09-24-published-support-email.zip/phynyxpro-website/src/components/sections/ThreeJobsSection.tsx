export function ThreeJobsSection() {
  return (
    <section id="system-walkthrough" className="py-16 lg:py-24 bg-ivory grain scroll-mt-[84px]">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
          The PhynyxPro system
        </p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight max-w-3xl">
          One Operating System.
          <br />
          Three Jobs
        </h2>
        <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl">
          PhynyxPro is not just the ad account. It connects demand generation, the workflow after
          the click, and the practice-verified outcomes used to improve the system.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-12">
          <div className="rounded-2xl bg-white border border-black/10 p-6">
            <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
              01 · Attract
            </p>
            <h3 className="mt-3 text-lg font-bold text-ink leading-snug">
              Build Demand for Your Market
            </h3>
            <p className="mt-3 text-sm text-warm leading-relaxed">
              Managed paid acquisition, offer strategy, creative, and landing pages designed for
              chiropractic new-patient demand.
            </p>
            <div className="mt-5 rounded-xl bg-linen/70 border border-black/5 p-4">
              <p className="text-[11px] font-bold uppercase tracking-wider text-warm">
                A clear offer for a local patient need.
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-ink">
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2 py-1">Offer</span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2 py-1">Creative</span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2 py-1">
                  Landing page
                </span>
              </div>
              <p className="mt-3 text-[10px] uppercase tracking-wider text-warm">Campaign path</p>
            </div>
          </div>

          <div className="rounded-2xl bg-white border border-black/10 p-6">
            <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
              02 · Convert
            </p>
            <h3 className="mt-3 text-lg font-bold text-ink leading-snug">
              Give Qualified Inquiries a Defined Next Step
            </h3>
            <p className="mt-3 text-sm text-warm leading-relaxed">
              PYRO coordinates response, qualification, booking, confirmation, reminders, and the
              handoff to your team.
            </p>
            <ol className="mt-5 space-y-2.5">
              {[
                "New lead enters PYRO",
                "Ember begins the approved conversation",
                "Appointment request reaches the calendar",
                "Confirmation, reminders, and human handoff",
              ].map((step, i) => (
                <li key={step} className="flex items-start gap-3 text-sm text-ink">
                  <span className="mt-0.5 w-5 h-5 shrink-0 rounded-full bg-phoenix text-white text-[11px] font-bold flex items-center justify-center">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
            <p className="mt-4 font-hand text-base text-phoenix">one accountable handoff</p>
          </div>

          <div className="rounded-2xl bg-white border border-black/10 p-6">
            <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
              03 · Operate & Improve
            </p>
            <h3 className="mt-3 text-lg font-bold text-ink leading-snug">
              Use the Full Journey to Make Decisions
            </h3>
            <p className="mt-3 text-sm text-warm leading-relaxed">
              Review campaign activity alongside the appointment and patient stages your practice
              records—without presenting ad-platform leads as outcomes.
            </p>
            <div className="mt-5 rounded-xl bg-linen/70 border border-black/5 p-4 space-y-3">
              {[
                { k: "Campaign source", v: "Captured" },
                { k: "Appointment status", v: "Updated" },
                { k: "Show / start outcome", v: "Practice verified" },
              ].map((row) => (
                <div key={row.k} className="flex items-center justify-between text-xs">
                  <span className="text-warm">{row.k}</span>
                  <span className="font-semibold text-phoenix">{row.v}</span>
                </div>
              ))}
              <p className="pt-2 border-t border-black/5 text-[10px] uppercase tracking-wider text-warm">
                Decision record
              </p>
            </div>
          </div>
        </div>
        <p className="mt-8 text-sm font-semibold text-ink">
          The review starts with stage definitions everyone agrees on.
        </p>
      </div>
    </section>
  );
}

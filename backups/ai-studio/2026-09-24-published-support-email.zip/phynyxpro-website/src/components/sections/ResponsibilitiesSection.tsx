export function ResponsibilitiesSection() {
  return (
    <section className="py-16 lg:py-20 bg-linen border-y border-black/10">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="rounded-2xl bg-white border border-black/10 p-6 lg:p-8">
          <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
            PhynyxPro installs and operates
          </p>
          <ul className="mt-5 space-y-3 text-sm text-ink leading-relaxed">
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Campaign, offer, creative, and landing-page
              operation
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>PYRO pipeline, response, booking, and reminder
              workflows
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Ember configuration with defined human-handoff
              rules
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Source-to-stage reporting and an operating
              review cadence
            </li>
          </ul>
        </div>
        <div className="rounded-2xl bg-white border border-black/10 p-6 lg:p-8">
          <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
            Your practice provides
          </p>
          <ul className="mt-5 space-y-3 text-sm text-ink leading-relaxed">
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Access, approvals, calendar rules, and
              new-patient capacity
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Accurate services, FAQs, and escalation
              guidance
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>A person available when a conversation needs
              human judgment
            </li>
            <li className="flex gap-3">
              <span className="text-phoenix">•</span>Consistent Confirmed, Day 1 Show, and Start
              Care updates
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}

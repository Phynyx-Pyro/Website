import { useState } from "react";
import { DualCta } from "../DualCta";
import { ChevronDown } from "lucide-react";

const FAQS = [
  {
    q: "What happens after I click?",
    a: "You’ll enter last month’s inquiries, bookings, shows, starts, and media spend. We calculate your visible conversion rates, identify the largest drop-off, and show a conservative improvement scenario before you decide whether to book.",
  },
  {
    q: "Is PhynyxPro just ad management?",
    a: "No. Paid acquisition is one part of the system. PhynyxPro also coordinates the post-click workflow—response, qualification, appointment requests, confirmations, reminders, handoff, and stage reporting—through PYRO.",
  },
  {
    q: "How does Ember work with our team?",
    a: "Ember is the AI receptionist inside PYRO. It follows the practice-approved conversation and scheduling rules, then hands off when a person should take over. Your team remains responsible for clinical judgment and patient care.",
  },
  {
    q: "Do we have to replace our current CRM?",
    a: "The diagnostic maps your current tools before any recommendation is made. What can be connected or consolidated depends on the platforms, permissions, and workflow already in place.",
  },
  {
    q: "What does this cost?",
    a: "Paid media, implementation, and ongoing system operation are separate. Full campaign fits generally begin with at least $2,000 per month in paid media; the diagnostic determines whether the operating scope makes sense.",
  },
  {
    q: "Do you guarantee patient volume?",
    a: "No. PhynyxPro can install and operate the acquisition system, but patient volume and care decisions depend on market conditions, media investment, practice capacity, team execution, and clinical fit.",
  },
];

export function FaqSection() {
  const [open, setOpen] = useState<string>("item-0");

  return (
    <section className="py-16 lg:py-24 bg-ivory">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
          Straight answers
        </p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink">
          What happens after I click?
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mt-10">
          {/* Accessible accordion — first item open initially */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-white border border-black/10 overflow-hidden">
              {FAQS.map((f, i) => {
                const id = `item-${i}`;
                const isOpen = open === id;
                const panelId = `faq-panel-${i}`;
                const btnId = `faq-button-${i}`;
                return (
                  <div key={f.q} className={i > 0 ? "border-t border-black/10" : ""}>
                    <h3>
                      <button
                        id={btnId}
                        type="button"
                        aria-expanded={isOpen}
                        aria-controls={panelId}
                        onClick={() => setOpen(isOpen ? "" : id)}
                        className="flex w-full items-center justify-between gap-4 px-5 lg:px-6 py-4 lg:py-5 text-left text-sm lg:text-base font-bold text-ink hover:bg-linen/40 transition-colors cursor-pointer"
                      >
                        <span>{f.q}</span>
                        <ChevronDown
                          className={`w-5 h-5 shrink-0 text-phoenix transition-transform duration-200 ${
                            isOpen ? "rotate-180" : ""
                          }`}
                        />
                      </button>
                    </h3>
                    <div
                      id={panelId}
                      role="region"
                      aria-labelledby={btnId}
                      hidden={!isOpen}
                      className="px-5 lg:px-6 pb-5 lg:pb-6"
                    >
                      <p className="text-sm text-warm leading-relaxed max-w-prose">{f.a}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Snapshot preview card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-ink text-white grain-dark p-6 lg:p-8 sticky top-28">
              <p className="text-[11px] font-bold uppercase tracking-widest text-flame">
                Snapshot preview
              </p>
              <h3 className="mt-3 text-xl font-bold leading-snug">
                See your conversion math before you book a call.
              </h3>
              <p className="mt-3 text-sm text-white/60 leading-relaxed">
                Bring the numbers you have. Missing data is part of what we'll map.
              </p>
              <div className="mt-6">
                <DualCta variant="dark" ctaSource="home-faq" align="left" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

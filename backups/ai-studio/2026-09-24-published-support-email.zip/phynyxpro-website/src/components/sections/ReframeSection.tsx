export function ReframeSection() {
  const cards = [
    {
      tag: "Lead captured",
      title: "The Campaign Did Its Job",
      body: "Source and offer context enter the pipeline with the inquiry.",
    },
    {
      tag: "Appointment request",
      title: "The Handoff Decides What Happens Next",
      body: "Response, qualification, and booking remove avoidable friction.",
    },
    {
      tag: "Verified outcome",
      title: "The Practice Closes the Loop",
      body: "Confirmed, Day 1 Show, and Start Care are recorded separately.",
    },
  ];
  return (
    <section className="py-16 lg:py-24 bg-ivory grain">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">The reframe</p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight max-w-3xl">
          Buying More Leads Cannot Fix What Happens After the Click
        </h2>
        <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl">
          A campaign can fill the inbox while slow response, unclear qualification, scheduling
          friction, and inconsistent follow-up leave the calendar open. Lead count alone cannot tell
          you where the patient journey broke.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          {cards.map((c) => (
            <div key={c.tag} className="rounded-2xl bg-white border border-black/10 p-6">
              <p className="text-[11px] font-bold uppercase tracking-wider text-phoenix">{c.tag}</p>
              <h3 className="mt-3 text-lg font-bold text-ink leading-snug">{c.title}</h3>
              <p className="mt-3 text-sm text-warm leading-relaxed">{c.body}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 text-lg lg:text-xl font-bold text-ink">
          A lead is a starting event—not a patient outcome.
        </p>
      </div>
    </section>
  );
}

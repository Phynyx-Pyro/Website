import { ASSETS } from "../../lib/assets";

const HANDOFFS = ["Campaign → response", "Request → show", "Show → start"];

export function FounderSection() {
  return (
    <section className="py-16 lg:py-24 bg-ivory">
      {/* Source: card x≈335-930 (595px), right text x≈993, gap≈64px */}
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-[595px_1fr] gap-10 lg:gap-[64px] items-center">
        {/* LEFT: dark branded operator-perspective quote card with phoenix icon,
            Campaign→response / Request→show / Show→start row, and overlapping
            white Andrew Higdon, DC founder badge. */}
        <div className="order-2 lg:order-1">
          <div className="relative rounded-2xl bg-charcoal text-white grain-charcoal p-8 lg:p-10 shadow-xl min-h-[420px] lg:min-h-[460px] flex flex-col">
            {/* Rust phoenix icon near upper-left */}
            <img
              src={ASSETS.pyroIcon}
              alt=""
              aria-hidden="true"
              className="w-9 h-9 object-contain mb-8"
            />

            {/* Quote + handoffs anchored toward lower portion */}
            <div className="mt-auto">
              <p className="text-[11px] font-bold uppercase tracking-widest text-flame mb-3">
                Operator perspective
              </p>
              <p className="text-2xl lg:text-[28px] font-bold leading-snug text-white max-w-[300px]">
                Measure the handoffs the practice can influence.
              </p>

              <div className="mt-6 flex flex-wrap gap-2.5">
                {HANDOFFS.map((h) => (
                  <span
                    key={h}
                    className="rounded-md bg-white/10 px-3 py-1.5 text-xs font-semibold text-white/85"
                  >
                    {h}
                  </span>
                ))}
              </div>
            </div>

            {/* Overlapping white founder badge anchored lower-right */}
            <div className="absolute -bottom-5 right-6 lg:right-8 rounded-xl bg-white border border-black/10 shadow-2xl px-5 py-3.5 flex items-center gap-3">
              <img
                src={ASSETS.pyroIcon}
                alt=""
                aria-hidden="true"
                className="w-7 h-7 object-contain"
              />
              <div>
                <p className="text-sm font-bold text-ink leading-tight">Andrew Higdon, DC</p>
                <p className="text-[11px] text-warm leading-tight">
                  Founder · Practicing chiropractor
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: copy */}
        <div className="order-1 lg:order-2">
          <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
            Founder &amp; operator
          </p>
          <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight">
            Andrew Higdon, DC
          </h2>
          <p className="mt-2 text-sm font-semibold text-warm">Practicing chiropractor</p>

          <p className="mt-6 text-xs font-bold uppercase tracking-widest text-phoenix">
            Why the model is different
          </p>
          <h3 className="mt-3 text-2xl lg:text-[48px] font-bold text-ink leading-[1.1] max-w-xl">
            Built Around the Realities of a Chiropractic Front Desk
          </h3>
          <p className="mt-5 text-base lg:text-[18px] text-warm leading-relaxed max-w-xl">
            Andrew Higdon, DC, is a practicing chiropractor and the founder of PhynyxPro. That
            operator perspective shapes the system: campaign reporting is only the beginning;
            response, appointment status, Day 1 attendance, and the practice-recorded start decision
            complete the view.
          </p>
          <p className="mt-5 text-base lg:text-[18px] text-warm leading-relaxed max-w-xl">
            PhynyxPro operates the acquisition infrastructure. Your team retains clinical judgment,
            patient relationships, scheduling capacity, and the responsibility to keep real outcomes
            current.
          </p>
          <p className="mt-6 font-hand text-xl text-phoenix">
            practice reality over vanity metrics.
          </p>
        </div>
      </div>
    </section>
  );
}

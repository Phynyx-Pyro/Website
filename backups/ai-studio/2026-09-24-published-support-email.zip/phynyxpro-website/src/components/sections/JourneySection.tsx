import { DualCta } from "../DualCta";

export function JourneySection() {
  const stages = [
    {
      n: "STAGE 01",
      t: "Lead",
      d: "An inquiry enters with its source and campaign context attached.",
    },
    {
      n: "STAGE 02",
      t: "Appointment Request",
      d: "The prospect takes a real scheduling step—not just another click.",
    },
    {
      n: "STAGE 03",
      t: "Confirmed",
      d: "The appointment is booked and its confirmation status is visible.",
    },
    {
      n: "STAGE 04",
      t: "Day 1 Show",
      d: "Your team records whether the new patient arrived for the visit.",
    },
    {
      n: "STAGE 05",
      t: "Start Care",
      d: "The practice records the next-care decision in its system.",
    },
  ];
  return (
    <section className="py-16 lg:py-24 bg-ink text-white grain-dark">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-flame mb-3">
          The measurable journey
        </p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight leading-tight max-w-3xl">
          One Path. Five Stages Your Practice Can Actually See
        </h2>
        <p className="mt-5 text-base text-white/70 leading-relaxed max-w-2xl">
          PhynyxPro connects campaign activity to the operational stages that matter, while your
          team verifies the patient outcomes only it can know.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mt-12">
          {stages.map((s) => (
            <div
              key={s.n}
              className="rounded-xl bg-white/5 border border-white/10 p-5 backdrop-blur-sm"
            >
              <p className="text-[10px] font-bold uppercase tracking-widest text-flame">{s.n}</p>
              <h3 className="mt-2 text-base font-bold text-white">{s.t}</h3>
              <p className="mt-2 text-xs text-white/60 leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 text-sm text-white/70 max-w-2xl leading-relaxed">
          Start with a 3-minute growth snapshot. Use exact numbers, estimates, or mark what is not
          tracked. Missing data is part of what we'll map.
        </p>
        <div className="mt-8">
          <DualCta variant="dark" ctaSource="home-journey" align="left" />
        </div>
      </div>
    </section>
  );
}

export function TimelineSection() {
  const phases = [
    {
      n: "1",
      tag: "Before Day One",
      title: "Onboarding Complete",
      body: "We confirm the inputs, access, and approvals required to start the core build.",
      items: [
        "Confirm offer, capacity, locations, and handoff owners",
        "Receive advertising, CRM, calendar, domain, and reporting access",
        "Collect required brand assets, approvals, and business details",
      ],
    },
    {
      n: "2",
      tag: "Days 1–3",
      title: "Campaign Build",
      body: "We build the campaign strategy, Meta lead flow, creative, and source tracking.",
      items: [
        "Campaign strategy and offer path",
        "Meta lead ads, forms, copy, and creative setup",
        "Tracking and source structure",
      ],
    },
    {
      n: "3",
      tag: "Days 4–7",
      title: "System Configuration",
      body: "We connect the pipeline, calendar, automations, and included handoff rules.",
      items: [
        "PYRO pipeline and calendar connection",
        "Follow-up, reminders, and status automation",
        "Ember and staff handoff rules where included",
      ],
    },
    {
      n: "4",
      tag: "Days 8–10",
      title: "QA and Launch-Ready",
      body: "We test the end-to-end journey, confirm ownership, and prepare for a controlled launch.",
      items: [
        "End-to-end lead and booking tests",
        "Team ownership and escalation review",
        "Final approvals and controlled launch preparation",
      ],
    },
  ];
  return (
    <section className="py-16 lg:py-24 bg-ivory grain">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
          The first 7–10 days
        </p>
        <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight max-w-3xl">
          Your Core Acquisition System, Built in 7–10 Days
        </h2>
        <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl">
          The build window begins once onboarding inputs, account access, and required approvals are
          complete. From there, we build the campaign, Meta lead flow, pipeline, follow-up, and
          handoff process.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          {phases.map((p) => (
            <div key={p.n} className="rounded-2xl bg-white border border-black/10 p-6">
              <div className="flex items-center gap-3">
                <span className="w-9 h-9 rounded-full bg-phoenix text-white text-sm font-bold flex items-center justify-center">
                  {p.n}
                </span>
                <p className="text-[11px] font-bold uppercase tracking-wider text-phoenix">
                  {p.tag}
                </p>
              </div>
              <h3 className="mt-4 text-base font-bold text-ink">{p.title}</h3>
              <p className="mt-2 text-xs text-warm leading-relaxed">{p.body}</p>
              <ul className="mt-4 space-y-2 text-xs text-ink">
                {p.items.map((it) => (
                  <li key={it} className="flex gap-2">
                    <span className="text-phoenix">•</span>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-8 text-xs text-warm leading-relaxed max-w-3xl">
          7–10 days is the standard core-build window after complete onboarding. Missing access,
          delayed approvals or client inputs, carrier/A2P registration, and other third-party
          dependencies can move the live-launch date.
        </p>
      </div>
    </section>
  );
}

import { Link } from "@tanstack/react-router";
import { ASSETS } from "../lib/assets";

export function Footer() {
  return (
    <footer className="bg-ink text-white grain-dark pt-16 pb-12 border-t border-white/10">
      <div className="mx-auto max-w-[1320px] px-5 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          <div className="lg:col-span-2">
            <Link to="/" className="inline-block mb-4" aria-label="Phynyx Pro home">
              <img src={ASSETS.logoLight} alt="Phynyx Pro" className="h-8 w-auto object-contain" />
            </Link>
            <p className="max-w-[340px] text-sm text-white/60 leading-relaxed">
              The acquisition operating system connecting demand, response, booking, and verified
              outcomes.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-flame mb-4">System</h4>
            <ul className="flex flex-col gap-2.5 text-sm text-white/70">
              <li>
                <Link to="/growth-system" className="hover:text-white transition-colors">
                  Growth System
                </Link>
              </li>
              <li>
                <Link to="/results" className="hover:text-white transition-colors">
                  Measurement
                </Link>
              </li>
              <li>
                <Link to="/pyro-ember" className="hover:text-white transition-colors">
                  PYRO & Ember
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-flame mb-4">
              Industries
            </h4>
            <ul className="flex flex-col gap-2.5 text-sm text-white/70">
              <li>
                <Link to="/industries/chiropractic" className="hover:text-white transition-colors">
                  Chiropractic
                </Link>
              </li>
              <li>
                <Link to="/industries/home-services" className="hover:text-white transition-colors">
                  Home Services
                </Link>
              </li>
              <li>
                <Link to="/industries/dental-medspa" className="hover:text-white transition-colors">
                  Dental & Medspa
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-flame mb-4">
              Technology
            </h4>
            <p className="text-sm font-bold text-white">PYRO by PhynyxPro</p>
            <p className="mt-2 max-w-[200px] text-xs text-white/60 leading-relaxed">
              PYRO is the operating platform. Ember is the AI receptionist inside it.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-flame mb-4">Company</h4>
            <ul className="flex flex-col gap-2.5 text-sm text-white/70">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link to="/client-login" className="hover:text-white transition-colors">
                  Client Login
                </Link>
              </li>
              <li>
                <Link to="/support" className="hover:text-white transition-colors">
                  Support
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-white/40">
          <p>
            © {new Date().getFullYear()} PhynyxPro. Acquisition systems for appointment-driven
            businesses.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy-policy" className="hover:text-white/70 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-white/70 transition-colors">
              Terms
            </Link>
            <Link to="/fulfillment" className="hover:text-white/70 transition-colors">
              Fulfillment Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

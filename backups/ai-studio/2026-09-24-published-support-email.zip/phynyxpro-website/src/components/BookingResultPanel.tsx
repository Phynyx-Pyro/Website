import { Check, Clock, AlertCircle, RotateCcw, Info, Mail, type LucideIcon } from "lucide-react";
import type { BookingResult } from "../lib/calendar";

type DayGroup = { dateKey: string; label: string; sub: string; slots: string[] };

function formatTimeLabel(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  } catch {
    return iso;
  }
}

/**
 * In-slot failure banner shown below the slot grid when the booking did NOT
 * advance to "done". Distinguishes retryable "unavailable" (409 slot conflict)
 * from ambiguous "uncertain" (network/5xx after POST — an appointment may
 * exist, so we don't encourage an immediate retry).
 */
export function SlotFailureBanner({
  result,
  onDismiss,
}: {
  result: Extract<BookingResult, { ok: false }>;
  onDismiss: () => void;
}) {
  const isUnavail = result.reason === "unavailable";
  const Icon: LucideIcon = isUnavail ? AlertCircle : Mail;
  return (
    <div
      className={`rounded-xl border p-4 flex items-start gap-3 ${
        isUnavail ? "border-phoenix/30 bg-phoenix/5" : "border-ink/20 bg-ivory"
      }`}
    >
      <Icon className={`w-5 h-5 shrink-0 mt-0.5 ${isUnavail ? "text-phoenix" : "text-ink"}`} />
      <div className="flex-1">
        <p className="text-sm font-bold text-ink">
          {isUnavail ? "That time is no longer available" : "Check your email to confirm"}
        </p>
        <p className="text-[12px] text-warm mt-1 leading-relaxed">{result.message}</p>
        {isUnavail ? (
          <button
            type="button"
            onClick={onDismiss}
            className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Choose another time
          </button>
        ) : (
          <p className="mt-3 text-[12px] text-warm/80 leading-relaxed">
            Please don&apos;t submit again — your request may have been received. Contact us if you
            don&apos;t see a confirmation email shortly.
          </p>
        )}
      </div>
    </div>
  );
}

/**
 * "Done" step — renders a confirmed message (with the real appointment
 * reference) OR an accepted-but-unverified message (request received, check
 * email, don't re-submit). Never fabricates an appointment ID.
 */
export function DonePanel({
  result,
  email,
  phone,
  consent,
  selectedGroup,
  selectedTime,
}: {
  result: Extract<BookingResult, { ok: true }>;
  email: string;
  phone: string;
  consent: boolean;
  selectedGroup: DayGroup | null;
  selectedTime: string | null;
}) {
  if (result.status === "confirmed") {
    return (
      <div className="text-center py-8">
        <div className="w-14 h-14 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto">
          <Check className="w-7 h-7" />
        </div>
        <h2 className="mt-5 text-xl font-bold text-ink">You&apos;re on the calendar</h2>
        <p className="mt-2 text-sm text-warm leading-relaxed max-w-md mx-auto">
          We&apos;ll send a confirmation to <span className="font-semibold text-ink">{email}</span>{" "}
          {consent && (
            <>
              and text <span className="font-semibold text-ink">{phone}</span>{" "}
            </>
          )}
          for your booked time
          {selectedGroup && selectedTime ? (
            <>
              {" "}
              (
              <span className="font-semibold text-ink">
                {selectedGroup.label} {selectedGroup.sub} at {formatTimeLabel(selectedTime)}
              </span>
              )
            </>
          ) : null}
          .
        </p>
        <p className="mt-3 text-[11px] text-warm/70 leading-relaxed">
          Appointment reference: {result.appointmentId}
        </p>
      </div>
    );
  }

  // accepted-unverified
  return (
    <div className="text-center py-8">
      <div className="w-14 h-14 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto">
        <Info className="w-7 h-7" />
      </div>
      <h2 className="mt-5 text-xl font-bold text-ink">Your request was received</h2>
      <p className="mt-2 text-sm text-warm leading-relaxed max-w-md mx-auto">
        We submitted your booking request for{" "}
        {selectedGroup && selectedTime ? (
          <span className="font-semibold text-ink">
            {selectedGroup.label} {selectedGroup.sub} at {formatTimeLabel(selectedTime)}
          </span>
        ) : (
          "your selected time"
        )}
        , but we could not confirm it from the response.
      </p>
      <p className="mt-3 text-sm text-warm leading-relaxed max-w-md mx-auto">
        Please check your email at <span className="font-semibold text-ink">{email}</span> for an
        authoritative confirmation. If you don&apos;t see one shortly, contact us — please
        don&apos;t submit again.
      </p>
    </div>
  );
}

export { formatTimeLabel };
export type { DayGroup };
// Re-export icons used by the slot grid so ScheduleForm doesn't need to import
// them separately if it wants to keep its import list stable.
export { Clock };

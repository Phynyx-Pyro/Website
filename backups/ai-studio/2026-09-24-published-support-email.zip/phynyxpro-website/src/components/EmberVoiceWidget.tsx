import { useEffect, useRef } from "react";

/**
 * Real Ember Embedded/Inline Voice AI visualizer.
 *
 * Mounts the configured inline widget (Embedded/Inline + Visualizer) from the
 * platform widget loader. No iframe, no simulation — the loader renders the
 * actual visualizer globe.
 *
 * Lifecycle robustness:
 * The HighLevel loader asynchronously creates a `<chat-widget>` custom element
 * and appends it directly under `<body>` (NOT inside our placeholder). The
 * generated element looks like:
 *   <chat-widget data-loader-instance-id="loader-..." source="custom-code" ...>
 * It has NO data-widget-id attribute, so we match by the stable `source` attr.
 *
 * A module-level MutationObserver on document.body persists across React dev
 * remounts and SPA route reentry. It reconciles ALL matching custom elements:
 * exactly one is retained inside the active hero container; extras are removed.
 * When the route unmounts (activeContainer = null) any late-async widget from a
 * prior loader execution is removed as an orphan. The observer is disconnected
 * after a short grace period so it does not run forever on unrelated routes.
 */
const WIDGET_ID = "69e2597506d5d59faa8b2a91";
const LOCATION_ID = "DsRnzA2tcoiwklSgjBtR";
const LOADER_SRC = "https://widgets.leadconnectorhq.com/loader.js";
const RESOURCES_URL = "https://widgets.leadconnectorhq.com/chat-widget/loader.js";

/** Match the real generated custom element (no data-widget-id on it). */
const WIDGET_SELECTOR = 'chat-widget[source="custom-code"]';

/** Grace period (ms) to keep observing after unmount for late loader widgets. */
const OBSERVER_GRACE_MS = 6000;

// --- Module-level singleton state (survives remounts / route reentry) ---
let bodyObserver: MutationObserver | null = null;
let activeContainer: HTMLElement | null = null;
let cleanupTimer: ReturnType<typeof setTimeout> | null = null;

/**
 * Reconcile every matching <chat-widget> on the page.
 * - With an active container: keep exactly one (prefer one already inside),
 *   move it into the container if needed, and remove all duplicates/orphans.
 * - Without an active container (route unmounted): remove all orphans.
 */
function reconcileWidgets(): void {
  const widgets = Array.from(document.querySelectorAll<HTMLElement>(WIDGET_SELECTOR));
  if (widgets.length === 0) return;

  if (activeContainer) {
    // Prefer a widget already in the container; otherwise adopt the first.
    const inContainer = widgets.find((w) => w.parentElement === activeContainer);
    const keep = inContainer ?? widgets[0];
    if (!keep) return;
    if (!inContainer) {
      activeContainer.appendChild(keep);
    }
    // Remove every other instance (duplicates from reentry / late loader).
    for (const w of widgets) {
      if (w !== keep) w.remove();
    }
  } else {
    // No active route — remove all orphan widgets.
    for (const w of widgets) w.remove();
  }
}

/** Create the persistent body observer if it does not already exist. */
function ensureObserver(): void {
  if (bodyObserver) return;
  bodyObserver = new MutationObserver(() => {
    const widgets = document.querySelectorAll<HTMLElement>(WIDGET_SELECTOR);
    if (widgets.length === 0) return;
    // Skip work if already perfectly reconciled (one widget in container).
    const first = widgets.item(0);
    if (activeContainer && widgets.length === 1 && first?.parentElement === activeContainer) {
      return;
    }
    reconcileWidgets();
  });
  bodyObserver.observe(document.body, { childList: true, subtree: true });
}

/** Schedule observer teardown after the grace period (only if still inactive). */
function scheduleObserverTeardown(): void {
  if (cleanupTimer) clearTimeout(cleanupTimer);
  cleanupTimer = setTimeout(() => {
    cleanupTimer = null;
    if (!activeContainer && bodyObserver) {
      bodyObserver.disconnect();
      bodyObserver = null;
    }
  }, OBSERVER_GRACE_MS);
}

export function EmberVoiceWidget({ className }: { className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Cancel any pending teardown — we're active again.
    if (cleanupTimer) {
      clearTimeout(cleanupTimer);
      cleanupTimer = null;
    }

    // Register as the active container and ensure the observer is running.
    activeContainer = container;
    ensureObserver();

    // 1) Inline placeholder the loader scans for.
    const placeholder = document.createElement("div");
    placeholder.setAttribute("data-chat-widget", "");
    placeholder.setAttribute("data-widget-id", WIDGET_ID);
    placeholder.setAttribute("data-location-id", LOCATION_ID);
    container.appendChild(placeholder);

    // 2) Adopt any existing widget immediately (reentry / orphan from prior load).
    reconcileWidgets();

    // 3) (Re)load the loader script. Remove any prior tag first so we never
    //    accumulate duplicate scripts; re-adding re-triggers the loader on
    //    reentry so a fresh widget is created.
    const oldScript = document.querySelector<HTMLScriptElement>(`script[src="${LOADER_SRC}"]`);
    if (oldScript) oldScript.remove();

    const script = document.createElement("script");
    script.src = LOADER_SRC;
    script.async = true;
    script.setAttribute("data-resources-url", RESOURCES_URL);
    script.setAttribute("data-widget-id", WIDGET_ID);
    document.body.appendChild(script);

    return () => {
      // Deactivate so the observer treats any late widget as an orphan.
      activeContainer = null;

      // Remove our placeholder and any widget we own in the container.
      container.innerHTML = "";

      // Eagerly remove orphan widgets currently under <body>.
      const orphans = document.querySelectorAll<HTMLElement>(WIDGET_SELECTOR);
      for (const o of orphans) o.remove();

      // Remove the loader script tag (already-executed code may still finish).
      const s = document.querySelector<HTMLScriptElement>(`script[src="${LOADER_SRC}"]`);
      if (s) s.remove();

      // Keep the observer alive briefly to catch late-async widgets from a
      // loader that already finished fetching/executing after cleanup.
      scheduleObserverTeardown();
    };
  }, []);

  return <div ref={containerRef} className={className} data-chat-widget-hero-container />;
}

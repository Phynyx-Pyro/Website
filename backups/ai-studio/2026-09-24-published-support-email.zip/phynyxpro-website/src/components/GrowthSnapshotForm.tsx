import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { AlertCircle, ArrowRight, RotateCcw } from "lucide-react";

export function GrowthSnapshotForm({
  defaultIndustry = "chiropractic",
}: {
  defaultIndustry?: string;
}) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [marketingSms, setMarketingSms] = useState(false);
  const [nonMarketingSms, setNonMarketingSms] = useState(false);
  const [aiVoiceConsent, setAiVoiceConsent] = useState(false);
  // No backend exists in this draft — show an honest unavailable state, never a fake
  // "session created" / "intake saved" success.
  const [status, setStatus] = useState<"idle" | "attempting" | "unavailable">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("attempting");
    window.setTimeout(() => setStatus("unavailable"), 600);
  };

  return (
    <div className="bg-white rounded-2xl p-6 lg:p-8 border border-black/10 shadow-[0_20px_50px_-10px_rgba(20,19,18,0.15)]">
      <div className="flex items-center justify-between pb-4 mb-5 border-b border-black/10">
        <div>
          <h3 className="text-lg font-bold text-ink">Build My Growth Snapshot</h3>
          <p className="text-xs text-warm">Save progress, then enter your numbers.</p>
        </div>
        <span className="text-[11px] font-bold tracking-wider uppercase bg-linen px-2.5 py-1 rounded text-warm">
          3-Min Snapshot
        </span>
      </div>

      {/* Honest unavailable banner — no fake intake/session creation claim */}
      {status === "unavailable" && (
        <div className="mb-5 rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-bold text-ink">Snapshot save is not available yet</p>
            <p className="text-[12px] text-warm mt-1 leading-relaxed">
              This draft has no connected submission backend. Your contact details were not saved,
              sent, or used to create an intake session. Your entries are preserved below so you can
              retry once a backend is connected.
            </p>
            <button
              type="button"
              onClick={() => setStatus("idle")}
              className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Retry
            </button>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="gsf-first" className="block text-xs font-semibold text-ink mb-1">
              First name <span className="text-phoenix">*</span>
            </label>
            <input
              id="gsf-first"
              type="text"
              required
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix bg-white"
            />
          </div>
          <div>
            <label htmlFor="gsf-last" className="block text-xs font-semibold text-ink mb-1">
              Last name
            </label>
            <input
              id="gsf-last"
              type="text"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix bg-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="gsf-email" className="block text-xs font-semibold text-ink mb-1">
              Work email <span className="text-phoenix">*</span>
            </label>
            <input
              id="gsf-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix bg-white"
            />
          </div>
          <div>
            <label htmlFor="gsf-phone" className="block text-xs font-semibold text-ink mb-1">
              Phone number <span className="text-phoenix">*</span>
            </label>
            <input
              id="gsf-phone"
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix bg-white"
            />
          </div>
        </div>

        {/* Consent Checkboxes — separate, unchecked by default */}
        <div className="pt-2 space-y-3">
          <p className="text-[11px] font-bold text-warm uppercase tracking-wider">
            Contact preferences (optional)
          </p>

          <label className="flex items-start gap-2.5 text-[11.5px] leading-snug text-warm cursor-pointer select-none">
            <input
              type="checkbox"
              checked={marketingSms}
              onChange={(e) => setMarketingSms(e.target.checked)}
              className="mt-0.5 rounded border-black/20 text-phoenix focus:ring-phoenix"
            />
            <span>
              I agree to receive marketing text messages from PhynyxPro about its services, my
              growth snapshot, and booking a diagnostic, including automated messages. Message
              frequency varies. Message and data rates may apply. Reply STOP to opt out or HELP for
              help. Consent is not a condition of purchase.
            </span>
          </label>

          <label className="flex items-start gap-2.5 text-[11.5px] leading-snug text-warm cursor-pointer select-none">
            <input
              type="checkbox"
              checked={nonMarketingSms}
              onChange={(e) => setNonMarketingSms(e.target.checked)}
              className="mt-0.5 rounded border-black/20 text-phoenix focus:ring-phoenix"
            />
            <span>
              I agree to receive non-marketing text messages from PhynyxPro about my requested
              diagnostic, including appointment confirmations, reminders, and schedule changes.
              Message frequency varies. Message and data rates may apply. Reply STOP to opt out or
              HELP for help.
            </span>
          </label>

          <label className="flex items-start gap-2.5 text-[11.5px] leading-snug text-warm cursor-pointer select-none">
            <input
              type="checkbox"
              checked={aiVoiceConsent}
              onChange={(e) => setAiVoiceConsent(e.target.checked)}
              className="mt-0.5 rounded border-black/20 text-phoenix focus:ring-phoenix"
            />
            <span>
              I agree that PhynyxPro may call the number I provided about its services, my growth
              snapshot, and diagnostic using an automated system and an artificial or AI-generated
              voice. Consent is not a condition of purchase. I may revoke consent at any time by
              asking the caller to stop or contacting PhynyxPro.
            </span>
          </label>
        </div>

        <p className="text-[11px] text-warm/80 leading-tight pt-1">
          This is an unpublished draft with no connected submission backend. Continuing does not
          save, send, or store your contact details.{" "}
          <Link to="/privacy-policy" className="underline hover:text-ink">
            Privacy Policy
          </Link>{" "}
          ·{" "}
          <Link to="/terms" className="underline hover:text-ink">
            Terms
          </Link>
        </p>

        <button
          type="submit"
          disabled={status === "attempting"}
          className="w-full mt-2 py-3.5 px-6 rounded-lg bg-phoenix hover:bg-ember disabled:opacity-60 text-white font-semibold text-sm transition-colors shadow-lg flex items-center justify-center gap-2"
        >
          {status === "attempting" ? "Starting…" : "Start My 3-Minute Snapshot"}
          {status !== "attempting" && <ArrowRight className="w-4 h-4" />}
        </button>

        <p className="text-[11px] text-center text-warm/70">
          No submission backend is connected in this draft. Your details are not saved or sent.
        </p>
      </form>
    </div>
  );
}

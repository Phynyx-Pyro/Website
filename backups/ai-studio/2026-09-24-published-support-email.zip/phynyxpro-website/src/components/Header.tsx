import { Link, useLocation } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown, Menu, X, ArrowRight, Calendar } from "lucide-react";
import { ASSETS } from "../lib/assets";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [industriesOpen, setIndustriesOpen] = useState(false);
  // Source hides the Schedule header CTA on the entire /growth-assessment journey.
  const hideCta = useLocation({ select: (s) => s.pathname === "/growth-assessment" });

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-ivory/95 backdrop-blur-sm border-b border-black/5">
      <nav className="mx-auto flex h-[84px] max-w-[1320px] items-center justify-between px-6 lg:px-10">
        {/* Logo */}
        <Link to="/" className="shrink-0" aria-label="Phynyx Pro home">
          <div className="relative h-[38px] w-[170px] lg:h-[42px] lg:w-[188px] flex items-center">
            <img
              src={ASSETS.logoDark}
              alt="Phynyx Pro"
              className="h-full w-auto object-contain object-left"
            />
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-6 xl:gap-8 text-[14px] xl:text-[14.5px] font-medium text-ink/80">
          <Link
            to="/growth-system"
            activeProps={{ className: "text-phoenix font-semibold" }}
            className="hover:text-phoenix transition-colors"
          >
            Growth System
          </Link>

          {/* Industries Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setIndustriesOpen(true)}
            onMouseLeave={() => setIndustriesOpen(false)}
          >
            <button
              type="button"
              onClick={() => setIndustriesOpen(!industriesOpen)}
              className="flex items-center gap-1.5 hover:text-phoenix transition-colors py-2"
            >
              Industries
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform ${industriesOpen ? "rotate-180" : ""}`}
              />
            </button>

            {industriesOpen && (
              <div className="absolute top-full left-0 w-60 rounded-xl bg-white p-2 shadow-xl border border-black/10 flex flex-col gap-1 z-50">
                <Link
                  to="/industries"
                  className="px-3 py-2 text-xs font-bold uppercase tracking-wider text-warm hover:text-phoenix border-b border-black/5 pb-2"
                >
                  All Industries
                </Link>
                <Link
                  to="/industries/chiropractic"
                  className="px-3 py-2 text-sm rounded-lg hover:bg-linen/60 text-ink hover:text-phoenix transition-colors"
                >
                  Chiropractic Practices
                </Link>
                <Link
                  to="/industries/home-services"
                  className="px-3 py-2 text-sm rounded-lg hover:bg-linen/60 text-ink hover:text-phoenix transition-colors"
                >
                  Home Services
                </Link>
                <Link
                  to="/industries/dental-medspa"
                  className="px-3 py-2 text-sm rounded-lg hover:bg-linen/60 text-ink hover:text-phoenix transition-colors"
                >
                  Dental & Medspa
                </Link>
              </div>
            )}
          </div>

          <Link
            to="/results"
            activeProps={{ className: "text-phoenix font-semibold" }}
            className="hover:text-phoenix transition-colors"
          >
            Measurement
          </Link>
          <Link
            to="/pyro-ember"
            activeProps={{ className: "text-phoenix font-semibold" }}
            className="hover:text-phoenix transition-colors"
          >
            PYRO & Ember
          </Link>
          <Link
            to="/about"
            activeProps={{ className: "text-phoenix font-semibold" }}
            className="hover:text-phoenix transition-colors"
          >
            About
          </Link>
        </div>

        {/* CTA — hidden on the /growth-assessment journey (source) */}
        <div className="hidden lg:flex items-center">
          {!hideCta && (
            <Link
              to="/schedule"
              search={{ cta: "site-header-desktop" }}
              className="group flex items-center gap-2.5 whitespace-nowrap rounded-lg bg-phoenix px-5 py-3.5 text-[14px] font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
            >
              <Calendar className="w-4 h-4" />
              Schedule My Growth Call
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </Link>
          )}
        </div>

        {/* Mobile Toggle */}
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden flex h-10 w-10 items-center justify-center rounded-lg border border-black/10 bg-white"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden bg-ivory border-b border-black/10 px-6 py-6 flex flex-col gap-4 text-base font-medium shadow-xl">
          <Link
            to="/growth-system"
            onClick={() => setMobileOpen(false)}
            className="hover:text-phoenix"
          >
            Growth System
          </Link>

          <div className="flex flex-col gap-2 pl-2 border-l-2 border-phoenix/20">
            <span className="text-xs font-bold uppercase tracking-wider text-warm">Industries</span>
            <Link
              to="/industries"
              onClick={() => setMobileOpen(false)}
              className="text-sm hover:text-phoenix"
            >
              Overview
            </Link>
            <Link
              to="/industries/chiropractic"
              onClick={() => setMobileOpen(false)}
              className="text-sm hover:text-phoenix"
            >
              Chiropractic
            </Link>
            <Link
              to="/industries/home-services"
              onClick={() => setMobileOpen(false)}
              className="text-sm hover:text-phoenix"
            >
              Home Services
            </Link>
            <Link
              to="/industries/dental-medspa"
              onClick={() => setMobileOpen(false)}
              className="text-sm hover:text-phoenix"
            >
              Dental & Medspa
            </Link>
          </div>

          <Link to="/results" onClick={() => setMobileOpen(false)} className="hover:text-phoenix">
            Measurement
          </Link>
          <Link
            to="/pyro-ember"
            onClick={() => setMobileOpen(false)}
            className="hover:text-phoenix"
          >
            PYRO & Ember
          </Link>
          <Link to="/about" onClick={() => setMobileOpen(false)} className="hover:text-phoenix">
            About
          </Link>

          {!hideCta && (
            <Link
              to="/schedule"
              search={{ cta: "site-header-mobile" }}
              onClick={() => setMobileOpen(false)}
              className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-phoenix py-3.5 text-sm font-semibold text-white"
            >
              <Calendar className="w-4 h-4" />
              Schedule My Growth Call
              <ArrowRight className="w-4 h-4" />
            </Link>
          )}
        </div>
      )}
    </header>
  );
}

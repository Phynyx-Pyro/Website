import { useState } from "react";
import { ChevronDown } from "lucide-react";

export function HomepageFaqs() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const faqs = [
    {
      q: "What happens after I click?",
      a: "You’ll enter last month’s inquiries, bookings, shows, starts, and media spend. We calculate your visible conversion rates, identify the largest drop-off, and show a conservative improvement scenario before you decide whether to book.",
    },
    {
      q: "Is PhynyxPro just ad management?",
      a: "No. Paid acquisition is one part of the system. PhynyxPro also coordinates the post-click workflow—response, qualification, appointment requests, confirmations, reminders, handoff, and stage reporting—through PYRO.",
    },
    {
      q: "How does Ember work with our team?",
      a: "Ember is the AI receptionist inside PYRO. It follows the practice-approved conversation and scheduling rules, then hands off when a person should take over. Your team remains responsible for clinical judgment and patient care.",
    },
    {
      q: "Do we have to replace our current CRM?",
      a: "The diagnostic maps your current tools before any recommendation is made. What can be connected or consolidated depends on the platforms, permissions, and workflow already in place.",
    },
    {
      q: "What does this cost?",
      a: "Paid media, implementation, and ongoing system operation are separate. Full campaign fits generally begin with at least $2,000 per month in paid media; the diagnostic determines whether the operating scope makes sense.",
    },
    {
      q: "Do you guarantee patient volume?",
      a: "No. PhynyxPro can install and operate the acquisition system, but patient volume and care decisions depend on market conditions, media investment, practice capacity, team execution, and clinical fit.",
    },
  ];

  return (
    <div className="space-y-3 pt-2">
      {faqs.map((faq, idx) => (
        <div key={idx} className="border border-black/10 rounded-xl bg-white overflow-hidden">
          <button
            type="button"
            onClick={() => toggleFaq(idx)}
            className="w-full text-left px-5 py-4 font-semibold text-sm flex items-center justify-between gap-4 text-ink hover:text-phoenix transition-colors"
          >
            <span>{faq.q}</span>
            <ChevronDown
              className={`w-4 h-4 shrink-0 transition-transform ${openFaq === idx ? "rotate-180" : ""}`}
            />
          </button>
          {openFaq === idx && (
            <div className="px-5 pb-4 text-xs leading-relaxed text-warm border-t border-black/5 pt-3">
              {faq.a}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

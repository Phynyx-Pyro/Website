// Presentational subcomponents for the GrowthAssessmentFunnel.
// Extracted to keep the funnel component focused on state/logic.

import type { ReactNode } from "react";
import { Clock, TriangleAlert } from "lucide-react";
import type { FunnelMetric, SequenceIssue } from "../lib/growth-snapshot-calc";

export function MetaItem({ icon: Icon, label }: { icon: typeof Clock; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <Icon className="w-3.5 h-3.5 text-phoenix" />
      {label}
    </span>
  );
}

export function FreeInput({
  id,
  label,
  hint,
  placeholder,
  value,
  onChange,
}: {
  id: string;
  label: string;
  hint: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-bold text-ink mb-1">
        {label}
      </label>
      <p className="text-[11px] text-warm mb-2 leading-snug min-h-[28px]">{hint}</p>
      <input
        id={id}
        type="number"
        min="0"
        step="1"
        inputMode="numeric"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-lg font-bold text-ink bg-ivory/40 focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix"
      />
    </div>
  );
}

export function RateStat({
  label,
  value,
  sub,
}: {
  label: string;
  value: number | null;
  sub: string;
}) {
  return (
    <div>
      <p className="text-[10px] font-bold uppercase tracking-wider text-white/50">{label}</p>
      <p className="text-xl font-bold text-flame mt-1">{value !== null ? `${value}%` : "—"}</p>
      <p className="text-[10px] text-white/60">{sub}</p>
    </div>
  );
}

export function Field({
  id,
  label,
  required,
  value,
  onChange,
  type,
}: {
  id: string;
  label: string;
  required?: boolean;
  value: string;
  onChange: (v: string) => void;
  type: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1">
        {label} {required && <span className="text-phoenix">*</span>}
      </label>
      <input
        id={id}
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix bg-ivory/40"
      />
    </div>
  );
}

export function SelectField({
  id,
  label,
  value,
  onChange,
  options,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1">
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix bg-white"
      >
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}

export function ConsentCheck({
  title,
  checked,
  onChange,
  text,
}: {
  title: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  text: string;
}) {
  return (
    <label className="flex items-start gap-2.5 text-[11.5px] leading-snug text-warm cursor-pointer select-none py-1">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="mt-0.5 rounded border-black/20 text-phoenix focus:ring-phoenix shrink-0"
      />
      <span>
        <span className="font-bold text-ink block mb-0.5">{title}</span>
        {text}
      </span>
    </label>
  );
}

export function MetricInput({
  label,
  hint,
  metric,
  onChange,
}: {
  label: string;
  hint: string;
  metric: FunnelMetric;
  onChange: (m: FunnelMetric) => void;
}) {
  const id = `metric-${label.replace(/\s+/g, "-").toLowerCase()}`;
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1">
        {label}
      </label>
      <p className="text-[11px] text-warm mb-2 leading-snug">{hint}</p>
      <div className="flex gap-2">
        <input
          id={id}
          type="number"
          min="0"
          inputMode="decimal"
          placeholder="—"
          value={metric.value}
          disabled={metric.quality === "not-tracked"}
          onChange={(e) => onChange({ ...metric, value: e.target.value })}
          className="flex-1 px-3.5 py-2.5 rounded-lg border border-black/15 text-sm font-semibold text-ink bg-ivory/40 focus:outline-none focus:border-phoenix focus:ring-1 focus:ring-phoenix disabled:opacity-40"
        />
        <select
          value={metric.quality}
          onChange={(e) =>
            onChange({
              ...metric,
              quality: e.target.value as FunnelMetric["quality"],
              value: e.target.value === "not-tracked" ? "" : metric.value,
            })
          }
          className="px-3 py-2.5 rounded-lg border border-black/15 text-xs font-semibold text-ink bg-white focus:outline-none focus:border-phoenix"
        >
          <option value="exact">Exact</option>
          <option value="estimate">Estimate</option>
          <option value="not-tracked">Not tracked</option>
        </select>
      </div>
    </div>
  );
}

export function KpiTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-ivory/60 border border-black/5 px-3 py-2.5 text-center">
      <p className="text-[10px] font-bold uppercase tracking-wider text-warm">{label}</p>
      <p className="text-lg font-bold text-ink mt-0.5">{value}</p>
    </div>
  );
}

export function SequenceIssueBanner({
  title,
  issues,
  footer,
}: {
  title: string;
  issues: SequenceIssue[];
  footer: string;
}) {
  return (
    <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
      <TriangleAlert className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
      <div className="flex-1">
        <p className="text-sm font-bold text-ink">{title}</p>
        <ul className="mt-1 space-y-1">
          {issues.map((issue) => (
            <li key={issue.field} className="text-[12px] text-warm leading-relaxed">
              {issue.message}
            </li>
          ))}
        </ul>
        <p className="text-[12px] text-warm mt-1">{footer}</p>
      </div>
    </div>
  );
}

export function ErrorBanner({
  title,
  message,
  detail,
}: {
  title: string;
  message: string;
  detail?: string;
}) {
  return (
    <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
      <TriangleAlert className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
      <div className="flex-1">
        <p className="text-sm font-bold text-ink">{title}</p>
        <p className="text-[12px] text-warm mt-1 leading-relaxed">{message}</p>
        {detail && <p className="text-[12px] text-warm mt-1">{detail}</p>}
      </div>
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-2xl bg-white border border-black/10 shadow-[0_20px_50px_-10px_rgba(20,19,18,0.15)] ${className}`}
    >
      {children}
    </div>
  );
}

export const PRIMARY_BUTTON =
  "px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/50 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center gap-2 shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)]";

export const FULL_BUTTON =
  "w-full px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/50 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)]";

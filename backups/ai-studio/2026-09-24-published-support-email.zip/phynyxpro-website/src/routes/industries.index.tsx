import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ArrowRight } from "lucide-react";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/industries/")({
  head: () => ({
    meta: [
      { title: "Industries | PhynyxPro" },
      {
        name: "description",
        content:
          "Built for Chiropractic. Adaptable to other appointment-driven businesses — Home Services, Dental & Medspa, and other service businesses.",
      },
      { property: "og:title", content: "Industries — PhynyxPro" },
      {
        property: "og:description",
        content:
          "The same response, booking, and recorded-outcome framework configured for different appointment-driven businesses.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndustriesPage,
});

function IndustriesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, ~1120px column, 72px split-color H1 over four lines */}
        <section className="bg-ivory grain pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Industries
            </p>
            <h1 className="text-[40px] sm:text-[52px] lg:text-[72px] font-bold tracking-tight leading-[1.05] max-w-[920px]">
              <span className="text-ink">Built for Chiropractic.</span>
              <br />
              <span className="text-phoenix">Adaptable to Other</span>
              <br />
              <span className="text-phoenix">Appointment-Driven</span>
              <br />
              <span className="text-phoenix">Businesses</span>
            </h1>
            <p className="mt-7 text-base lg:text-lg text-warm leading-relaxed max-w-[640px]">
              Explore how the same response, booking, and recorded-outcome framework can be
              configured for different appointment-driven businesses.
            </p>
          </div>
        </section>

        {/* Industry cards — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Chiropractic */}
            <Link
              to="/industries/chiropractic"
              className="group flex flex-col rounded-2xl overflow-hidden bg-white border border-black/10 hover:border-phoenix transition-all shadow-sm"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={ASSETS.industryChiro}
                  alt="Chiropractic"
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-6 flex flex-col flex-1">
                <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
                  Chiropractic-first
                </p>
                <h3 className="mt-2 text-lg font-bold text-ink group-hover:text-phoenix transition-colors">
                  Chiropractic
                </h3>
                <p className="mt-2 text-sm text-warm leading-relaxed flex-1">
                  Built around the chiropractic patient journey.
                </p>
                <p className="mt-3 text-xs text-warm/80 leading-relaxed">
                  A practicing chiropractor's operator perspective informs the handoffs from first
                  inquiry through Day 1 Show and Start Care.
                </p>
                <span className="mt-4 text-xs font-semibold text-phoenix flex items-center gap-1">
                  Learn more
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>

            {/* Home Services */}
            <Link
              to="/industries/home-services"
              className="group flex flex-col rounded-2xl overflow-hidden bg-white border border-black/10 hover:border-phoenix transition-all shadow-sm"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={ASSETS.industryHome}
                  alt="Home Services"
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-6 flex flex-col flex-1">
                <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
                  Adaptable for
                </p>
                <h3 className="mt-2 text-lg font-bold text-ink group-hover:text-phoenix transition-colors">
                  Home Services
                </h3>
                <p className="mt-2 text-sm text-warm leading-relaxed flex-1">
                  Connect the inbox to scheduled work.
                </p>
                <p className="mt-3 text-xs text-warm/80 leading-relaxed">
                  For roofing, plumbing, and HVAC workflows that need a clearer path from inquiry to
                  estimate request, scheduled work, and recorded outcome.
                </p>
                <span className="mt-4 text-xs font-semibold text-phoenix flex items-center gap-1">
                  Learn more
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>

            {/* Dental & Medspa */}
            <Link
              to="/industries/dental-medspa"
              className="group flex flex-col rounded-2xl overflow-hidden bg-white border border-black/10 hover:border-phoenix transition-all shadow-sm"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={ASSETS.industryDental}
                  alt="Dental & Medspa"
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-6 flex flex-col flex-1">
                <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
                  Adaptable for
                </p>
                <h3 className="mt-2 text-lg font-bold text-ink group-hover:text-phoenix transition-colors">
                  Dental & Medspa
                </h3>
                <p className="mt-2 text-sm text-warm leading-relaxed flex-1">
                  Connect inquiry, follow-up, and appointment status.
                </p>
                <p className="mt-3 text-xs text-warm/80 leading-relaxed">
                  For dental and medspa workflows that benefit from prompt response, approved
                  follow-up, scheduling, and recorded-outcome visibility.
                </p>
                <span className="mt-4 text-xs font-semibold text-phoenix flex items-center gap-1">
                  Learn more
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          </div>
        </section>

        {/* Fit Check — Other Service Businesses — ivory */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-5">
              <img
                src={ASSETS.industryOther}
                alt="Other service businesses"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Fit check
              </p>
              <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1]">
                Other Service Businesses
              </h2>
              <p className="mt-4 text-base text-warm leading-relaxed">
                See whether the workflow fits your business.
              </p>
              <p className="mt-3 text-sm text-warm leading-relaxed max-w-xl">
                Appointment-driven businesses can use the growth snapshot to compare funnel
                visibility, operating readiness, capacity, and investment context.
              </p>
              <div className="mt-6">
                <Link
                  to="/growth-assessment"
                  search={{ cta: "industries-other-card", industry: "other-service" }}
                  className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
                >
                  Get My Growth Snapshot
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Footer CTA — linen */}
        <section className="py-16 lg:py-24 bg-linen border-t border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 text-center">
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px] mx-auto">
              Not Sure if PhynyxPro Is Right for Your Industry?
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px] mx-auto">
              Start with a 3-minute growth snapshot. See the largest visible drop-off before
              deciding whether to continue to a working diagnostic.
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                to="/growth-assessment"
                search={{ cta: "industries-footer", industry: "chiropractic" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

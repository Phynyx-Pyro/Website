import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ArrowRight } from "lucide-react";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/industries/dental-medspa")({
  head: () => ({
    meta: [
      { title: "Dental & Medspa Consultation System | PhynyxPro" },
      {
        name: "description",
        content:
          "Turn more consultation inquiries into attended visits. A clear path from inquiry to staff handoff, scheduling, reminders, and a recorded outcome.",
      },
      { property: "og:title", content: "Dental & Medspa Consultation System — PhynyxPro" },
      {
        property: "og:description",
        content:
          "High-consideration appointments need a clear path from inquiry to staff handoff, scheduling, reminders, and a recorded outcome.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DentalMedspaIndustryPage,
});

const SYSTEM_ITEMS = [
  {
    t: "High-Consideration Appointments",
    d: "Keep cosmetic, elective, and consultation inquiries visible through the next recorded step.",
  },
  {
    t: "Prompt Response",
    d: "Ember can support approved conversation flows and route staff handoffs on connected channels.",
  },
  {
    t: "After-Hours Inquiry Handling",
    d: "Configured workflows can acknowledge off-hours inquiries and capture an appointment request for follow-up.",
  },
  {
    t: "Confirmation & Reminders",
    d: "Approved confirmation and reminder sequences support the team's attendance workflow.",
  },
  {
    t: "Treatment-Path Visibility",
    d: "Connect available source and campaign data with appointment status and recorded treatment outcomes.",
  },
  {
    t: "Eligible-Patient Reactivation",
    d: "Permission-based outreach can be configured for eligible existing contacts with recorded channel consent and no opt-out.",
  },
];

function DentalMedspaIndustryPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, ~1120px column, 64px H1 */}
        <section className="bg-ivory grain pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Dental & Medspa
              </p>
              <h1 className="text-[36px] sm:text-[48px] lg:text-[64px] font-bold tracking-tight text-ink leading-[1.05] max-w-[640px]">
                Turn More Consultation Inquiries Into Attended Visits
              </h1>
              <p className="mt-7 text-base lg:text-lg text-warm leading-relaxed max-w-[560px]">
                High-consideration appointments need a clear path from inquiry to staff handoff,
                scheduling, reminders, and a recorded outcome. PhynyxPro connects that workflow.
              </p>
              <div className="mt-8">
                <Link
                  to="/growth-assessment"
                  search={{ cta: "dental-medspa-hero", audience: "healthcare" }}
                  className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
                >
                  Get My Patient Growth Snapshot
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
            <div className="lg:col-span-5">
              <img
                src={ASSETS.dental}
                alt="Modern dental practice"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3] shadow-sm"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* How the Workflow Supports — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              How the workflow supports
            </p>
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              How the Workflow Supports Dental and Medspa Teams
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
              {SYSTEM_ITEMS.map((s, i) => (
                <div key={s.t} className="rounded-xl bg-white border border-black/10 p-5 shadow-sm">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-phoenix">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 text-base font-bold text-ink">{s.t}</h3>
                  <p className="mt-2 text-sm text-warm leading-relaxed">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer CTA — ivory */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 text-center">
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px] mx-auto">
              Ready to Map the Path From Request to Confirmed Appointment?
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px] mx-auto">
              Start with a 3-minute growth snapshot. Enter last month's inquiries, bookings, visits,
              outcomes, and media spend to see the largest visible drop-off.
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                to="/growth-assessment"
                search={{ cta: "dental-medspa-footer", audience: "healthcare" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Patient Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ASSETS } from "../lib/assets";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About PhynyxPro | Operator-Led Growth Architecture" },
      {
        name: "description",
        content:
          "Andrew Higdon, DC, is a practicing chiropractor and the founder of PhynyxPro. His operator perspective shapes a system centered on the handoffs between first inquiry, appointment request, attendance, and the recorded outcome.",
      },
      { property: "og:title", content: "About PhynyxPro | Operator-Led Growth Architecture" },
      {
        property: "og:description",
        content:
          "Andrew Higdon, DC, is a practicing chiropractor and the founder of PhynyxPro. His operator perspective shapes a system centered on the handoffs between first inquiry, appointment request, attendance, and the recorded outcome.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const BELIEFS = [
  {
    title: "Transparency",
    body: "Connected reporting is designed to keep available spend, lead, appointment, and recorded-outcome data visible in one place.",
  },
  {
    title: "Outcomes Over Activity",
    body: "We connect campaign and response metrics to appointment status and business-recorded outcomes when the source data is available.",
  },
  {
    title: "Readiness Before Scope",
    body: "The growth snapshot weighs capacity, decision access, timing, operating ownership, revenue, and paid-media investment before recommending a next step.",
  },
  {
    title: "Operator Perspective",
    body: "Andrew Higdon, DC, is a practicing chiropractor. That perspective keeps the work grounded in real handoffs and team capacity.",
  },
];

function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Two-column top: dark quote card LEFT (full-height), headline + paragraphs RIGHT */}
        <section className="bg-ivory pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-6 lg:px-0">
            <div className="grid grid-cols-1 lg:grid-cols-[442px_1fr] gap-10 lg:gap-[47px] items-start">
              {/* LEFT: charcoal textured operator quote card — desktop left; mobile AFTER copy (order-2) */}
              <div className="relative rounded-2xl bg-charcoal text-white grain-charcoal p-8 lg:p-10 shadow-xl flex flex-col min-h-[480px] lg:min-h-[589px] lg:mt-10 order-2 lg:order-1">
                {/* Rust phoenix icon near upper-left */}
                <img
                  src={ASSETS.pyroIcon}
                  alt=""
                  className="w-9 h-9 object-contain mb-8"
                  aria-hidden="true"
                />
                {/* Label + quote + attribution anchored near bottom (source: label y516, quote y548) */}
                <div className="mt-auto">
                  <p className="text-xs font-bold uppercase tracking-widest text-flame mb-4">
                    Operator perspective
                  </p>
                  <p className="text-2xl lg:text-[30px] font-bold leading-snug text-white max-w-[300px]">
                    Measure the handoffs the team can influence.
                  </p>
                  <div className="mt-8 pt-6 border-t border-white/10">
                    <p className="text-lg font-bold text-white">Andrew Higdon, DC</p>
                    <p className="mt-1 text-sm text-white/60">Founder · Practicing chiropractor</p>
                  </div>
                </div>
              </div>

              {/* RIGHT: headline + three paragraphs — desktop right; mobile FIRST (order-1), label stays near y≈165 */}
              <div className="flex flex-col justify-start order-1 lg:order-2">
                <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                  About PhynyxPro
                </p>
                <h1 className="text-[40px] sm:text-[52px] lg:text-[64px] font-bold tracking-tight text-ink leading-[1.05]">
                  Built With a Practicing Chiropractor&rsquo;s Perspective
                </h1>
                <div className="mt-7 space-y-5 max-w-[520px]">
                  <p className="text-base text-warm leading-relaxed">
                    Andrew Higdon, DC, is a practicing chiropractor and the founder of PhynyxPro.
                    His operator perspective shapes a system centered on what happens between first
                    inquiry, appointment request, attendance, and the recorded outcome.
                  </p>
                  <p className="text-base text-warm leading-relaxed">
                    PhynyxPro is designed to connect advertising, response, appointment requests,
                    confirmations, reminders, and outcome reporting. PYRO coordinates the workflow,
                    with Ember as the AI receptionist inside the platform.
                  </p>
                  <p className="text-base text-warm leading-relaxed">
                    The operating principle is simple: make the workflow inspectable, distinguish
                    recorded outcomes from assumptions, and improve the handoffs the business can
                    control.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* What We Believe — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <h2 className="text-[28px] sm:text-[34px] lg:text-[40px] font-bold tracking-tight text-ink leading-[1.1]">
              What We Believe
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mt-10">
              {BELIEFS.map((b) => (
                <div
                  key={b.title}
                  className="rounded-xl bg-white border border-black/10 p-6 shadow-sm"
                >
                  <div className="flex items-center gap-2.5 mb-3">
                    <img src={ASSETS.pyroIcon} alt="" className="w-6 h-6 object-contain" />
                    <h3 className="text-lg font-bold text-ink">{b.title}</h3>
                  </div>
                  <p className="text-sm text-warm leading-relaxed">{b.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* A Working Model Built for Clarity — ivory */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-[28px] sm:text-[34px] lg:text-[40px] font-bold tracking-tight text-ink leading-[1.1]">
                A Working Model Built for Clarity
              </h2>
              <div className="mt-6 space-y-4 max-w-[520px]">
                <p className="text-base text-warm leading-relaxed">
                  The engagement model emphasizes documented responsibilities, visible handoffs, and
                  a shared review cadence so the business and the operating team can work from the
                  same record.
                </p>
                <p className="text-base text-warm leading-relaxed">
                  Platform access, integrations, managed services, and communication paths are
                  defined for each engagement during the diagnostic and documented in the client
                  agreement.
                </p>
              </div>
            </div>

            {/* Illustrative workspace image — badge restored on the image */}
            <div className="relative rounded-2xl overflow-hidden border border-black/10 shadow-lg">
              <img
                src={ASSETS.clientTeam}
                alt="Illustrative workspace"
                className="w-full h-auto object-cover"
              />
              <span className="absolute top-4 left-4 inline-flex items-center gap-1.5 rounded-full bg-white/90 backdrop-blur-sm border border-black/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-phoenix">
                Illustrative workspace
              </span>
            </div>
          </div>
        </section>

        {/* Footer CTA — linen */}
        <section className="py-16 lg:py-24 bg-linen border-t border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <h2 className="text-[28px] sm:text-[34px] lg:text-[40px] font-bold tracking-tight text-ink leading-[1.1] max-w-[680px]">
              Let&rsquo;s Find Out if We&rsquo;re the Right Fit
            </h2>
            <p className="mt-5 text-base text-warm leading-relaxed max-w-[560px]">
              Start with a 3-minute growth snapshot. See the largest visible drop-off before
              deciding whether to continue to a working diagnostic.
            </p>
            <div className="mt-8">
              <Link
                to="/growth-assessment"
                search={{ cta: "about-footer" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

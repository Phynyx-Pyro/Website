import { createFileRoute } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { HomepageHero } from "../components/HomepageHero";
import { HomepageSystemSections } from "../components/HomepageSystemSections";
import { MobileStickyCta } from "../components/MobileStickyCta";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PhynyxPro | From Ad Click to First Visit" },
      {
        name: "description",
        content:
          "We run your Meta ads and connect rapid response, booking, reminders, and team handoffs for chiropractic practices.",
      },
      { property: "og:title", content: "PhynyxPro — From Ad Click to First Visit" },
      {
        property: "og:description",
        content:
          "Patient acquisition operating system for chiropractic practices. Track each lead from campaign source through confirmed appointments, first visits, and starts of care.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: ASSETS.heroChiro },
      { name: "twitter:image", content: ASSETS.heroChiro },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px]">
        <HomepageHero />
        <HomepageSystemSections />
      </main>
      <Footer />
      {/* Mobile-only fixed bottom CTA bar — hidden at top, slides in after ~1 viewport.
          Bottom padding prevents it from covering content/controls on a 390px viewport. */}
      <div className="h-[64px] lg:h-0" aria-hidden="true" />
      <MobileStickyCta />
    </div>
  );
}
// AI Studio route index refresh v9

import { createFileRoute } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { DualCta } from "../components/DualCta";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/results")({
  head: () => ({
    meta: [
      { title: "Measurement Approach | PhynyxPro" },
      {
        name: "description",
        content:
          "PhynyxPro connects available campaign, response, appointment, and outcome data so your team can see where follow-up needs attention.",
      },
      { property: "og:title", content: "Measurement Approach — PhynyxPro" },
      {
        property: "og:description",
        content:
          "From campaign spend to recorded outcomes. Connected reporting keeps spend, lead, appointment, and outcome data visible in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResultsPage,
});

const FRAMEWORK_METRICS = [
  { t: "Advertising Investment", d: "What you spend on campaigns" },
  { t: "Leads Generated", d: "People who express interest" },
  { t: "Appointment Requests", d: "Inquiries that take a scheduling step" },
  { t: "Confirmed Appointments", d: "Requests with a booked time recorded" },
  { t: "Appointments Attended", d: "Confirmed appointments recorded as attended" },
  { t: "Recorded Customers / Outcomes", d: "Recorded care or service outcomes" },
  { t: "Revenue Context", d: "Recorded revenue associated with available source data" },
];

const REPORTING_ITEMS = [
  { t: "Advertising Spend", d: "Available spend by connected platform and campaign." },
  { t: "Lead Volume & Source", d: "Available source and campaign records for captured leads." },
  { t: "Response Time", d: "Response-time records for inquiries on connected channels." },
  { t: "Request Rate", d: "How many captured leads took an appointment-request step." },
  { t: "Confirmation Rate", d: "How many appointment requests became confirmed bookings." },
  { t: "Show Rate", d: "How many confirmed appointments were recorded as attended." },
  {
    t: "Revenue Context",
    d: "Recorded revenue associated with available source and campaign data.",
  },
];

function ResultsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, content starts x≈396, H1 y≈202. Bottom padding
            places the next section eyebrow near source y≈688. */}
        <section className="bg-ivory pt-12 lg:pt-[81px] pb-40 lg:pb-[230px]">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-0">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
              Measurement approach
            </p>
            <h1 className="text-4xl lg:text-[72px] font-bold tracking-tight leading-[1.05]">
              <span className="text-ink">See the Full Journey.</span>
              <br />
              <span className="text-phoenix">Not Just the First Click</span>
            </h1>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-2xl">
              PhynyxPro connects available campaign, response, appointment, and outcome data so your
              team can see where follow-up needs attention.
            </p>
          </div>
        </section>

        {/* Framework — pale ivory (same as hero), content x≈396, begins ~y718 */}
        <section className="bg-ivory pt-4 lg:pt-8 pb-24 lg:pb-32 border-t border-black/5">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-0">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
              Measurement framework
            </p>
            <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight leading-tight max-w-3xl text-ink">
              From Campaign Spend to Recorded Outcomes
            </h2>
            <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl">
              Clicks and impressions are only the beginning. We connect early indicators to
              appointment and revenue outcomes when the underlying data is available.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-12">
              {FRAMEWORK_METRICS.map((m, i) => (
                <div key={m.t} className="rounded-xl bg-white border border-black/10 p-5 shadow-sm">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-phoenix">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 text-sm font-bold text-ink leading-snug">{m.t}</h3>
                  <p className="mt-2 text-xs text-warm leading-relaxed">{m.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Transparency — ivory, no dotted texture, business-owner illustration restored */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-0 grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-5">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                Transparency is the methodology
              </p>
              <h2 className="text-2xl lg:text-3xl font-bold tracking-tight text-ink leading-tight">
                Connected reporting keeps available spend, lead, appointment, and outcome data
                visible in one place.
              </h2>
              <p className="mt-5 text-sm text-warm leading-relaxed">
                The reporting approach keeps first-touch metrics and downstream outcomes visible
                together, using the records available from your connected systems.
              </p>

              {/* Business-owner illustration in the reporting-view section */}
              <div className="mt-8 rounded-2xl overflow-hidden border border-black/10 shadow-lg">
                <img
                  src={ASSETS.businessOwner}
                  alt="Illustrative business reporting review"
                  className="w-full h-auto object-cover"
                  loading="lazy"
                />
              </div>
            </div>

            <div className="lg:col-span-7">
              <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix mb-4">
                What the reporting view is designed to include
              </p>
              <div className="space-y-3">
                {REPORTING_ITEMS.map((r) => (
                  <div
                    key={r.t}
                    className="rounded-xl bg-white border border-black/10 p-4 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4"
                  >
                    <span className="text-sm font-bold text-ink sm:w-56 shrink-0">{r.t}</span>
                    <span className="text-sm text-warm leading-relaxed">{r.d}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA — linen, no dotted texture */}
        <section className="py-16 lg:py-24 bg-linen border-t border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-0 text-center">
            <h2 className="text-3xl lg:text-[40px] font-bold tracking-tight text-ink leading-tight max-w-3xl mx-auto">
              Ready to Map Your Current Acquisition Path?
            </h2>
            <p className="mt-5 text-base text-warm leading-relaxed max-w-2xl mx-auto">
              If you are ready to talk, choose a time now. If you want to see your numbers first,
              build the free snapshot.
            </p>
            <div className="mt-8 flex justify-center">
              <DualCta variant="light" ctaSource="results-final" align="center" />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

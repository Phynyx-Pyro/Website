import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Mail, HelpCircle } from "lucide-react";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "Contact PhynyxPro | Support" },
      {
        name: "description",
        content:
          "Send a question about PhynyxPro or your PYRO account. This is not an emergency or guaranteed-response channel.",
      },
      { property: "og:title", content: "Contact PhynyxPro | Support" },
      {
        property: "og:description",
        content:
          "Send a question about PhynyxPro or your PYRO account. This is not an emergency or guaranteed-response channel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SupportPage,
});

const SUPPORT_EMAIL = "craig@phynyxpro.com";
const SUPPORT_SUBJECT = "PhynyxPro inquiry";

function SupportPage() {
  const mailtoHref = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(SUPPORT_SUBJECT)}`;

  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px] pb-20">
        <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
          {/* Centered intro with simple question icon */}
          <div className="max-w-[640px] mx-auto text-center mb-10">
            <div className="w-12 h-12 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto mb-5">
              <HelpCircle className="w-6 h-6" />
            </div>
            <h1 className="text-[34px] sm:text-[42px] lg:text-[52px] font-bold tracking-tight text-ink leading-[1.1]">
              Contact PhynyxPro
            </h1>
            <p className="mt-5 text-base text-warm leading-relaxed">
              Send a question about PhynyxPro or your PYRO account. This is not an emergency or
              guaranteed-response channel.
            </p>
            <p className="mt-3 text-sm text-warm/80 leading-relaxed">
              Current clients with an urgent operational issue should use the contact route listed
              in their signed client agreement.
            </p>
          </div>

          {/* Email contact card */}
          <div className="max-w-[560px] mx-auto bg-white p-8 rounded-2xl border border-black/10 shadow-lg">
            <div className="text-center">
              <div className="w-14 h-14 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto">
                <Mail className="w-7 h-7" />
              </div>
              <h2 className="mt-5 text-xl font-bold text-ink">Email us</h2>
              <p className="mt-2 text-sm text-warm leading-relaxed max-w-md mx-auto">
                Click the button below to open your email app with a message addressed to our team.
              </p>

              <a
                href={mailtoHref}
                className="mt-6 w-full inline-flex items-center justify-center gap-2 py-3.5 bg-phoenix hover:bg-ember text-white font-semibold text-sm rounded-lg transition-colors"
              >
                <Mail className="w-4 h-4" />
                Email craig@phynyxpro.com
              </a>

              {/* Visible address for manual copy when no mail app is available */}
              <div className="mt-6 pt-6 border-t border-black/10">
                <p className="text-xs font-semibold text-ink mb-2">
                  No email app? Copy the address:
                </p>
                <code className="px-3 py-1.5 rounded-lg bg-ivory/60 border border-black/10 text-sm text-ink select-all">
                  {SUPPORT_EMAIL}
                </code>
                <p className="mt-3 text-[12px] text-warm/80 leading-relaxed">
                  The email link opens your email app, but nothing is sent until you press send
                  there.
                </p>
              </div>
            </div>

            <p className="mt-6 text-xs text-warm/80 leading-relaxed">
              Your information is handled according to our{" "}
              <Link to="/privacy-policy" className="text-phoenix font-semibold hover:underline">
                Privacy Policy
              </Link>
              .
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

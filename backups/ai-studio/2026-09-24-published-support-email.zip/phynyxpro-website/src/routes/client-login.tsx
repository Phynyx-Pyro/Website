import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ASSETS } from "../lib/assets";
import { Lock, ArrowUpRight, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/client-login")({
  head: () => ({
    meta: [
      { title: "Client Login | PhynyxPro" },
      {
        name: "description",
        content:
          "Access your PYRO dashboard, CRM pipeline, reporting, and available growth-system tools.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Client Login | PhynyxPro" },
      {
        property: "og:description",
        content:
          "Access your PYRO dashboard, CRM pipeline, reporting, and available growth-system tools.",
      },
    ],
  }),
  component: ClientLoginPage,
});

function ClientLoginPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px] pb-20 flex items-center justify-center">
        <div className="w-full max-w-[560px] px-5">
          {/* Centered intro with rust lock icon */}
          <div className="text-center mb-8">
            <div className="w-12 h-12 rounded-full bg-phoenix/10 text-phoenix flex items-center justify-center mx-auto mb-5">
              <Lock className="w-6 h-6" />
            </div>
            <h1 className="text-[34px] sm:text-[42px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1]">
              Client Login
            </h1>
            <p className="mt-4 text-sm text-warm leading-relaxed max-w-[420px] mx-auto">
              Access your PYRO dashboard, CRM pipeline, reporting, and available growth-system
              tools.
            </p>
          </div>

          {/* White PYRO login card */}
          <div className="bg-white p-8 rounded-2xl border border-black/10 shadow-xl text-center space-y-6">
            <div className="flex flex-col items-center gap-2">
              <img src={ASSETS.pyroIcon} alt="PYRO" className="w-12 h-12 object-contain" />
              <p className="text-2xl font-bold text-ink">PYRO</p>
              <p className="text-xs text-warm">by PhynyxPro</p>
            </div>

            <a
              href="https://app.gohighlevel.com"
              className="group w-full inline-flex items-center justify-center gap-2 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
            >
              Open Client Login
              <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>

            <p className="text-xs text-warm leading-relaxed">
              You'll be redirected to the secure GoHighLevel login used for your PYRO workspace. Use
              the credentials provided during onboarding.
            </p>
          </div>

          {/* Secondary links */}
          <div className="mt-8 flex flex-col items-center gap-4 text-sm">
            <p className="text-warm">
              Not a client yet?{" "}
              <Link
                to="/growth-assessment"
                search={{ cta: "client-login" }}
                className="inline-flex items-center gap-1 text-phoenix font-semibold hover:underline"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </p>
            <p className="text-warm">
              Need help?{" "}
              <Link to="/support" className="text-phoenix font-semibold hover:underline">
                Contact Support
              </Link>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

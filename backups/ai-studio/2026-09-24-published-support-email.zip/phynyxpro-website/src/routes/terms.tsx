import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service | PhynyxPro" },
      {
        name: "description",
        content:
          "Terms governing use of the PhynyxPro website, PYRO platform, Ember AI communications, and related services.",
      },
      { property: "og:title", content: "Terms of Service | PhynyxPro" },
      {
        property: "og:description",
        content:
          "Terms governing use of the PhynyxPro website, PYRO platform, Ember AI communications, and related services.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[104px] pb-24">
        <div className="mx-auto max-w-[720px] px-5 lg:px-8">
          <h1 className="text-[28px] sm:text-[32px] lg:text-[36px] font-bold tracking-tight text-ink leading-[1.15]">
            Terms of Service
          </h1>
          <p className="mt-3 text-sm text-warm">Last updated: September 7, 2026</p>

          <div className="mt-10 space-y-10 text-[15px] text-warm leading-[1.75]">
            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Agreement to Terms</h2>
              <p className="mb-4">
                By accessing or using the PhynyxPro website, PYRO platform, or any services provided
                by PhynyxPro, you agree to be bound by these Terms of Service. If you do not agree,
                please do not use our services.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Services</h2>
              <p className="mb-4">
                PhynyxPro provides growth marketing services, CRM and automation tools (through the
                PYRO platform), AI-powered communication (Ember), and related consulting and
                strategy services for appointment-driven businesses.
              </p>
              <p className="mb-4">
                Unless otherwise stated in the client agreement, service descriptions on this
                website are illustrative, and the signed client agreement controls scope,
                deliverables, access, timing, and service levels.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Optional Texts and AI Calls</h2>
              <p className="mb-4">
                PhynyxPro offers optional marketing texts about its services, growth snapshots, and
                diagnostic bookings; separate appointment texts for confirmations, reminders, and
                schedule changes; and automated or AI-generated voice calls with Ember. Each channel
                requires the relevant form selection. Consent is not required to purchase services
                or submit a growth snapshot. Message frequency varies; message and data rates may
                apply.
              </p>
              <p className="mb-4">
                Reply STOP to unsubscribe from texts. Reply HELP for help or email
                craig@phynyxpro.com. To stop calls, ask the caller or contact us. Carriers are not
                liable for delayed or undelivered messages. See our{" "}
                <Link to="/privacy-policy" className="text-phoenix font-semibold hover:underline">
                  Privacy Policy
                </Link>{" "}
                for information about how we handle your data.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Client Obligations</h2>
              <p className="mb-4">
                Clients agree to provide accurate business information, maintain appropriate
                licenses for their industry, and use our platform and services in compliance with
                all applicable laws and regulations.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Payment Terms</h2>
              <p className="mb-4">
                Service fees are outlined in individual client agreements. Unless otherwise stated
                in the client agreement, billing intervals, payment timing, and managed-service fees
                follow the scope of work agreed upon during onboarding.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Intellectual Property</h2>
              <p className="mb-4">
                All content, branding, software, and materials on this website and platform are the
                property of PhynyxPro unless otherwise stated. Clients retain ownership of their
                business data and content.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Limitation of Liability</h2>
              <p className="mb-4">
                PhynyxPro provides marketing and technology services but does not guarantee specific
                results. Marketing outcomes depend on many factors including market conditions,
                competition, and client participation.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Contact</h2>
              <p>
                Questions about these terms? Visit our{" "}
                <Link to="/support" className="text-phoenix font-semibold hover:underline">
                  support page
                </Link>
                .
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

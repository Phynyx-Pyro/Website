import { createFileRoute } from "@tanstack/react-router";
import { handlePhynyxBridge } from "../../lib/phynyx-bridge.server";

/**
 * POST /api/phynyx-bridge
 *
 * Server-side submission bridge for PhynyxPro intake / assessment / booking /
 * support actions. UNPUBLISHED DRAFT — the paired backend endpoint
 * (Cloudflare Worker PR #8) is NOT deployed, so this route is fail-closed.
 *
 * Browser callers select an action via the `x-phynyx-action` header from:
 *   intake | assessment | booking | support
 *
 * All key material is server-only (read inside the handler). This route file
 * imports only the server-only helper and is never reachable from the client
 * bundle (filename matches the *.server.* import-protection rule).
 *
 * Do not wire forms to this route until reviewed.
 */
export const Route = createFileRoute("/api/phynyx-bridge")({
  server: {
    handlers: {
      // All validation, signing, and forwarding live in the server-only helper.
      POST: async ({ request }) => handlePhynyxBridge(request),
    },
  },
});

import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

export const Route = createFileRoute("/fulfillment")({
  head: () => ({
    meta: [
      { title: "Fulfillment Policy | PhynyxPro" },
      {
        name: "description",
        content:
          "Standard fulfillment terms for PhynyxPro services, PYRO platform access, cancellation, refunds, and data export.",
      },
      { property: "og:title", content: "Fulfillment Policy | PhynyxPro" },
      {
        property: "og:description",
        content:
          "Standard fulfillment terms for PhynyxPro services, PYRO platform access, cancellation, refunds, and data export.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FulfillmentPage,
});

function FulfillmentPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[104px] pb-24">
        <div className="mx-auto max-w-[720px] px-5 lg:px-8">
          <h1 className="text-[28px] sm:text-[32px] lg:text-[36px] font-bold tracking-tight text-ink leading-[1.15]">
            Fulfillment Policy
          </h1>
          <p className="mt-3 text-sm text-warm">Last updated: September 4, 2026</p>

          <div className="mt-10 space-y-10 text-[15px] text-warm leading-[1.75]">
            <section>
              <p className="mb-4">
                Unless otherwise stated in the client agreement, the following standard fulfillment
                terms apply. The signed client agreement controls to the extent any provision
                differs.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Service Delivery</h2>
              <p className="mb-4">
                PhynyxPro services are delivered digitally according to the scope, prerequisites,
                and timing in the signed client agreement. Implementation estimates begin after
                required access, inputs, and approvals have been received; third-party reviews or
                dependencies may affect live-launch timing.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">PYRO Platform Access</h2>
              <p className="mb-4">
                Platform access, billing intervals, activation requirements, and access duration are
                defined in the signed client agreement.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Cancellation</h2>
              <p className="mb-4">
                Cancellation rights, notice requirements, termination dates, and any continuing
                obligations are governed by the signed client agreement.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Refunds</h2>
              <p className="mb-4">
                Refund eligibility is governed by the signed client agreement. Advertising spend and
                other amounts already paid or committed to third-party platforms may be
                non-refundable once spent or committed.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Data Export</h2>
              <p className="mb-4">
                Where provided by the signed client agreement, clients may request an export of
                eligible data from the PYRO platform. Export format, timing, retention, and deletion
                are subject to that agreement, platform capabilities, and applicable law.
              </p>
            </section>

            <section>
              <h2 className="text-[20px] font-bold text-ink mb-3">Contact</h2>
              <p>
                For fulfillment or refund inquiries, visit our{" "}
                <Link to="/support" className="text-phoenix font-semibold hover:underline">
                  support page
                </Link>
                .
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

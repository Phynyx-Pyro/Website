import { createFileRoute } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { GrowthAssessmentFunnel } from "../components/GrowthAssessmentFunnel";

export const Route = createFileRoute("/growth-assessment")({
  head: () => ({
    meta: [
      { title: "Free Funnel Check & Growth Snapshot | PhynyxPro" },
      {
        name: "description",
        content:
          "Use three numbers from a recent 30-day period to see two handoffs in your acquisition funnel. Try it free, without sharing contact details.",
      },
      { property: "og:title", content: "Free Funnel Check & Growth Snapshot | PhynyxPro" },
      {
        property: "og:description",
        content:
          "Use three numbers from a recent 30-day period to see two handoffs in your acquisition funnel. Try it free, without sharing contact details.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GrowthAssessmentPage,
});

function GrowthAssessmentPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[129px] lg:pt-[156px] pb-24">
        <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
          <GrowthAssessmentFunnel defaultIndustry="chiropractic" />
        </div>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ArrowRight, Stethoscope } from "lucide-react";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/industries/chiropractic")({
  head: () => ({
    meta: [
      { title: "Chiropractic Patient Acquisition | PhynyxPro" },
      {
        name: "description",
        content:
          "A patient acquisition system built around your front desk. Andrew Higdon, DC, focuses on the handoffs from first inquiry through Day 1 Show and Start Care.",
      },
      { property: "og:title", content: "Chiropractic Patient Acquisition — PhynyxPro" },
      {
        property: "og:description",
        content:
          "A patient acquisition system built around your front desk, from first inquiry through Day 1 Show and Start Care.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChiropracticIndustryPage,
});

const BREAKDOWNS = [
  {
    t: "Slow Follow-Up",
    d: "When follow-up waits, patient intent can cool or move elsewhere.",
  },
  {
    t: "Missed Calls After Hours",
    d: "After-hours and overflow inquiries can expose gaps in front-desk coverage.",
  },
  {
    t: "Leads Without Appointments",
    d: "Your ad campaigns generate interest, but interest without a system produces clicks — not patients.",
  },
  {
    t: "Fragmented Attribution",
    d: "Disconnected systems can make it difficult to connect campaign activity with recorded patient outcomes.",
  },
];

const SYSTEM_ITEMS = [
  "Managed advertising built around agreed audiences and offers",
  "Ember AI for configured response windows and channels",
  "Transactional appointment coordination with defined staff handoffs",
  "PYRO pipeline and recorded-outcome reporting",
  "Permission-based reactivation for patient lists with recorded channel consent and no opt-out",
];

function ChiropracticIndustryPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, wider left column so H1 wraps in five source lines, image lower/center */}
        <section className="bg-ivory pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-6 lg:px-0 grid grid-cols-1 lg:grid-cols-[1fr_540px] gap-8 lg:gap-8 items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4 flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5" />
                Chiropractic
              </p>
              <h1 className="text-[34px] sm:text-[48px] lg:text-[64px] font-bold tracking-tight text-ink leading-[1.05] max-w-[560px]">
                <span className="block lg:hidden">
                  A Patient Acquisition System Built Around Your Front Desk
                </span>
                <span className="hidden lg:block">
                  A Patient
                  <br />
                  Acquisition
                  <br />
                  System Built
                  <br />
                  Around Your Front
                  <br />
                  Desk
                </span>
              </h1>
              <p className="mt-7 text-[20px] sm:text-lg lg:text-lg text-warm leading-relaxed max-w-[520px]">
                Andrew Higdon, DC, is a practicing chiropractor and PhynyxPro&rsquo;s
                founder/operator. The system focuses on the handoffs from first inquiry through Day
                1 Show and Start Care.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 items-start">
                <Link
                  to="/growth-assessment"
                  search={{ cta: "chiropractic-hero", industry: "chiropractic" }}
                  className="group inline-flex items-center justify-center gap-2.5 rounded-lg bg-phoenix px-6 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember w-full sm:w-[352px] h-[74px] text-center leading-tight"
                >
                  <span>
                    Get My New-Patient
                    <br />
                    Growth Snapshot
                  </span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1 shrink-0" />
                </Link>
                <Link
                  to="/growth-system"
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-phoenix/40 px-6 py-3.5 text-sm font-semibold text-phoenix transition-colors hover:bg-phoenix/5 w-full sm:w-[170px]"
                >
                  See the System
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
            {/* Source image x≈974 y270 (preview x≈965 y258): shift +9 right / +12 down */}
            <div className="flex lg:justify-end lg:items-start lg:mt-[108px]">
              <img
                src={ASSETS.chiropractor}
                alt="Chiropractor treating a patient in a modern clinic"
                className="w-full max-w-none lg:w-[540px] lg:h-[405px] rounded-2xl border border-black/10 object-cover shadow-sm"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* Common Handoff Breakdowns — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Common handoff breakdowns
            </p>
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              Common Handoff Breakdowns in Chiropractic Practices
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-12">
              {BREAKDOWNS.map((b, i) => (
                <div key={b.t} className="rounded-xl bg-white border border-black/10 p-5 shadow-sm">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-phoenix">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 text-base font-bold text-ink">{b.t}</h3>
                  <p className="mt-2 text-sm text-warm leading-relaxed">{b.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* The System That Closes the Gap — ivory */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <img
                src={ASSETS.industryChiro}
                alt="Illustrative chiropractic practice setting"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                The system that closes the gap
              </p>
              <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1]">
                The System That Closes the Gap
              </h2>
              <p className="mt-6 text-base text-warm leading-relaxed">
                PhynyxPro connects paid acquisition with response, qualification, appointment
                requests, staff confirmation, reminders, and reporting. When an inquiry arrives by
                phone, chat, or form, PYRO coordinates the workflow and Ember can handle the
                approved conversation. Connected records make it easier to review requests,
                confirmed appointments, shows, and starts.
              </p>
              <ul className="mt-6 space-y-3">
                {SYSTEM_ITEMS.map((item) => (
                  <li
                    key={item}
                    className="rounded-xl bg-white border border-black/10 p-4 text-sm text-ink shadow-sm"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* Meet Ember — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-5">
              <img
                src={ASSETS.emberHuman}
                alt="Ember configured help for after-hours inquiries"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Meet Ember
              </p>
              <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1]">
                Meet Ember. Configured Help for After-Hours Inquiries
              </h2>
              <p className="mt-6 text-base text-warm leading-relaxed">
                When an inquiry arrives after hours, Ember can respond, gather approved details, and
                route an appointment request. PYRO records the known outcome, and your team can take
                over when human judgment is needed.
              </p>
              <div className="mt-6">
                <Link
                  to="/pyro-ember"
                  className="inline-flex items-center gap-2 rounded-lg border border-phoenix/40 px-6 py-3.5 text-sm font-semibold text-phoenix transition-colors hover:bg-phoenix/5"
                >
                  See How PYRO & Ember Work
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Footer CTA — ivory */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 text-center">
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px] mx-auto">
              Ready to Grow Your Practice?
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px] mx-auto">
              Start with a 3-minute growth snapshot. Enter last month's inquiries, bookings, shows,
              starts, and media spend to see the largest visible drop-off.
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                to="/growth-assessment"
                search={{ cta: "chiropractic-footer", industry: "chiropractic" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My New-Patient Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

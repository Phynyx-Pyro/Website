import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ArrowRight } from "lucide-react";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/growth-system")({
  head: () => ({
    meta: [
      { title: "The Growth System | PhynyxPro" },
      {
        name: "description",
        content:
          "PhynyxPro connects advertising, follow-up, and operations so the team can coordinate them around shared data.",
      },
      { property: "og:title", content: "The Growth System — PhynyxPro" },
      {
        property: "og:description",
        content:
          "Ads, follow-up, and reporting working as one system. Keep requests, confirmations, and outcomes distinct.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GrowthSystemPage,
});

const VISIBILITY_STAGES = [
  { t: "Lead", d: "Campaign source and inquiry are recorded" },
  { t: "Request", d: "A scheduling request is captured" },
  { t: "Confirmed", d: "A booked time is recorded separately" },
  { t: "Show", d: "Attendance is verified as its own outcome" },
  { t: "Outcome", d: "The business records the next result" },
  { t: "Improve", d: "Team reviews and adjusts" },
];

const ATTRACT_ITEMS = [
  "Paid search & social campaigns",
  "Offer strategy & ad creative",
  "Landing page workflows",
  "Budget review & allocation",
];

const CONVERT_ITEMS = [
  "CRM pipeline management",
  "Transactional request coordination and reminders",
  "Ember AI receptionist workflows",
  "Request and confirmation workflows",
];

const OPERATE_ITEMS = [
  "PYRO CRM & automation platform",
  "Ember AI voice & chat receptionist",
  "Permission-based database reactivation",
  "Connected attribution reporting",
];

function GrowthSystemPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, ~1120px column, 72px H1 over three lines */}
        <section className="bg-ivory grain pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              The Growth System
            </p>
            <h1 className="text-[40px] sm:text-[52px] lg:text-[72px] font-bold tracking-tight text-ink leading-[1.05] max-w-[920px]">
              Ads, Follow-Up, and
              <br />
              Reporting—Working as
              <br />
              One System
            </h1>
            <p className="mt-7 text-base lg:text-lg text-warm leading-relaxed max-w-[640px]">
              Most agencies sell isolated tactics. PhynyxPro connects advertising, follow-up, and
              operations so the team can coordinate them around shared data.
            </p>
            <div className="mt-8">
              <Link
                to="/growth-assessment"
                search={{ cta: "growth-system-hero", industry: "chiropractic" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-ink px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(20,19,18,0.7)] transition-colors hover:bg-night"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
            {/* 7–10 day onboarding caveat in a white bordered rounded card */}
            <div className="mt-8 max-w-[640px] rounded-2xl bg-white border border-black/10 p-5 shadow-sm">
              <p className="text-sm font-semibold text-ink">
                A standard core build is planned for 7–10 days after complete onboarding.
              </p>
              <p className="mt-2 text-xs text-warm leading-relaxed">
                The window begins after required access, inputs, and approvals are complete.
                A2P/carrier registration, delayed client inputs or approvals, and other third-party
                dependencies can move the live-launch date.
              </p>
            </div>
          </div>
        </section>

        {/* Visibility across the journey — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Visibility across the journey
            </p>
            <h2 className="text-[30px] sm:text-[36px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              Keep Requests, Confirmations, and Outcomes Distinct
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
              {VISIBILITY_STAGES.map((s, i) => (
                <div key={s.t} className="rounded-xl bg-white border border-black/10 p-5 shadow-sm">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-phoenix">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 text-base font-bold text-ink">{s.t}</h3>
                  <p className="mt-2 text-sm text-warm leading-relaxed">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Illustrative workflow — Attract */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Illustrative workflow
              </p>
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-ink">
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Offer</span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                  Campaign Inputs
                </span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Source</span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                  Lead Context
                </span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Connected</span>
                <span className="text-warm">→</span>
                <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                  Spend View
                </span>
              </div>
            </div>
            <div className="lg:col-span-5">
              <img
                src={ASSETS.adCreative}
                alt="Illustrative campaign creative"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* Pillar One — Attract — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Pillar One
            </p>
            <h2 className="text-[30px] sm:text-[36px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              Attract
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px]">
              Managed advertising, offer strategy, and creative — built for your market. We handle
              campaigns designed to put your business in front of relevant people in your market.
            </p>
            <ul className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-[640px]">
              {ATTRACT_ITEMS.map((item) => (
                <li
                  key={item}
                  className="rounded-xl bg-white border border-black/10 p-4 text-sm text-ink shadow-sm"
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Pillar Two — Convert — ivory */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Pillar Two
              </p>
              <h2 className="text-[30px] sm:text-[36px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1]">
                Convert
              </h2>
              <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px]">
                CRM, approved response workflows, and appointment coordination that keep a request
                distinct from a confirmed booking. Ember can respond on connected channels, with
                human handoff when needed.
              </p>
              <ul className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-[640px]">
                {CONVERT_ITEMS.map((item) => (
                  <li
                    key={item}
                    className="rounded-xl bg-white border border-black/10 p-4 text-sm text-ink shadow-sm"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="lg:col-span-5 space-y-5">
              <div className="rounded-2xl bg-white border border-black/10 p-6 shadow-sm">
                <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix">
                  Ember AI · Example conversation
                </p>
                <div className="mt-4 space-y-3 text-sm">
                  <p className="rounded-lg bg-linen/70 px-4 py-3 text-ink">
                    Hi! I'd like to schedule an appointment.
                  </p>
                  <p className="rounded-lg bg-ink px-4 py-3 text-white">
                    I can capture your scheduling preference for the team. Would you prefer morning
                    or afternoon?
                  </p>
                </div>
              </div>
              <img
                src={ASSETS.emberHuman}
                alt="Ember supporting lead qualification and appointment requests"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* Illustrative workflow — Operate — ivory */}
        <section className="py-12 lg:py-16 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              Illustrative workflow
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-ink">
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Inputs</span>
              <span className="text-warm">→</span>
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                Campaign Context
              </span>
              <span className="text-warm">→</span>
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Events</span>
              <span className="text-warm">→</span>
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                Journey Records
              </span>
              <span className="text-warm">→</span>
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">Review</span>
              <span className="text-warm">→</span>
              <span className="rounded-md bg-phoenix/10 text-phoenix px-2.5 py-1">
                Outcome Notes
              </span>
            </div>
          </div>
        </section>

        {/* Pillar Three — Operate & Improve — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Pillar Three
              </p>
              <h2 className="text-[30px] sm:text-[36px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1]">
                Operate & Improve
              </h2>
              <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px]">
                Ember, systems coaching, reporting, and permission-based reactivation for contacts
                with recorded channel consent and no opt-out—connecting available campaign data with
                recorded outcomes.
              </p>
              <ul className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-[640px]">
                {OPERATE_ITEMS.map((item) => (
                  <li
                    key={item}
                    className="rounded-xl bg-white border border-black/10 p-4 text-sm text-ink shadow-sm"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="lg:col-span-5">
              <img
                src={ASSETS.businessOwner}
                alt="Illustrative business reporting review"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3]"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* The System Is the Advantage — ivory */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 text-center">
            <h2 className="text-[30px] sm:text-[36px] lg:text-[48px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px] mx-auto">
              The System Is the Advantage
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px] mx-auto">
              Isolated tactics create fragmented workflows. When advertising, response, and
              appointment operations share the same data and strategy, the three functions are
              easier to coordinate and improve.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 justify-center">
              <Link
                to="/growth-assessment"
                search={{ cta: "growth-system-footer", industry: "chiropractic" }}
                className="group inline-flex items-center justify-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/results"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-phoenix/40 px-6 py-3.5 text-sm font-semibold text-phoenix transition-colors hover:bg-phoenix/5"
              >
                See How Measurement Works
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

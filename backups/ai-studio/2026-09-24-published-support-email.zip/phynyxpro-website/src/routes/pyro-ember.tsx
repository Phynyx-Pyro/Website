import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ASSETS } from "../lib/assets";
import {
  ArrowRight,
  Phone,
  MessageSquare,
  CalendarClock,
  Database,
  GitBranch,
  BarChart3,
  Check,
} from "lucide-react";
import { EmberVoiceWidget } from "../components/EmberVoiceWidget";

export const Route = createFileRoute("/pyro-ember")({
  head: () => ({
    meta: [
      { title: "PYRO Platform & Ember AI Receptionist | PhynyxPro" },
      {
        name: "description",
        content:
          "Meet Ember, the AI receptionist inside PYRO. Ember handles approved inquiries and scheduling requests; PYRO keeps the record, follow-up, and team handoff connected.",
      },
      { property: "og:title", content: "PYRO Platform & Ember AI Receptionist | PhynyxPro" },
      {
        property: "og:description",
        content:
          "Meet Ember, the AI receptionist inside PYRO. Ember handles approved inquiries and scheduling requests; PYRO keeps the record, follow-up, and team handoff connected.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PyroEmberPage,
});

const SUPPORT_ITEMS = [
  {
    icon: Phone,
    title: "AI Voice Agent",
    body: "Ember can support configured inbound-call workflows, gather approved details, and route appointment requests.",
  },
  {
    icon: MessageSquare,
    title: "AI Chat & SMS",
    body: "Configured inbound and transactional SMS and chat workflows can gather approved details and coordinate appointment requests, with defined staff handoff rules.",
  },
  {
    icon: CalendarClock,
    title: "Appointment Coordination",
    body: "Connect approved calendars and scheduling rules so Ember can capture preferences or appointment requests; the configured calendar or staff workflow handles confirmation.",
  },
  {
    icon: Database,
    title: "Database Reactivation",
    body: "Permission-based outreach can be configured only for eligible existing contacts with recorded channel consent and no opt-out.",
  },
  {
    icon: GitBranch,
    title: "CRM & Pipeline",
    body: "Track connected leads from first touch through recorded appointment outcomes in one working view.",
  },
  {
    icon: BarChart3,
    title: "Attribution Engine",
    body: "Connect available campaign, contact, and outcome data so the team can review where inquiries move or stall.",
  },
];

function PyroEmberPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Full-bleed hero: responsive orange-lit backdrops (desktop/mobile) with
            transparent Ember layered on top — no rectangular image card.
            Mobile DOM order: intro, Ember, globe, CTA, benefits.
            Desktop (lg): Ember left; intro / globe / CTA right; benefits full-width. */}
        <section className="relative bg-charcoal text-white overflow-hidden">
          {/* Desktop backdrop (lg+) */}
          <img
            src={ASSETS.emberHeroBgDesktop}
            alt=""
            aria-hidden="true"
            className="hidden lg:block absolute inset-0 w-full h-full object-cover object-center"
          />
          {/* Mobile backdrop (<lg) — centered orange halo, dark charcoal sides */}
          <img
            src={ASSETS.emberHeroBgMobile}
            alt=""
            aria-hidden="true"
            className="lg:hidden absolute inset-0 w-full h-full object-cover object-center"
          />
          {/* Subtle low-opacity gradient for text legibility — does NOT cover the orange halo */}
          <div
            className="absolute inset-0 pointer-events-none z-[1]"
            aria-hidden="true"
            style={{
              background:
                "linear-gradient(to bottom, rgba(14,13,12,0.4) 0%, rgba(14,13,12,0.12) 30%, rgba(14,13,12,0.2) 70%, rgba(14,13,12,0.55) 100%)",
            }}
          />
          <div className="relative grain-charcoal">
            <div className="mx-auto max-w-[1120px] px-6 lg:px-8 xl:px-0 pt-10 pb-0 lg:pt-14 lg:pb-0">
              <div className="grid grid-cols-1 lg:grid-cols-12 lg:gap-x-12 items-start min-h-[560px] lg:min-h-[640px]">
                {/* 1) Heading + "Talk with Ember live" */}
                <div className="relative z-20 order-1 lg:col-span-6 lg:col-start-7 lg:row-start-1">
                  <h1 className="text-[34px] sm:text-[44px] lg:text-[52px] font-bold tracking-tight leading-[1.08] whitespace-nowrap">
                    Talk with <span className="text-phoenix">Ember</span> live
                  </h1>
                  <p className="mt-5 text-[16px] sm:text-[17px] lg:text-lg text-white/80 leading-relaxed max-w-[440px]">
                    See how you can turn more calls into customers - in real time.
                  </p>
                </div>

                {/* 2) Transparent Ember portrait — no box; lower body gently fades
                    toward the live globe. Face/headset/PYRO logo stay fully opaque. */}
                <div className="relative z-10 order-2 lg:col-span-6 lg:col-start-1 lg:row-start-1 lg:row-span-3 flex justify-center lg:justify-start lg:items-end">
                  <img
                    src={ASSETS.emberTallTransparent}
                    alt="Ember, the PYRO AI voice and chat receptionist"
                    className="w-[94vw] max-w-[440px] sm:max-w-[440px] lg:w-[460px] lg:max-w-none xl:w-[520px] h-auto object-contain object-bottom"
                    style={{
                      WebkitMaskImage:
                        "linear-gradient(to bottom, #000 0%, #000 66%, rgba(0,0,0,0.85) 80%, rgba(0,0,0,0.4) 92%, transparent 100%)",
                      maskImage:
                        "linear-gradient(to bottom, #000 0%, #000 66%, rgba(0,0,0,0.85) 80%, rgba(0,0,0,0.4) 92%, transparent 100%)",
                      WebkitMaskRepeat: "no-repeat",
                      maskRepeat: "no-repeat",
                    }}
                  />
                </div>

                {/* 3) ONE live globe — below Ember's faded torso on mobile; right col desktop */}
                <EmberVoiceWidget className="relative z-20 order-3 mx-auto w-full max-w-[240px] min-h-[240px] flex items-center justify-center -mt-16 lg:col-span-6 lg:col-start-7 lg:row-start-2 lg:mx-0 lg:max-w-[300px] lg:min-h-[300px] lg:mt-4" />

                {/* 4) CTA */}
                <div className="relative z-20 order-4 lg:col-span-6 lg:col-start-7 lg:row-start-3 mt-4 lg:mt-8">
                  <Link
                    to="/growth-assessment"
                    search={{ cta: "pyro-ember-hero" }}
                    className="group inline-flex w-full sm:w-[260px] items-center justify-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
                  >
                    Get My Growth Snapshot
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>

                {/* 5) Compact dark checkmark benefit strip */}
                <div className="relative z-20 order-5 lg:col-span-12 lg:col-start-1 lg:row-start-4 mt-8 lg:mt-10 pt-5 border-t border-white/10 flex flex-wrap gap-x-6 gap-y-2">
                  {[
                    "After-hours inquiry handling",
                    "Appointment request capture",
                    "Defined human handoff",
                  ].map((b) => (
                    <span
                      key={b}
                      className="inline-flex items-center gap-1.5 text-[12px] text-white/75"
                    >
                      <Check className="w-3.5 h-3.5 text-flame" />
                      {b}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Curved soft transition from hero to cream-white SMS section */}
          <div className="relative -mb-px z-20">
            <svg
              className="block w-full h-[36px] lg:h-[52px] text-ivory"
              preserveAspectRatio="none"
              viewBox="0 0 1440 52"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M0,52 L0,26 C360,2 1080,2 1440,26 L1440,52 Z" fill="currentColor" />
            </svg>
          </div>
        </section>

        {/* REAL CONVERSATIONS. REAL PATIENTS. — centered phone composition */}
        <section className="bg-ivory pt-14 lg:pt-24 pb-10 lg:pb-16">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            {/* Centered heading block */}
            <div className="text-center max-w-[680px] mx-auto">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                Real conversations. Real patients.
              </p>
              <h2 className="text-[30px] sm:text-[36px] lg:text-[44px] font-bold tracking-tight leading-[1.1]">
                <span className="text-ink">She Handles the Calls.</span>
                <br />
                <span className="text-phoenix">You Get the Patients.</span>
              </h2>
            </div>

            {/* Phone mockup with handwritten callouts — centered */}
            <div className="relative mt-10 lg:mt-14 flex flex-col items-center md:flex-row md:justify-center">
              {/* Mobile legend (< md) — balanced two-column row above the phone, no overlap */}
              <div className="md:hidden flex justify-between items-start w-full max-w-[300px] mb-5 px-1">
                <div className="flex flex-col items-start gap-0.5">
                  <span className="font-hand text-[16px] text-ink leading-tight">Real Patient</span>
                  <svg
                    className="w-4 h-4 text-phoenix"
                    viewBox="0 0 16 16"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M8 2 L8 12 M4 8 L8 12 L12 8"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div className="flex flex-col items-end gap-0.5">
                  <span className="font-hand text-[16px] text-ink leading-tight">
                    Ember (Voice AI)
                  </span>
                  <svg
                    className="w-4 h-4 text-phoenix"
                    viewBox="0 0 16 16"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M8 2 L8 12 M4 8 L8 12 L12 8"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </div>

              {/* Handwritten callout: Real Patient (left) — desktop */}
              <div className="hidden md:block absolute left-0 top-[120px] w-[180px] text-right z-10">
                <p className="font-hand text-[22px] text-ink leading-tight">Real Patient</p>
                <svg
                  className="ml-auto mt-1 w-[90px] h-[40px] text-phoenix"
                  viewBox="0 0 90 40"
                  fill="none"
                  aria-hidden="true"
                >
                  <path
                    d="M4 8 C 30 8, 60 22, 86 34"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeDasharray="2 5"
                  />
                  <path
                    d="M78 28 L 88 35 L 76 38"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                  />
                </svg>
              </div>

              {/* Phone mockup — light iMessage-style */}
              <div className="relative w-full max-w-[320px] sm:max-w-[340px]">
                <div className="rounded-[2.5rem] bg-ink p-2.5 shadow-[0_30px_60px_-20px_rgba(20,19,18,0.45)]">
                  <div className="rounded-[2rem] bg-white overflow-hidden">
                    {/* Status bar — dark iOS island */}
                    <div className="bg-ink px-6 pt-2.5 pb-2 flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-white">8:07</span>
                      <div className="w-20 h-5 rounded-full bg-black" />
                      <div className="flex items-center gap-1.5 text-white">
                        <svg
                          width="15"
                          height="10"
                          viewBox="0 0 15 10"
                          fill="currentColor"
                          aria-hidden="true"
                        >
                          <rect x="0" y="6" width="2.5" height="4" rx="0.5" />
                          <rect x="4" y="4" width="2.5" height="6" rx="0.5" />
                          <rect x="8" y="2" width="2.5" height="8" rx="0.5" />
                          <rect x="12" y="0" width="2.5" height="10" rx="0.5" />
                        </svg>
                        <svg
                          width="14"
                          height="10"
                          viewBox="0 0 14 10"
                          fill="currentColor"
                          aria-hidden="true"
                        >
                          <path d="M7 2.2 C4.5 2.2 2.3 3.1 0.6 4.6l1 1.1C3 4.5 4.9 3.8 7 3.8s4 0.7 5.4 1.9l1-1.1C11.7 3.1 9.5 2.2 7 2.2z" />
                          <path d="M7 5.4c-1.7 0-3.3 0.6-4.5 1.7l1 1.1c0.9-0.8 2.1-1.3 3.5-1.3s2.6 0.5 3.5 1.3l1-1.1C10.3 6 8.7 5.4 7 5.4z" />
                          <circle cx="7" cy="9" r="1.1" />
                        </svg>
                        <div className="relative w-6 h-3 rounded-[3px] border border-white/70">
                          <div className="absolute inset-[1.5px] right-1 rounded-[1px] bg-white/85" />
                          <div className="absolute -right-[3px] top-1/2 -translate-y-1/2 w-[2px] h-1.5 rounded-r bg-white/70" />
                        </div>
                      </div>
                    </div>

                    {/* Conversation header — light iMessage style */}
                    <div className="bg-white border-b border-black/10 px-4 py-3 flex items-center gap-2.5">
                      <img
                        src={ASSETS.emberAvatar}
                        alt=""
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <p className="text-[13px] font-semibold text-ink">Ember</p>
                        <p className="text-[10px] text-warm">Voice AI · online</p>
                      </div>
                      <span className="text-[9px] uppercase tracking-widest text-warm">
                        Illustrative
                      </span>
                    </div>

                    {/* Conversation body — light, labels live outside the phone */}
                    <div className="bg-white px-3.5 py-5 space-y-3.5 min-h-[300px]">
                      {/* Patient — pale gray bubble, left */}
                      <div className="flex justify-start">
                        <div className="rounded-2xl rounded-tl-sm bg-black/[0.06] px-3.5 py-2.5 text-[13px] text-ink leading-snug max-w-[82%]">
                          Hi, I saw your ad. Do you have any openings this week?
                        </div>
                      </div>
                      {/* Ember — pale peach bubble with avatar, right */}
                      <div className="flex justify-end">
                        <div className="flex items-end gap-1.5 max-w-[85%]">
                          <div className="rounded-2xl rounded-tr-sm bg-phoenix/15 border border-phoenix/20 px-3.5 py-2.5 text-[13px] text-ink leading-snug">
                            Welcome! I can capture a scheduling preference for the team. Are you
                            looking for a morning or afternoon appointment?
                          </div>
                          <img
                            src={ASSETS.emberAvatar}
                            alt=""
                            className="w-5 h-5 rounded-full object-cover shrink-0"
                          />
                        </div>
                      </div>
                      {/* Patient — pale gray bubble, left */}
                      <div className="flex justify-start">
                        <div className="rounded-2xl rounded-tl-sm bg-black/[0.06] px-3.5 py-2.5 text-[13px] text-ink leading-snug max-w-[82%]">
                          Afternoon works better. Thursday or Friday if possible.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Handwritten callout: Ember (Voice AI) (right) — desktop */}
              <div className="hidden md:block absolute right-0 top-[210px] w-[180px] z-10">
                <p className="font-hand text-[22px] text-ink leading-tight">Ember (Voice AI)</p>
                <svg
                  className="mt-1 w-[90px] h-[40px] text-phoenix"
                  viewBox="0 0 90 40"
                  fill="none"
                  aria-hidden="true"
                >
                  <path
                    d="M86 8 C 60 8, 30 22, 4 34"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeDasharray="2 5"
                  />
                  <path
                    d="M12 28 L 2 35 L 14 38"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                  />
                </svg>
              </div>
            </div>

            {/* Caption beneath */}
            <div className="mt-8 flex justify-center">
              <div className="flex items-center gap-2.5 rounded-full bg-white border border-black/10 px-5 py-3 shadow-sm">
                <BarChart3 className="w-5 h-5 text-phoenix" />
                <span className="text-[14px] sm:text-[15px] font-semibold text-ink">
                  Converts late-night calls into booked appointments.
                </span>
              </div>
            </div>

            {/* Illustrative caveat */}
            <p className="mt-4 text-center text-xs text-warm leading-relaxed max-w-[520px] mx-auto">
              Illustrative — not a promise of availability, autonomous booking, or guaranteed
              appointments. Scripts, escalation rules, calendar logic, and confirmation behavior are
              configured for each business.
            </p>
          </div>
        </section>

        {/* How PYRO Supports the Acquisition Workflow — ivory */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              How PYRO Supports the Acquisition Workflow
            </p>
            <h2 className="text-[30px] sm:text-[36px] lg:text-[44px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              PYRO is the operating platform inside the PhynyxPro system. Ember is the AI
              receptionist inside PYRO.
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
              {SUPPORT_ITEMS.map((item) => (
                <div
                  key={item.title}
                  className="rounded-xl bg-white border border-black/10 p-6 shadow-sm"
                >
                  <div className="w-11 h-11 rounded-xl bg-phoenix/10 text-phoenix flex items-center justify-center mb-4">
                    <item.icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-ink">{item.title}</h3>
                  <p className="mt-2 text-sm text-warm leading-relaxed">{item.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Designed for Natural Conversation. Built for Clear Handoff — linen,
            with a restored voice-demo waveform (separate from the hero waveform) */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Designed for Natural Conversation.
              </p>
              <h2 className="text-[28px] sm:text-[34px] lg:text-[40px] font-bold tracking-tight text-ink leading-[1.1]">
                Built for Clear Handoff
              </h2>
              <p className="mt-6 text-base text-warm leading-relaxed">
                Ember can support configured inbound call flows, gather approved details, and route
                conversations to staff when human judgment is needed.
              </p>
              <p className="mt-4 text-sm text-warm leading-relaxed">
                When enabled, call summaries and recorded outcomes can be written to connected
                systems. Recording and transcription depend on business settings and applicable
                requirements.
              </p>
            </div>

            {/* Illustrative call workflow card */}
            <div className="rounded-2xl bg-night text-white grain-dark p-6 lg:p-8 shadow-xl">
              <div className="flex items-center gap-2 mb-5">
                <img
                  src={ASSETS.emberAvatar}
                  alt=""
                  className="w-5 h-5 rounded-full object-cover"
                />
                <span className="text-[11px] font-bold uppercase tracking-widest text-flame">
                  Ember · Illustrative call workflow
                </span>
              </div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-white/50 mb-2">
                Example
              </p>
              <div className="space-y-3">
                <div className="rounded-lg bg-white/10 px-4 py-3 text-sm text-white/90">
                  Configured route: Ember
                </div>
                <div className="rounded-lg bg-phoenix/20 px-4 py-3 text-sm text-white/90">
                  Example outcome: appointment request captured
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How Access Works — ivory */}
        <section className="py-16 lg:py-24 bg-ivory">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              How access works
            </p>
            <h2 className="text-[30px] sm:text-[36px] lg:text-[44px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              Configured Around the Workflow
            </h2>
            <div className="mt-8 max-w-[640px] space-y-4">
              <p className="text-base text-warm leading-relaxed">
                PYRO is deployed as part of PhynyxPro.
              </p>
              <p className="text-base text-warm leading-relaxed">
                Platform scope, integrations, and managed services are reviewed during the
                diagnostic and defined in the client agreement.
              </p>
              <p className="text-base text-warm leading-relaxed">
                The diagnostic maps the current stack, required handoffs, and implementation scope
                before any agreement.
              </p>
            </div>
          </div>
        </section>

        {/* Footer CTA — linen */}
        <section className="py-16 lg:py-24 bg-linen border-t border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <h2 className="text-[28px] sm:text-[34px] lg:text-[40px] font-bold tracking-tight text-ink leading-[1.1] max-w-[680px]">
              Map PYRO and Ember Into Your Current Handoffs
            </h2>
            <p className="mt-5 text-base text-warm leading-relaxed max-w-[560px]">
              Start with a 3-minute growth snapshot. See the largest visible drop-off before
              deciding whether to continue to a working diagnostic.
            </p>
            <div className="mt-8">
              <Link
                to="/growth-assessment"
                search={{ cta: "pyro-ember-footer" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

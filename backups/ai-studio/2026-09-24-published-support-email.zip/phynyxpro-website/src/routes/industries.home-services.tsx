import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { ArrowRight } from "lucide-react";
import { ASSETS } from "../lib/assets";

export const Route = createFileRoute("/industries/home-services")({
  head: () => ({
    meta: [
      { title: "Home Services Lead Acquisition | PhynyxPro" },
      {
        name: "description",
        content:
          "Turn more inquiries into scheduled estimates and jobs. PhynyxPro connects the workflow from inquiry to estimate request, scheduled work, and recorded outcome.",
      },
      { property: "og:title", content: "Home Services Lead Acquisition — PhynyxPro" },
      {
        property: "og:description",
        content:
          "Roofing, plumbing, and HVAC businesses: connect inquiry to estimate request, scheduled work, and recorded outcome.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomeServicesIndustryPage,
});

const SYSTEM_ITEMS = [
  {
    t: "Prompt Lead Response",
    d: "Ember can support configured phone, SMS, and chat workflows, with staff handoff when needed.",
  },
  {
    t: "Estimate & Job Requests",
    d: "Connected scheduling can capture the next requested step against configured rules; staff or the connected calendar confirms availability.",
  },
  {
    t: "After-Hours Inquiry Handling",
    d: "Configured workflows can acknowledge after-hours and weekend inquiries and route follow-up.",
  },
  {
    t: "Connected Reporting",
    d: "Bring available ad, lead, request, confirmed appointment, and recorded revenue data into one review path.",
  },
  {
    t: "Permission-Based Follow-Up",
    d: "Re-engagement can be configured only for eligible contacts with recorded channel consent and no opt-out.",
  },
  {
    t: "Service Workflows",
    d: "The workflow can be configured around estimate requests, job scheduling, and service follow-up.",
  },
];

function HomeServicesIndustryPage() {
  return (
    <div className="min-h-screen flex flex-col bg-ivory text-ink font-sans antialiased grain">
      <Header />
      <main className="flex-1 pt-[84px]">
        {/* Hero — ivory, ~1120px column, 64px H1 */}
        <section className="bg-ivory grain pt-16 pb-20 lg:pt-20 lg:pb-28">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
                Home Services
              </p>
              <h1 className="text-[36px] sm:text-[48px] lg:text-[64px] font-bold tracking-tight text-ink leading-[1.05] max-w-[640px]">
                Turn More Inquiries Into Scheduled Estimates and Jobs
              </h1>
              <p className="mt-7 text-base lg:text-lg text-warm leading-relaxed max-w-[560px]">
                Roofing, plumbing, and HVAC businesses depend on timely handoffs from inquiry to
                estimate request, scheduled work, and recorded outcome. PhynyxPro connects that
                workflow.
              </p>
              <div className="mt-8">
                <Link
                  to="/growth-assessment"
                  search={{ cta: "home-services-hero", industry: "home-services" }}
                  className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
                >
                  Get My Growth Snapshot
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
            <div className="lg:col-span-5">
              <img
                src={ASSETS.homeServices}
                alt="Home service professional on a job site"
                className="w-full rounded-2xl border border-black/10 object-cover aspect-[4/3] shadow-sm"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        {/* What the System Does — linen */}
        <section className="py-16 lg:py-24 bg-linen border-y border-black/10">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10">
            <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-4">
              What the system does
            </p>
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px]">
              What the System Does for Home Service Businesses
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
              {SYSTEM_ITEMS.map((s, i) => (
                <div key={s.t} className="rounded-xl bg-white border border-black/10 p-5 shadow-sm">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-phoenix">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 text-base font-bold text-ink">{s.t}</h3>
                  <p className="mt-2 text-sm text-warm leading-relaxed">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer CTA — ivory */}
        <section className="py-16 lg:py-24 bg-ivory grain">
          <div className="mx-auto max-w-[1120px] px-5 lg:px-10 text-center">
            <h2 className="text-[26px] sm:text-[32px] lg:text-[42px] font-bold tracking-tight text-ink leading-[1.1] max-w-[760px] mx-auto">
              Ready to Tighten the Path From Inquiry to Scheduled Work?
            </h2>
            <p className="mt-6 text-base lg:text-lg text-warm leading-relaxed max-w-[640px] mx-auto">
              Start with a 3-minute growth snapshot. Enter last month's leads, bookings, completed
              jobs, and media spend to see the largest visible drop-off.
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                to="/growth-assessment"
                search={{ cta: "home-services-footer", industry: "home-services" }}
                className="group inline-flex items-center gap-2.5 rounded-lg bg-phoenix px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)] transition-colors hover:bg-ember"
              >
                Get My Growth Snapshot
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
// AI Studio route index refresh v9

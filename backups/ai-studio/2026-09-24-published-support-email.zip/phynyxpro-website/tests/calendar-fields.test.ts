import { describe, it, expect } from "vitest";
import { CUSTOM_FIELDS, CALENDAR_ID } from "../src/lib/calendar";

describe("/schedule field ID unification", () => {
  it("appointmentTextConsent uses unified intake field ID", () => {
    expect(CUSTOM_FIELDS.appointmentTextConsent).toBe("xNnkLEk8FCUI7XSbeElK");
  });

  it("ctaSource uses unified intake field ID", () => {
    expect(CUSTOM_FIELDS.ctaSource).toBe("CVSuXDCFaJslF3bIuRvI");
  });

  it("calendar ID is the correct round-robin calendar", () => {
    expect(CALENDAR_ID).toBe("NX2pJFAx51yOcaNIdNjL");
  });

  it("does not use old field IDs", () => {
    expect(CUSTOM_FIELDS.appointmentTextConsent).not.toBe("Unplv0vwJSkik0mQ9owj");
    expect(CUSTOM_FIELDS.ctaSource).not.toBe("XrmJih7R59gZYuIH888w");
  });
});

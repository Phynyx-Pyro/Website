import { describe, it, expect, vi, beforeEach } from "vitest";
import { submitCalendarBooking } from "../src/lib/calendar";

let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  fetchMock = vi.fn();
  global.fetch = fetchMock as unknown as typeof global.fetch;
});

const basePayload = {
  locationId: "DsRnzA2tcoiwklSgjBtR",
  calendarId: "NX2pJFAx51yOcaNIdNjL",
  firstName: "Jane",
  lastName: "Doe",
  email: "jane@test.com",
  phone: "5551234567",
  selectedSlot: "2026-09-25T09:30:00-07:00",
  sessionId: "stable-session-1",
};

describe("submitCalendarBooking — explicit confirmed 2xx", () => {
  it("2xx with appointmentId + bookedStart => confirmed", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_123", bookedStart: "2026-09-25T09:30:00-07:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("confirmed");
    }
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_123");
      expect(result.bookedStart).toBe("2026-09-25T09:30:00-07:00");
    }
  });

  it("2xx with id + start aliases => confirmed", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ id: "apt_456", start: "2026-09-25T10:00:00-07:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok && result.status === "confirmed") {
      expect(result.appointmentId).toBe("apt_456");
      expect(result.bookedStart).toBe("2026-09-25T10:00:00-07:00");
    }
  });
});

describe("submitCalendarBooking — 2xx missing fields", () => {
  it("2xx with no appointment fields => accepted-unverified (NOT error)", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({}),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with appointmentId but no bookedStart => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "apt_789" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with bookedStart but no id => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ bookedStart: "2026-09-25T09:30:00-07:00" }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with empty-string fields => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ appointmentId: "", bookedStart: "  " }),
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });

  it("2xx with unparseable JSON => accepted-unverified", async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => {
        throw new SyntaxError("bad json");
      },
    });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.status).toBe("accepted-unverified");
    }
  });
});

describe("submitCalendarBooking — 409 slot conflict", () => {
  it("409 => unavailable (retryable)", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 409 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("unavailable");
      expect(result.message).toContain("taken");
    }
  });
});

describe("submitCalendarBooking — ambiguous / uncertain failure", () => {
  it("500 after POST => uncertain (no immediate retry)", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 500 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
      expect(result.message).toContain("check your email");
    }
  });

  it("502 after POST => uncertain", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 502 });
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
    }
  });

  it("network error after POST => uncertain (appointment may exist)", async () => {
    fetchMock.mockRejectedValue(new Error("network timeout"));
    const result = await submitCalendarBooking(basePayload);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("uncertain");
      expect(result.message).toContain("check your email");
    }
  });
});

describe("submitCalendarBooking — hard pre-POST error", () => {
  it("missing sessionId => error (retryable)", async () => {
    const result = await submitCalendarBooking({ ...basePayload, sessionId: "" });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.reason).toBe("error");
      expect(result.message).toContain("session");
    }
    // Should not have attempted a fetch.
    expect(fetchMock).not.toHaveBeenCalled();
  });
});

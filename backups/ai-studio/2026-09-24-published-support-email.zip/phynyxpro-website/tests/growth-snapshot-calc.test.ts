import { describe, it, expect } from "vitest";
import {
  pct,
  round1,
  buildRates,
  costPer,
  computeScenario,
  freeNum,
  metricNum,
  metricFloat,
  validateFreeSequence,
  validateFunnelSequence,
  EMPTY_METRIC,
  type FunnelMetric,
} from "../src/lib/growth-snapshot-calc";

const metric = (value: string, quality: FunnelMetric["quality"] = "exact"): FunnelMetric => ({
  value,
  quality,
});

describe("freeNum / metricNum / metricFloat", () => {
  it("freeNum: blank => null, valid int => number, decimal => null, negative => null", () => {
    expect(freeNum("")).toBeNull();
    expect(freeNum("80")).toBe(80);
    expect(freeNum("12.5")).toBeNull();
    expect(freeNum("-5")).toBeNull();
  });

  it("metricNum: not-tracked => null, blank => null, decimal => null", () => {
    expect(metricNum(EMPTY_METRIC)).toBeNull();
    expect(metricNum(metric("", "exact"))).toBeNull();
    expect(metricNum(metric("12.5", "exact"))).toBeNull();
    expect(metricNum(metric("100", "estimate"))).toBe(100);
  });

  it("metricFloat: uses Number() — rejects malformed, allows decimals for ad spend / value", () => {
    expect(metricFloat(metric("1500.50", "exact"))).toBe(1500.5);
    expect(metricFloat(metric("", "exact"))).toBeNull();
    expect(metricFloat(EMPTY_METRIC)).toBeNull();
    expect(metricFloat(metric("-10", "exact"))).toBeNull();
    // Malformed strings rejected (Number("12abc") === NaN), unlike parseFloat.
    expect(metricFloat(metric("12abc", "exact"))).toBeNull();
    expect(metricFloat(metric("abc", "exact"))).toBeNull();
  });
});

describe("pct — safe rates", () => {
  it("returns null when denominator <= 0", () => {
    expect(pct(5, 0)).toBeNull();
    expect(pct(5, -1)).toBeNull();
  });

  it("returns null when numerator > denominator (no >100%)", () => {
    expect(pct(30, 20)).toBeNull();
    expect(pct(100, 80)).toBeNull();
  });

  it("computes valid rates", () => {
    expect(pct(28, 80)).toBe(35);
    expect(pct(20, 28)).toBe(71.4);
  });

  it("returns null for non-finite", () => {
    expect(pct(NaN, 10)).toBeNull();
    expect(pct(10, Infinity)).toBeNull();
  });
});

describe("free calculator: 80/28/20", () => {
  const leads = 80, booked = 28, showed = 20;
  const bookedRate = pct(booked, leads);
  const showRate = pct(showed, booked);
  const dropoff = round1(((booked - showed) / booked) * 100);

  it("booked rate = 35%", () => expect(bookedRate).toBe(35));
  it("show rate = 71.4%", () => expect(showRate).toBe(71.4));
  it("dropoff = 28.6%", () => expect(dropoff).toBe(28.6));
});

describe("free calculator: zero / unknown / inconsistent", () => {
  it("zero leads => null rates", () => {
    expect(pct(0, 0)).toBeNull();
    expect(pct(5, 0)).toBeNull();
  });

  it("unknown (null) => null rates", () => {
    expect(pct(28, null as unknown as number)).toBeNull();
  });

  it("inconsistent showed>booked => null show rate, no >100%", () => {
    expect(pct(30, 28)).toBeNull();
  });

  it("inconsistent booked>leads => null booked rate", () => {
    expect(pct(90, 80)).toBeNull();
  });
});

describe("validateFreeSequence", () => {
  it("valid sequence => no issues", () => {
    expect(validateFreeSequence(80, 28, 20)).toHaveLength(0);
  });

  it("booked>leads => issue", () => {
    const issues = validateFreeSequence(80, 90, 20);
    expect(issues).toHaveLength(1);
    expect(issues[0]!.field).toBe("Appointments Booked");
  });

  it("showed>booked => issue", () => {
    const issues = validateFreeSequence(80, 28, 30);
    expect(issues).toHaveLength(1);
    expect(issues[0]!.field).toBe("Showed");
  });

  it("missing values => no issues (missing is valid)", () => {
    expect(validateFreeSequence(null, 28, null)).toHaveLength(0);
  });
});

describe("validateFunnelSequence", () => {
  it("valid => no issues", () => {
    expect(
      validateFunnelSequence({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 20, started: 14 }),
    ).toHaveLength(0);
  });

  it("showed>confirmed => issue", () => {
    const issues = validateFunnelSequence({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 30, started: 14 });
    expect(issues.length).toBeGreaterThanOrEqual(1);
  });

  it("missing => no issues", () => {
    expect(validateFunnelSequence({ inquiries: null, contacted: null, booked: null, confirmed: null, showed: null, started: null })).toHaveLength(0);
  });
});

describe("buildRates — unknown is NOT zero (null-guard)", () => {
  it("inquiries 80 / contacted null => Contacted AND Booked rates null (not 0%)", () => {
    const rates = buildRates({ inquiries: 80, contacted: null, booked: 28, confirmed: null, showed: null, started: null });
    expect(rates.find((r) => r.label === "Contacted Rate")?.rate).toBeNull();
    expect(rates.find((r) => r.label === "Booked Rate")?.rate).toBeNull();
  });

  it("inconsistent showed>confirmed => show rate null", () => {
    const rates = buildRates({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 30, started: 14 });
    const showRate = rates.find((r) => r.label === "Show Rate");
    expect(showRate?.rate).toBeNull();
  });

  it("all valid => all rates computed", () => {
    const rates = buildRates({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 20, started: 14 });
    expect(rates.every((r) => r.rate !== null)).toBe(true);
  });

  it("all missing => all null", () => {
    const rates = buildRates({ inquiries: null, contacted: null, booked: null, confirmed: null, showed: null, started: null });
    expect(rates.every((r) => r.rate === null)).toBe(true);
  });
});

describe("computeScenario — strict downstream + nStarted requirement", () => {
  it("80/60/28/24/20/10 => ~2.1 additional starts (round only final)", () => {
    const rates = buildRates({ inquiries: 80, contacted: 60, booked: 28, confirmed: 24, showed: 20, started: 10 });
    // Weakest = Booked Rate (28/60 = 46.7%). +10pp => 56.7%.
    // uplift = 60 * (10/100) * (24/28)*(20/24)*(10/20) = 60*0.1*0.8571*0.8333*0.5
    const scenario = computeScenario(rates, [80, 60, 28, 24, 20], 10);
    expect(scenario).not.toBeNull();
    expect(scenario!.additionalStarts).not.toBeNull();
    // 60 * 0.1 * (24/28) * (20/24) * (10/20) = 6 * 0.857143 * 0.833333 * 0.5 = 2.142857
    expect(scenario!.additionalStarts).toBe(2.1);
  });

  it("80/60/28/confirmed null/showed 20/started 10 => additionalStarts null (missing downstream)", () => {
    const rates = buildRates({ inquiries: 80, contacted: 60, booked: 28, confirmed: null, showed: 20, started: 10 });
    const scenario = computeScenario(rates, [80, 60, 28, null, 20], 10);
    expect(scenario).not.toBeNull();
    expect(scenario!.additionalStarts).toBeNull();
  });

  it("nStarted null => additionalStarts null", () => {
    const rates = buildRates({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 20, started: 14 });
    const scenario = computeScenario(rates, [100, 80, 28, 25, 20], null);
    expect(scenario).not.toBeNull();
    expect(scenario!.additionalStarts).toBeNull();
  });

  it("capped 95% => uses 5pp gain, not 10", () => {
    // Weakest at 95% => improvedRate capped at 100, gain = 5pp.
    const rates = buildRates({ inquiries: 100, contacted: 100, booked: 100, confirmed: 100, showed: 100, started: 95 });
    const scenario = computeScenario(rates, [100, 100, 100, 100, 100], 95);
    expect(scenario).not.toBeNull();
    expect(scenario!.improvedRate).toBe(100);
    // uplift = 100 * (5/100) * (100/100)^4 = 5.0
    expect(scenario!.additionalStarts).toBe(5);
  });

  it("no valid rates => null", () => {
    const rates = buildRates({ inquiries: null, contacted: null, booked: null, confirmed: null, showed: null, started: null });
    expect(computeScenario(rates, [null, null, null, null, null], null)).toBeNull();
  });

  it("inconsistent data (showed>confirmed) => null scenario (no impossible projection)", () => {
    const rates = buildRates({ inquiries: 100, contacted: 80, booked: 28, confirmed: 25, showed: 30, started: 14 });
    const scenario = computeScenario(rates, [100, 80, 28, 25, 30], 14);
    expect(scenario).toBeNull();
  });
});

describe("costPer", () => {
  it("valid => spend/n", () => {
    expect(costPer(100, 5000)).toBe(50);
  });

  it("null or zero count => null", () => {
    expect(costPer(null, 5000)).toBeNull();
    expect(costPer(0, 5000)).toBeNull();
  });

  it("null spend => null", () => {
    expect(costPer(100, null)).toBeNull();
  });
});

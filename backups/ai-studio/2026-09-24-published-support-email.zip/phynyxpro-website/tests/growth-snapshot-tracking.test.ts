import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the global fetch so we can assert tracking behavior without network.
let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  fetchMock = vi.fn();
  global.fetch = fetchMock as unknown as typeof global.fetch;
  // The tracking code reads window, document, navigator as bare globals.
  const mockWindow = {
    location: { href: "https://test.local/growth-assessment", pathname: "/growth-assessment" },
  };
  Object.defineProperty(global, "window", {
    value: mockWindow,
    writable: true,
    configurable: true,
  });
  Object.defineProperty(global, "document", {
    value: { title: "Test" },
    writable: true,
    configurable: true,
  });
  Object.defineProperty(global, "navigator", {
    value: { userAgent: "node" },
    writable: true,
    configurable: true,
  });
  // crypto.randomUUID exists in Node 19+; stub it for deterministic tests.
  vi.spyOn(crypto, "randomUUID").mockReturnValue("test-uuid-1234");
});

describe("trackGrowthSnapshotIntake", () => {
  it("awaits delayed 2xx and resolves ok", async () => {
    const {
      trackGrowthSnapshotIntake,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    const result = await trackGrowthSnapshotIntake({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      appointmentTexts: true,
      marketingTexts: false,
      aiPhoneCalls: false,
      ctaSource: "test-cta",
    });
    expect(result.ok).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("non-2xx => rejects with error, preserves message", async () => {
    const {
      trackGrowthSnapshotIntake,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: false, status: 500 });
    const result = await trackGrowthSnapshotIntake({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      appointmentTexts: false,
      marketingTexts: false,
      aiPhoneCalls: false,
      ctaSource: "test-cta",
    });
    expect(result.ok).toBe(false);
    expect(result.message).toContain("500");
  });

  it("network error => rejects with error", async () => {
    const {
      trackGrowthSnapshotIntake,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockRejectedValue(new Error("network"));
    const result = await trackGrowthSnapshotIntake({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      appointmentTexts: false,
      marketingTexts: false,
      aiPhoneCalls: false,
      ctaSource: "test-cta",
    });
    expect(result.ok).toBe(false);
    expect(result.message).toContain("couldn't reach");
  });
});

describe("trackGrowthSnapshotCompletion", () => {
  it("2xx => ok, fires completion form (not intake)", async () => {
    const {
      trackGrowthSnapshotCompletion,
      GROWTH_SNAPSHOT_COMPLETION_FORM_ID,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    const result = await trackGrowthSnapshotCompletion({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      ctaSource: "test-cta",
      status: "Completed",
      completedAt: "2026-01-01T00:00:00Z",
      summary: "test summary",
      industry: "chiropractic",
      primaryChallenge: "Booked Rate at 35%",
    });
    expect(result.ok).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    // Verify the form body contains the completion formId, not intake
    const bodyArg = fetchMock.mock.calls[0]![1];
    const formData = bodyArg.body as FormData;
    const event = JSON.parse(formData.get("event") as string);
    expect(event.formId).toBe(GROWTH_SNAPSHOT_COMPLETION_FORM_ID);
  });

  it("non-2xx => error, does not claim Completed", async () => {
    const {
      trackGrowthSnapshotCompletion,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: false, status: 503 });
    const result = await trackGrowthSnapshotCompletion({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      ctaSource: "test-cta",
      status: "Completed",
      completedAt: "2026-01-01T00:00:00Z",
      summary: "test summary",
      industry: "chiropractic",
      primaryChallenge: "Booked Rate at 35%",
    });
    expect(result.ok).toBe(false);
    expect(result.message).toContain("503");
  });

  it("network error => error", async () => {
    const {
      trackGrowthSnapshotCompletion,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockRejectedValue(new Error("network"));
    const result = await trackGrowthSnapshotCompletion({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      ctaSource: "test-cta",
      status: "Completed",
      completedAt: "2026-01-01T00:00:00Z",
      summary: "test summary",
      industry: "chiropractic",
      primaryChallenge: "Booked Rate at 35%",
    });
    expect(result.ok).toBe(false);
  });
});

describe("no duplicate intake on completion", () => {
  it("completion does not send consent fields", async () => {
    const {
      trackGrowthSnapshotCompletion,
      CF_APPOINTMENT_SMS_CONSENT,
      CF_MARKETING_SMS_CONSENT,
      CF_AI_VOICE_CONSENT,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    await trackGrowthSnapshotCompletion({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      ctaSource: "test-cta",
      status: "Completed",
      completedAt: "2026-01-01T00:00:00Z",
      summary: "test summary",
      industry: "chiropractic",
      primaryChallenge: "Booked Rate at 35%",
    });
    const bodyArg = fetchMock.mock.calls[0]![1];
    const formData = bodyArg.body as FormData;
    const event = JSON.parse(formData.get("event") as string);
    // Completion must NOT include consent custom field keys
    expect(event.formData[CF_APPOINTMENT_SMS_CONSENT]).toBeUndefined();
    expect(event.formData[CF_MARKETING_SMS_CONSENT]).toBeUndefined();
    expect(event.formData[CF_AI_VOICE_CONSENT]).toBeUndefined();
  });
});

describe("intake sends consent fields with Consented/Not consented", () => {
  it("intake includes consent fields with unified vocabulary", async () => {
    const {
      trackGrowthSnapshotIntake,
      CF_APPOINTMENT_SMS_CONSENT,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    await trackGrowthSnapshotIntake({
      businessName: "Test Clinic",
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      appointmentTexts: true,
      marketingTexts: false,
      aiPhoneCalls: false,
      ctaSource: "test-cta",
    });
    const bodyArg = fetchMock.mock.calls[0]![1];
    const formData = bodyArg.body as FormData;
    const event = JSON.parse(formData.get("event") as string);
    expect(event.formData[CF_APPOINTMENT_SMS_CONSENT]).toBe("Consented");
  });
});

describe("trackGrowthCallBookingIntake (/schedule early capture)", () => {
  it("2xx => ok, fires growth-call-booking-intake form (not snapshot forms)", async () => {
    const {
      trackGrowthCallBookingIntake,
      GROWTH_CALL_BOOKING_INTAKE_FORM_ID,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    const result = await trackGrowthCallBookingIntake({
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      businessName: "Test Clinic",
      appointmentTexts: false,
      ctaSource: "schedule-page",
    });
    expect(result.ok).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const bodyArg = fetchMock.mock.calls[0]![1];
    const formData = bodyArg.body as FormData;
    const event = JSON.parse(formData.get("event") as string);
    expect(event.formId).toBe(GROWTH_CALL_BOOKING_INTAKE_FORM_ID);
  });

  it("non-2xx => error, preserves message", async () => {
    const { trackGrowthCallBookingIntake } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: false, status: 500 });
    const result = await trackGrowthCallBookingIntake({
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      businessName: "Test Clinic",
      appointmentTexts: false,
      ctaSource: "schedule-page",
    });
    expect(result.ok).toBe(false);
    expect(result.message).toContain("500");
  });

  it("network error => error", async () => {
    const { trackGrowthCallBookingIntake } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockRejectedValue(new Error("network"));
    const result = await trackGrowthCallBookingIntake({
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      businessName: "Test Clinic",
      appointmentTexts: false,
      ctaSource: "schedule-page",
    });
    expect(result.ok).toBe(false);
  });

  it("sends ONLY appointment consent + CTA source (no marketing/AI voice)", async () => {
    const {
      trackGrowthCallBookingIntake,
      CF_APPOINTMENT_SMS_CONSENT,
      CF_MARKETING_SMS_CONSENT,
      CF_AI_VOICE_CONSENT,
      CF_CTA_SOURCE,
    } = await import("../src/lib/growth-snapshot-tracking");
    fetchMock.mockResolvedValue({ ok: true, status: 200 });
    await trackGrowthCallBookingIntake({
      firstName: "Jane",
      lastName: "Doe",
      email: "jane@test.com",
      phone: "5551234567",
      businessName: "Test Clinic",
      appointmentTexts: true,
      ctaSource: "home-hero",
    });
    const bodyArg = fetchMock.mock.calls[0]![1];
    const formData = bodyArg.body as FormData;
    const event = JSON.parse(formData.get("event") as string);
    expect(event.formData[CF_APPOINTMENT_SMS_CONSENT]).toBe("Consented");
    expect(event.formData[CF_CTA_SOURCE]).toBe("home-hero");
    // Marketing and AI voice consent must NEVER be sent from /schedule.
    expect(event.formData[CF_MARKETING_SMS_CONSENT]).toBeUndefined();
    expect(event.formData[CF_AI_VOICE_CONSENT]).toBeUndefined();
  });
});

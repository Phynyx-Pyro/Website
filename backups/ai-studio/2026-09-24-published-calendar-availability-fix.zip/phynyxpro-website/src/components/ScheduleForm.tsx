import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Clock, AlertCircle, RotateCcw, Loader2 } from "lucide-react";
import {
  CALENDAR_ID,
  LOCATION_ID,
  CUSTOM_FIELDS,
  fetchCalendarFreeSlots,
  slotsToSet,
  submitCalendarBooking,
  type FreeSlotsResponse,
  type BookingResult,
} from "../lib/calendar";
import { toDayGroups, isValidAvailabilityShape, type DayGroup } from "../lib/schedule-availability";
import { trackGrowthCallBookingIntake } from "../lib/growth-snapshot-tracking";
import { SlotFailureBanner, DonePanel, formatTimeLabel } from "./BookingResultPanel";

/**
 * Custom scheduling form + slot-selection UI.
 * Native-looking (no iframe, no embedded calendar).
 * Wired to the existing "Phynyx Website - Assessment" calendar behind the branded UI.
 */

// RFC 5322-ish email pattern — sufficient for client-side validation.
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Accepts +, (), -, spaces, and 7+ digits.
const PHONE_RE = /^[+()\-\s\d]{7,}$/;

export function ScheduleForm({ ctaSource = "schedule-page" }: { ctaSource?: string }) {
  const [step, setStep] = useState<"contact" | "slot" | "done">("contact");
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  // contact fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [business, setBusiness] = useState("");
  const [consent, setConsent] = useState(false);

  // inline validation (shown after blur/submit attempt)
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [submitAttempted, setSubmitAttempted] = useState(false);

  // availability state
  const [dayGroups, setDayGroups] = useState<DayGroup[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsError, setSlotsError] = useState<string | null>(null);
  const [slotsReloadKey, setSlotsReloadKey] = useState(0);

  // booking state
  const [booking, setBooking] = useState(false);
  const [bookingResult, setBookingResult] = useState<BookingResult | null>(null);
  const bookingPendingRef = useRef(false);

  // Early contact-capture intake state (Growth Call Booking Intake).
  // Fired on "Choose My Appointment Time" BEFORE slot selection so a lead who
  // abandons slot selection is still captured. Awaited; preserves input + retry
  // on network/non-2xx failure.
  const [intakeSubmitting, setIntakeSubmitting] = useState(false);
  const [intakeError, setIntakeError] = useState<string | null>(null);

  // Fingerprint of the last successfully-submitted contact payload, so
  // edit-back-and-forward with UNCHANGED details does not emit twice.
  // Changed details produce a new fingerprint and may submit a new event.
  const intakeFingerprintRef = useRef<string | null>(null);
  // Guard against double-click while a submission is pending.
  const intakePendingRef = useRef(false);

  /** Build a stable fingerprint of the contact details for dedup. */
  const contactFingerprint = (n: string, e: string, p: string, b: string, c: boolean) =>
    [n.trim().toLowerCase(), e.trim().toLowerCase(), p.trim(), b.trim().toLowerCase(), c].join("|");

  /**
   * Stable booking-attempt/session key, created once per form mount and reused
   * across every retry. The provider does not document server-side idempotency,
   * so this is sent as a best-effort dedup key only — each POST is still a
   * distinct attempt unless the provider confirms deduplication.
   */
  const sessionIdRef = useRef<string>("");
  if (!sessionIdRef.current) {
    sessionIdRef.current = crypto.randomUUID();
  }

  const emailValid = EMAIL_RE.test(email.trim());
  const phoneValid = PHONE_RE.test(phone.trim());
  const contactValid =
    name.trim().length > 0 && business.trim().length > 0 && emailValid && phoneValid;

  // Split a full name into first/last for the booking payload.
  const nameParts = useMemo(() => {
    const trimmed = name.trim();
    const idx = trimmed.indexOf(" ");
    if (idx === -1) return { firstName: trimmed, lastName: "" };
    return { firstName: trimmed.slice(0, idx), lastName: trimmed.slice(idx + 1) };
  }, [name]);

  // Fetch availability for the next ~14 days when entering the slot step.
  useEffect(() => {
    if (step !== "slot") return;
    let cancelled = false;

    const load = async () => {
      setSlotsLoading(true);
      setSlotsError(null);
      try {
        const now = new Date();
        const startMs = now.getTime();
        const endMs = startMs + 14 * 24 * 60 * 60 * 1000;
        const data = await fetchCalendarFreeSlots(CALENDAR_ID, startMs, endMs);
        if (!cancelled) {
          // A structurally-invalid response is a retryable read error.
          if (!isValidAvailabilityShape(data)) {
            setDayGroups([]);
            setSlotsError("We couldn't read the available times right now. Please try again.");
          } else {
            setDayGroups(toDayGroups(data));
            // An empty-but-valid object is a legitimate "no open times"
            // outcome — rendered with a /support fallback link below, not
            // as an error.
            setSlotsError(null);
          }
        }
      } catch {
        if (!cancelled) {
          setSlotsError("We couldn't load available times right now. Please try again.");
        }
      } finally {
        if (!cancelled) setSlotsLoading(false);
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [step, slotsReloadKey]);

  const selectedGroup = dayGroups.find((g) => g.dateKey === selectedDay) ?? null;

  const handleConfirm = async () => {
    if (!selectedTime || bookingPendingRef.current) return;
    bookingPendingRef.current = true;
    setBooking(true);
    setBookingResult(null);

    // 1) RECHECK AT COMMIT — re-fetch current availability and require the
    //    exact selected ISO slot to still be open before POSTing a booking.
    //    This is a PRE-POST check: if it fails, NO booking request was sent,
    //    so we must NOT claim one was. The error is retryable (a fresh
    //    availability recheck happens on the next Confirm click), the
    //    selection is preserved, and the action row stays available.
    const now = new Date();
    const startMs = now.getTime();
    const endMs = startMs + 14 * 24 * 60 * 60 * 1000;

    let fresh: FreeSlotsResponse | null = null;
    try {
      fresh = await fetchCalendarFreeSlots(CALENDAR_ID, startMs, endMs);
    } catch {
      // Availability recheck failed BEFORE any booking POST. No request was
      // sent — show a retryable availability error and keep the selection +
      // action row intact so the visitor can try again (which re-fetches).
      setBookingResult({
        ok: false,
        reason: "error",
        message:
          "We couldn't re-check availability right now. Please try again — your selected time is still saved.",
      });
      bookingPendingRef.current = false;
      setBooking(false);
      return;
    }

    // A successful HTTP GET may still decode to null/malformed JSON (e.g.
    // `null`, an array, or day records without a `slots` array). Treat any
    // structurally-invalid shape as a retryable PRE-POST read error (no
    // appointment was submitted) and release the guard/spinner — never leave
    // it stuck. A valid empty `{}` is NOT malformed: it is a legitimate
    // "no open times" outcome handled by the stillOpen check below.
    if (!isValidAvailabilityShape(fresh)) {
      setBookingResult({
        ok: false,
        reason: "error",
        message:
          "We couldn't read the latest availability right now. Please try again — your selected time is still saved.",
      });
      bookingPendingRef.current = false;
      setBooking(false);
      return;
    }

    // slotsToSet is defensive, but the shape is already validated above.
    const stillOpen = slotsToSet(fresh).has(selectedTime);

    if (!stillOpen) {
      // Slot is no longer available — refresh the visible list, clear the
      // selection, and show a real unavailable/retry state. No POST made.
      setDayGroups(toDayGroups(fresh));
      setSelectedTime(null);
      setSelectedDay(null);
      setBookingResult({
        ok: false,
        reason: "unavailable",
        message: "That time was just taken. Please choose another slot.",
      });
      bookingPendingRef.current = false;
      setBooking(false);
      return;
    }

    try {
      // 2) Re-validate contact details right before submission.
      if (!contactValid) {
        bookingPendingRef.current = false;
        setBooking(false);
        setStep("contact");
        setSubmitAttempted(true);
        return;
      }

      // 3) Submit with the stable session key (reused across retries).
      // Unified with Growth Snapshot intake: Consented/Not consented vocabulary.
      // Only appointment-text consent is sent from /schedule — no marketing or
      // AI voice consent fields are written here.
      const customFields = [
        {
          id: CUSTOM_FIELDS.appointmentTextConsent,
          field_value: consent ? "Consented" : "Not consented",
        },
        { id: CUSTOM_FIELDS.ctaSource, field_value: ctaSource },
      ];

      const result = await submitCalendarBooking({
        locationId: LOCATION_ID,
        calendarId: CALENDAR_ID,
        firstName: nameParts.firstName,
        lastName: nameParts.lastName,
        email: email.trim(),
        phone: phone.trim(),
        companyName: business.trim(),
        selectedSlot: selectedTime,
        sessionId: sessionIdRef.current,
        customFields,
      });

      setBookingResult(result);

      if (result.ok) {
        // Confirmed OR accepted-unverified: move out of the retryable slot
        // state. The "done" step renders the correct message per status.
        setStep("done");
      } else if (result.reason === "unavailable") {
        // Slot conflict reported by provider — refresh + force a re-pick.
        setSelectedTime(null);
        setSelectedDay(null);
        setStep("slot");
      }
      // "uncertain" and "error" results stay in the slot step; the banner
      // below the slot grid shows the appropriate message. For "uncertain"
      // we do NOT encourage an immediate retry (an appointment may exist).
      // "error" is a pre-POST failure — retryable, no appointment submitted.
    } catch {
      // Network failure AFTER the POST: ambiguous. An appointment may have
      // been created server-side even though we never received the response.
      // Do NOT encourage an immediate retry.
      setBookingResult({
        ok: false,
        reason: "uncertain",
        message:
          "We couldn't reach the booking service after sending your request. Your appointment may have been created — please check your email or contact us before trying again.",
      });
    } finally {
      bookingPendingRef.current = false;
      setBooking(false);
    }
  };

  const showFieldError = (key: string) =>
    (touched[key] || submitAttempted) &&
    !(key === "email"
      ? emailValid
      : key === "phone"
        ? phoneValid
        : key === "name"
          ? name.trim().length > 0
          : key === "business"
            ? business.trim().length > 0
            : true);

  return (
    <div className="w-full max-w-[548px] rounded-2xl bg-white border border-black/10 shadow-2xl overflow-hidden">
      <div className="p-6 lg:p-8">
        {/* STEP 1: CONTACT */}
        {step === "contact" && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setSubmitAttempted(true);
              if (!contactValid) return;

              // Guard double-click while a submission is pending.
              if (intakePendingRef.current || intakeSubmitting) return;

              const fp = contactFingerprint(name, email, phone, business, consent);
              // Skip re-emitting if the same contact payload already succeeded.
              if (intakeFingerprintRef.current === fp) {
                setIntakeError(null);
                setStep("slot");
                return;
              }

              intakePendingRef.current = true;
              setIntakeSubmitting(true);
              setIntakeError(null);

              const result = await trackGrowthCallBookingIntake({
                firstName: nameParts.firstName,
                lastName: nameParts.lastName,
                email: email.trim(),
                phone: phone.trim(),
                businessName: business.trim(),
                appointmentTexts: consent,
                ctaSource,
              });

              intakePendingRef.current = false;
              setIntakeSubmitting(false);

              if (!result.ok) {
                // Preserve input; show retry. Do NOT advance to slot step.
                setIntakeError(result.message);
                return;
              }

              // Success — record fingerprint so unchanged details don't re-emit.
              intakeFingerprintRef.current = fp;
              setStep("slot");
            }}
            className="space-y-5"
            noValidate
          >
            <div>
              {/* Source heading ~24px, H2 semantics */}
              <h2 className="text-[24px] font-bold text-ink leading-tight">
                Tell us where to send the invite.
              </h2>
              <p className="mt-1.5 text-sm text-warm leading-relaxed">
                Four details, then choose your appointment time.
              </p>
            </div>

            <div className="space-y-5" style={{ paddingTop: "17px" }}>
              <Field
                id="schedule-name"
                label="Name"
                required
                error={showFieldError("name") ? "Please enter your name." : undefined}
              >
                <input
                  id="schedule-name"
                  type="text"
                  required
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                  className={inputClass(showFieldError("name"))}
                  placeholder="Your name"
                  aria-invalid={showFieldError("name") || undefined}
                />
              </Field>
              <Field
                id="schedule-email"
                label="Email"
                required
                error={showFieldError("email") ? "Please enter a valid email address." : undefined}
              >
                <input
                  id="schedule-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                  className={inputClass(showFieldError("email"))}
                  placeholder="you@practice.com"
                  aria-invalid={showFieldError("email") || undefined}
                />
              </Field>
              <Field
                id="schedule-phone"
                label="Mobile number"
                required
                error={showFieldError("phone") ? "Please enter a valid mobile number." : undefined}
              >
                <input
                  id="schedule-phone"
                  type="tel"
                  required
                  autoComplete="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, phone: true }))}
                  className={inputClass(showFieldError("phone"))}
                  placeholder="(555) 123-4567"
                  aria-invalid={showFieldError("phone") || undefined}
                />
              </Field>
              <Field
                id="schedule-business"
                label="Business / practice name"
                required
                error={showFieldError("business") ? "Please enter your business name." : undefined}
              >
                <input
                  id="schedule-business"
                  type="text"
                  required
                  autoComplete="organization"
                  value={business}
                  onChange={(e) => setBusiness(e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, business: true }))}
                  className={inputClass(showFieldError("business"))}
                  placeholder="Practice name"
                  aria-invalid={showFieldError("business") || undefined}
                />
              </Field>
            </div>

            {/* Consent — simple unchecked checkbox with disclosure text on white (no tinted panel) */}
            <label
              className="flex items-start gap-3 cursor-pointer pt-2"
              style={{ paddingBottom: "13px" }}
            >
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-1 w-4 h-4 accent-phoenix shrink-0"
              />
              <span className="text-[11.5px] text-warm leading-snug">
                I agree to receive appointment confirmations and reminders by text from PhynyxPro.
                Message frequency varies. Message and data rates may apply. Reply STOP to opt out or
                HELP for help.
              </span>
            </label>

            {intakeError && (
              <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-bold text-ink">Couldn't save your details</p>
                  <p className="text-[12px] text-warm mt-1 leading-relaxed">{intakeError}</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={!contactValid || intakeSubmitting}
              className="w-full px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/30 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
            >
              {intakeSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Saving your details…
                </>
              ) : (
                <>
                  Choose My Appointment Time
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <p className="text-[11px] text-warm leading-relaxed pt-3 border-t border-black/5">
              No revenue, ad-budget, capacity, or funnel questions before booking.
            </p>
          </form>
        )}

        {/* STEP 2: SLOT SELECTION — real availability */}
        {step === "slot" && (
          <div className="space-y-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                Choose the time that works for you
              </p>

              {slotsLoading && (
                <div className="flex items-center gap-2 text-sm text-warm py-6">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Loading available times…
                </div>
              )}

              {slotsError && !slotsLoading && (
                <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-bold text-ink">Couldn't load times</p>
                    <p className="text-[12px] text-warm mt-1 leading-relaxed">{slotsError}</p>
                    <button
                      type="button"
                      onClick={() => setSlotsReloadKey((value) => value + 1)}
                      className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Retry
                    </button>
                  </div>
                </div>
              )}

              {!slotsLoading && !slotsError && dayGroups.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {dayGroups.map((g) => (
                    <button
                      key={g.dateKey}
                      type="button"
                      onClick={() => {
                        setSelectedDay(g.dateKey);
                        setSelectedTime(null);
                      }}
                      className={`rounded-xl border p-3 text-center transition-colors ${
                        selectedDay === g.dateKey
                          ? "border-phoenix bg-phoenix/5"
                          : "border-black/10 bg-white hover:border-phoenix/40"
                      }`}
                    >
                      <p className="text-[11px] font-bold uppercase tracking-wider text-warm">
                        {g.label}
                      </p>
                      <p className="text-sm font-bold text-ink mt-0.5">{g.sub}</p>
                    </button>
                  ))}
                </div>
              )}

              {!slotsLoading && !slotsError && dayGroups.length === 0 && (
                <div className="py-4 space-y-3">
                  <p className="text-sm text-warm">
                    No open times were found in the next two weeks. Please check back soon.
                  </p>
                  <Link
                    to="/support"
                    className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-phoenix hover:underline"
                  >
                    Contact us about scheduling →
                  </Link>
                </div>
              )}
            </div>

            {selectedGroup && (
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-phoenix mb-3">
                  Available times — {selectedGroup.label} {selectedGroup.sub}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {selectedGroup.slots.map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setSelectedTime(t)}
                      className={`rounded-lg border px-3 py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                        selectedTime === t
                          ? "border-phoenix bg-phoenix text-white"
                          : "border-black/10 bg-white text-ink hover:border-phoenix/40"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      {formatTimeLabel(t)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Booking failure banner — distinguishes retryable vs uncertain */}
            {bookingResult && !bookingResult.ok && (
              <SlotFailureBanner result={bookingResult} onDismiss={() => setBookingResult(null)} />
            )}

            {/* Hide the entire action row when an uncertain result is showing —
                an appointment may have been created; don't encourage a retry
                or re-entry to contact details (which could create a duplicate). */}
            {!(bookingResult && !bookingResult.ok && bookingResult.reason === "uncertain") && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-black/10">
                <button
                  type="button"
                  onClick={() => {
                    setStep("contact");
                    setSelectedDay(null);
                    setSelectedTime(null);
                    setBookingResult(null);
                  }}
                  className="text-xs font-semibold text-warm hover:text-ink underline"
                >
                  ← Edit contact details
                </button>
                <button
                  type="button"
                  disabled={!selectedTime || booking}
                  onClick={handleConfirm}
                  className="w-full sm:w-auto px-6 py-3.5 bg-phoenix hover:bg-ember disabled:bg-phoenix/30 disabled:cursor-not-allowed text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
                >
                  {booking ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Confirming…
                    </>
                  ) : (
                    <>
                      Confirm
                      {selectedGroup && selectedTime
                        ? ` · ${selectedGroup.label} ${formatTimeLabel(selectedTime)}`
                        : ""}
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 3: DONE — confirmed or accepted-unverified (no reset button) */}
        {step === "done" && bookingResult?.ok && (
          <DonePanel
            result={bookingResult}
            email={email}
            phone={phone}
            consent={consent}
            selectedGroup={selectedGroup}
            selectedTime={selectedTime}
          />
        )}
      </div>
    </div>
  );
}

const inputClass = (hasError?: boolean) =>
  `w-full px-4 py-3.5 rounded-lg border text-sm focus:outline-none focus:border-phoenix bg-ivory h-[53px] ${
    hasError ? "border-phoenix ring-1 ring-phoenix" : "border-black/15"
  }`;

function Field({
  id,
  label,
  required,
  error,
  children,
}: {
  id: string;
  label: string;
  required?: boolean;
  // Use `string | undefined` (not `?`) so callers may pass `undefined`
  // explicitly under `exactOptionalPropertyTypes`.
  error: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-ink mb-1.5">
        {label} {required && <span className="text-phoenix">*</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} className="mt-1 text-[11px] text-phoenix" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

/**
 * Availability helpers for the /schedule slot-picker UI.
 *
 * Extracted from ScheduleForm so the component stays focused on state/UI and
 * the shape-validation logic is unit-testable in isolation.
 */
import type { FreeSlotsResponse } from "./calendar";

export type DayGroup = { dateKey: string; label: string; sub: string; slots: string[] };

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/**
 * Validate a single slot entry is a non-empty string carrying an explicit
 * timezone designator (a trailing `Z` or a numeric `±HH:MM` offset), matching
 * the actual free-slots API contract. A bare local-time string (no offset)
 * is environment-dependent and must be rejected so a malformed successful GET
 * is never mistaken for a real open slot (which would clear the visitor's
 * selection as "taken").
 */
export function isIsoSlot(v: unknown): v is string {
  if (typeof v !== "string") return false;
  const t = v.trim();
  if (t === "") return false;
  // Must contain a date/time body plus an explicit timezone designator.
  if (!/^\d{4}-\d{2}-\d{2}T/.test(t)) return false;
  if (!/Z$/i.test(t) && !/[+-]\d{2}:\d{2}$/.test(t)) return false;
  // The full string must parse to a finite instant.
  return Number.isFinite(new Date(t).getTime());
}

/** Convert the raw free-slots response into ordered day groups. */
export function toDayGroups(slots: FreeSlotsResponse | null | undefined): DayGroup[] {
  if (!slots || typeof slots !== "object") return [];
  return Object.entries(slots)
    .filter(([, v]) => v?.slots?.length)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([dateKey, v]) => {
      const d = new Date(`${dateKey}T00:00:00`);
      const label = WEEKDAYS[d.getDay()] ?? "";
      const sub = d.toLocaleDateString([], { month: "short", day: "numeric" });
      return { dateKey, label, sub, slots: v.slots };
    });
}

/**
 * Validate that a fresh availability response is a usable object: a plain
 * object (not null/array) whose values are day records with a `slots` array,
 * AND every element of every `slots` array is a valid ISO-timestamp string
 * with an explicit timezone designator.
 *
 * Returns true only when the shape is structurally valid (it may still be
 * empty `{}`, which is a legitimate "no open times" outcome). A null, array,
 * malformed-nested response, or a slots array containing non-string / offsetless
 * entries returns false so the caller treats it as a retryable PRE-POST read
 * error rather than "slot taken".
 */
export function isValidAvailabilityShape(slots: unknown): slots is FreeSlotsResponse {
  if (!slots || typeof slots !== "object" || Array.isArray(slots)) return false;
  for (const v of Object.values(slots as Record<string, unknown>)) {
    if (v === null || typeof v !== "object" || !Array.isArray((v as { slots?: unknown }).slots)) {
      return false;
    }
    // Every slot entry must be a valid ISO timestamp string with an explicit
    // timezone. A `null`, number, empty, or offsetless entry makes the whole
    // response malformed.
    for (const entry of (v as { slots: unknown[] }).slots) {
      if (!isIsoSlot(entry)) return false;
    }
  }
  return true;
}

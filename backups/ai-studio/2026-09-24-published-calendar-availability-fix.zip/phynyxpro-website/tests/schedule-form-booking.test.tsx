import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";

// vi.mock factories are hoisted above imports, so the mock fns must be
// created with vi.hoisted to be referenceable inside the factory.
const mocks = vi.hoisted(() => ({
  fetchCalendarFreeSlots: vi.fn(),
  submitCalendarBooking: vi.fn(),
  trackGrowthCallBookingIntake: vi.fn(),
}));

// Mock the calendar module: availability recheck throws, booking never reached.
vi.mock("../src/lib/calendar", async () => {
  const actual = await vi.importActual<typeof import("../src/lib/calendar")>("../src/lib/calendar");
  return {
    ...actual,
    fetchCalendarFreeSlots: mocks.fetchCalendarFreeSlots,
    submitCalendarBooking: mocks.submitCalendarBooking,
  };
});

// Mock tracking so the contact intake does not hit the network.
vi.mock("../src/lib/growth-snapshot-tracking", () => ({
  trackGrowthCallBookingIntake: mocks.trackGrowthCallBookingIntake,
}));

const { fetchCalendarFreeSlots, submitCalendarBooking, trackGrowthCallBookingIntake } = mocks;

import { ScheduleForm } from "../src/components/ScheduleForm";
import { formatTimeLabel } from "../src/components/BookingResultPanel";

// ---------------------------------------------------------------------------
// Timezone-independent test fixtures.
//
// The production slot/time buttons render labels via `formatTimeLabel` and
// `toLocaleDateString`, which depend on the runtime locale+timezone. Hard-coding
// "4:30 PM" / "Sep 25" breaks in other timezones (e.g. America/Chicago renders
// "11:30 AM"). Instead, compute the EXACT rendered labels with the SAME
// formatters the component uses, so the selection always matches regardless of
// the CI/host timezone.
// ---------------------------------------------------------------------------
const SLOT_ISO = "2026-09-25T09:30:00-07:00";
const DAY_KEY = "2026-09-25";
const slotLabel = formatTimeLabel(SLOT_ISO);
const daySub = new Date(`${DAY_KEY}T00:00:00`).toLocaleDateString([], {
  month: "short",
  day: "numeric",
});

beforeEach(() => {
  fetchCalendarFreeSlots.mockReset();
  submitCalendarBooking.mockReset();
  trackGrowthCallBookingIntake.mockReset();
  trackGrowthCallBookingIntake.mockResolvedValue({ ok: true });
  // Stub crypto.randomUUID for the stable session id.
  vi.spyOn(crypto, "randomUUID").mockReturnValue("test-session-1");
});

function fillContact() {
  fireEvent.change(screen.getByPlaceholderText("Your name"), { target: { value: "Jane Doe" } });
  fireEvent.change(screen.getByPlaceholderText("you@practice.com"), {
    target: { value: "jane@test.com" },
  });
  fireEvent.change(screen.getByPlaceholderText("(555) 123-4567"), {
    target: { value: "5551234567" },
  });
  fireEvent.change(screen.getByPlaceholderText("Practice name"), {
    target: { value: "Acme Chiropractic" },
  });
}

/** Fill contact, submit intake, and select the single day + time slot. */
async function selectSlot() {
  fillContact();
  await act(async () => {
    fireEvent.click(screen.getByRole("button", { name: /Choose My Appointment Time/i }));
  });
  await waitFor(() => expect(fetchCalendarFreeSlots).toHaveBeenCalled());

  // Select the day (by its month/day sub-label) + time (by its formatted label).
  await act(async () => {
    fireEvent.click(screen.getAllByText(daySub)[0]!);
  });
  await act(async () => {
    fireEvent.click(screen.getAllByText(slotLabel)[0]!);
  });
}

/** The last "Confirm" button in the slot action row. */
const confirmBtn = () => screen.getAllByRole("button", { name: /Confirm/i }).at(-1)!;

describe("ScheduleForm — pre-POST availability recheck failure", () => {
  it("shows a retryable availability error and makes NO booking POST", async () => {
    // Initial slot load succeeds so we can reach the slot step.
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);

    await selectSlot();

    // Now make the COMMIT-TIME recheck throw. The first call was the initial
    // load; the second call (on Confirm) is the preflight recheck.
    fetchCalendarFreeSlots.mockRejectedValueOnce(new Error("preflight network down"));

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // The booking submit must NEVER have been called — no POST was made.
    expect(submitCalendarBooking).not.toHaveBeenCalled();

    // A retryable availability error is shown (not an uncertain "check your
    // email" message, which would imply a request was sent).
    await waitFor(() => {
      // The unique message text (the bold heading also says "Please try again"
      // so assert on the distinctive body copy instead).
      expect(screen.getByText(/couldn.t re-check availability/i)).toBeInTheDocument();
    });
    // The retry affordance is present.
    expect(screen.getByRole("button", { name: /Try again/i })).toBeInTheDocument();
  });

  it("preserves the selected slot + action row after a preflight failure (retryable)", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);

    await selectSlot();

    fetchCalendarFreeSlots.mockRejectedValueOnce(new Error("preflight down"));

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // The Confirm button must still be present (action row preserved) so the
    // visitor can retry — which re-runs the availability recheck.
    expect(confirmBtn()).toBeInTheDocument();
    expect(submitCalendarBooking).not.toHaveBeenCalled();
  });

  it("on retry: makes a fresh availability GET and only then exactly one POST", async () => {
    // Default: availability resolves with the slot open.
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });
    submitCalendarBooking.mockResolvedValue({
      ok: true,
      status: "confirmed",
      appointmentId: "apt_real",
      bookedStart: SLOT_ISO,
    });

    render(<ScheduleForm ctaSource="test-cta" />);

    await selectSlot();

    // 1st Confirm: preflight recheck FAILS (2nd fetchCalendarFreeSlots call).
    // mockRejectedValueOnce only affects the next call; the default still resolves.
    fetchCalendarFreeSlots.mockRejectedValueOnce(new Error("preflight down"));

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // No POST after the failed preflight.
    expect(submitCalendarBooking).not.toHaveBeenCalled();
    await waitFor(() => {
      expect(screen.getByText(/couldn.t re-check availability/i)).toBeInTheDocument();
    });

    // Dismiss the retryable banner (Try again) so the action row is fully active.
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /Try again/i }));
    });

    // 2nd Confirm: the preflight recheck must run AGAIN (a fresh GET), and
    // because it now succeeds and the slot is still open, exactly ONE POST
    // is made.
    const fetchCallsBefore = fetchCalendarFreeSlots.mock.calls.length;
    const postCallsBefore = submitCalendarBooking.mock.calls.length;

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // A fresh availability GET happened on retry.
    expect(fetchCalendarFreeSlots.mock.calls.length).toBeGreaterThan(fetchCallsBefore);
    // Exactly one booking POST was made — and only after the successful recheck.
    await waitFor(() => {
      expect(submitCalendarBooking).toHaveBeenCalledTimes(postCallsBefore + 1);
    });

    // The booking succeeded → done panel.
    await waitFor(() => {
      expect(screen.getByText(/You.s?re on the calendar/i)).toBeInTheDocument();
    });
    expect(screen.getByText(/apt_real/)).toBeInTheDocument();
  });
});

describe("ScheduleForm — confirmed booking with matching start", () => {
  it("advances to done when the provider confirms with a matching booked start", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });
    submitCalendarBooking.mockResolvedValue({
      ok: true,
      status: "confirmed",
      appointmentId: "apt_real",
      bookedStart: SLOT_ISO,
    });

    render(<ScheduleForm ctaSource="test-cta" />);

    await selectSlot();

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    await waitFor(() => {
      expect(screen.getByText(/You.s?re on the calendar/i)).toBeInTheDocument();
    });
    // The real appointment id is surfaced.
    expect(screen.getByText(/apt_real/)).toBeInTheDocument();
  });
});

describe("ScheduleForm — mismatched confirmed start falls back to accepted-unverified", () => {
  it("shows the accepted-unverified done panel when the confirmed start mismatches", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });
    // Provider returns a mismatched start; calendar.ts should return
    // accepted-unverified (not confirmed), so the done panel shows the
    // "request was received" message — never a false confirmation.
    submitCalendarBooking.mockResolvedValue({
      ok: true,
      status: "accepted-unverified",
    });

    render(<ScheduleForm ctaSource="test-cta" />);

    await selectSlot();

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    await waitFor(() => {
      expect(screen.getByText(/Your request was received/i)).toBeInTheDocument();
    });
    // No false confirmation.
    expect(screen.queryByText(/You.s?re on the calendar/i)).not.toBeInTheDocument();
  });
});

describe("ScheduleForm — malformed/null preflight availability", () => {
  it("null availability response => retryable error, zero POST, guard released", async () => {
    // Initial load succeeds so we can reach the slot step.
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    // Commit-time recheck resolves to null (malformed JSON decoded to null).
    fetchCalendarFreeSlots.mockResolvedValueOnce(null as unknown as Record<
      string,
      { slots: string[] }
    >);

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // No booking POST was made.
    expect(submitCalendarBooking).not.toHaveBeenCalled();

    // A retryable availability error is shown.
    await waitFor(() => {
      expect(screen.getByText(/couldn.t read the latest availability|couldn.t re-check availability/i)).toBeInTheDocument();
    });
    // Retry affordance present and Confirm still available (guard released).
    expect(screen.getByRole("button", { name: /Try again/i })).toBeInTheDocument();
    expect(confirmBtn()).toBeInTheDocument();
  });

  it("malformed availability (missing slots array) => retryable read error, zero POST, selection preserved", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    // Commit-time recheck resolves to a malformed shape (no slots arrays).
    fetchCalendarFreeSlots.mockResolvedValueOnce({ broken: true } as unknown as Record<
      string,
      { slots: string[] }
    >);

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    expect(submitCalendarBooking).not.toHaveBeenCalled();
    // Malformed shape => retryable read error (NOT "taken"), selection preserved.
    await waitFor(() => {
      expect(screen.getByText(/couldn.t read the latest availability/i)).toBeInTheDocument();
    });
    expect(screen.queryByText(/taken/i)).not.toBeInTheDocument();
    // Action row preserved so the visitor can retry (which re-fetches).
    expect(confirmBtn()).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Try again/i })).toBeInTheDocument();
  });

  it("after a malformed-availability retryable error, a safe retry succeeds", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });
    submitCalendarBooking.mockResolvedValue({
      ok: true,
      status: "confirmed",
      appointmentId: "apt_retry_ok",
      bookedStart: SLOT_ISO,
    });

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    // 1st Confirm: malformed availability (null).
    fetchCalendarFreeSlots.mockResolvedValueOnce(null as unknown as Record<
      string,
      { slots: string[] }
    >);

    await act(async () => {
      fireEvent.click(confirmBtn());
    });
    expect(submitCalendarBooking).not.toHaveBeenCalled();

    // Dismiss the retryable banner.
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /Try again/i }));
    });

    // 2nd Confirm: fresh GET succeeds (default mock), slot still open → one POST.
    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    await waitFor(() => {
      expect(submitCalendarBooking).toHaveBeenCalledTimes(1);
    });
    await waitFor(() => {
      expect(screen.getByText(/apt_retry_ok/)).toBeInTheDocument();
    });
  });
});

describe("ScheduleForm — uncertain result hides immediate retry", () => {
  it("post-POST uncertain failure shows check-email state with no Try again", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });
    // Network error AFTER the POST → uncertain (appointment may exist).
    submitCalendarBooking.mockRejectedValueOnce(new Error("post network down"));

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // Uncertain banner: "Check your email to confirm" + no immediate retry.
    await waitFor(() => {
      expect(screen.getByText(/Check your email to confirm/i)).toBeInTheDocument();
    });
    expect(screen.queryByRole("button", { name: /Try again/i })).not.toBeInTheDocument();
    // The action row (Confirm / Edit contact) is hidden to avoid a duplicate booking.
    expect(screen.queryByRole("button", { name: /Confirm/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Edit contact details/i })).not.toBeInTheDocument();
  });
});

describe("ScheduleForm — no open times fallback", () => {
  it("shows a /support fallback link when no open times are found", async () => {
    // Initial slot load returns a valid empty object (no open times).
    fetchCalendarFreeSlots.mockResolvedValue({});

    render(<ScheduleForm ctaSource="test-cta" />);
    fillContact();
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /Choose My Appointment Time/i }));
    });
    await waitFor(() => expect(fetchCalendarFreeSlots).toHaveBeenCalled());

    // The fallback link to /support is rendered.
    await waitFor(() => {
      expect(screen.getByRole("link", { name: /Contact us about scheduling/i })).toHaveAttribute(
        "href",
        "/support",
      );
    });
  });
});

describe("ScheduleForm — non-string slot entry in preflight availability", () => {
  it("slots array with a non-string entry => retryable read error, zero POST, selection preserved", async () => {
    // Initial load succeeds so we can reach the slot step.
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    // Commit-time recheck resolves to a slots array containing a non-string
    // entry (e.g. null or a number). This is a malformed successful GET and
    // must NOT be treated as a real open-slot list that clears the selection
    // as "taken".
    fetchCalendarFreeSlots.mockResolvedValueOnce({
      [DAY_KEY]: { slots: [SLOT_ISO, null] },
    } as unknown as Record<string, { slots: string[] }>);

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    // No booking POST was made.
    expect(submitCalendarBooking).not.toHaveBeenCalled();

    // A retryable availability read error is shown (NOT "taken").
    await waitFor(() => {
      expect(
        screen.getByText(/couldn.t read the latest availability|couldn.t re-check availability/i),
      ).toBeInTheDocument();
    });
    expect(screen.queryByText(/taken/i)).not.toBeInTheDocument();

    // Selection + action row preserved so the visitor can retry (which re-fetches).
    expect(confirmBtn()).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Try again/i })).toBeInTheDocument();
  });

  it("slots array with an offsetless string entry => retryable read error, zero POST", async () => {
    fetchCalendarFreeSlots.mockResolvedValue({
      [DAY_KEY]: { slots: [SLOT_ISO] },
    });

    render(<ScheduleForm ctaSource="test-cta" />);
    await selectSlot();

    // An offsetless local-time string is environment-dependent and must be
    // rejected as malformed.
    fetchCalendarFreeSlots.mockResolvedValueOnce({
      [DAY_KEY]: { slots: ["2026-09-25T09:30:00"] },
    } as unknown as Record<string, { slots: string[] }>);

    await act(async () => {
      fireEvent.click(confirmBtn());
    });

    expect(submitCalendarBooking).not.toHaveBeenCalled();

    await waitFor(() => {
      expect(
        screen.getByText(/couldn.t read the latest availability|couldn.t re-check availability/i),
      ).toBeInTheDocument();
    });
    expect(screen.queryByText(/taken/i)).not.toBeInTheDocument();
    expect(confirmBtn()).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Try again/i })).toBeInTheDocument();
  });
});

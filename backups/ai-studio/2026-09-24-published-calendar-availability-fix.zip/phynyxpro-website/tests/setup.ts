import "@testing-library/jest-dom";
import { vi } from "vitest";

// TanStack Router's <Link> reads router context at render time. The
// ScheduleForm component tests render the component in isolation (no router
// provider), so mock <Link> as a plain anchor that forwards href/children.
vi.mock("@tanstack/react-router", () => {
  const React = require("react");
  return {
    Link: React.forwardRef<
      HTMLAnchorElement,
      { to?: string; href?: string; search?: Record<string, unknown>; children?: React.ReactNode; className?: string }
    >(({ to, href, search, children, ...rest }, ref) => {
      let finalHref = href ?? to ?? "#";
      if (search && typeof search === "object") {
        const params = new URLSearchParams();
        for (const [k, v] of Object.entries(search)) {
          if (v !== undefined && v !== null) params.set(k, String(v));
        }
        const qs = params.toString();
        if (qs) finalHref = `${finalHref}?${qs}`;
      }
      return React.createElement("a", { ref, href: finalHref, ...rest }, children);
    }),
  };
});

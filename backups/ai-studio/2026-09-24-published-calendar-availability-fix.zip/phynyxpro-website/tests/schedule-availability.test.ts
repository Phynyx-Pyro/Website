import { describe, it, expect } from "vitest";
import { isValidAvailabilityShape, isIsoSlot, toDayGroups } from "../src/lib/schedule-availability";

describe("isIsoSlot", () => {
  it("accepts a valid ISO string with Z offset", () => {
    expect(isIsoSlot("2026-09-25T16:30:00Z")).toBe(true);
  });

  it("accepts a valid ISO string with numeric offset", () => {
    expect(isIsoSlot("2026-09-25T09:30:00-07:00")).toBe(true);
  });

  it("rejects a non-string", () => {
    expect(isIsoSlot(null)).toBe(false);
    expect(isIsoSlot(123)).toBe(false);
    expect(isIsoSlot(undefined)).toBe(false);
  });

  it("rejects an empty string", () => {
    expect(isIsoSlot("")).toBe(false);
    expect(isIsoSlot("   ")).toBe(false);
  });

  it("rejects an offsetless local-time string", () => {
    expect(isIsoSlot("2026-09-25T09:30:00")).toBe(false);
  });

  it("rejects a non-ISO string", () => {
    expect(isIsoSlot("not-a-date")).toBe(false);
    expect(isIsoSlot("2026/09/25 09:30:00-07:00")).toBe(false);
  });
});

describe("isValidAvailabilityShape", () => {
  it("accepts a valid populated object", () => {
    expect(
      isValidAvailabilityShape({ "2026-09-25": { slots: ["2026-09-25T09:30:00-07:00"] } }),
    ).toBe(true);
  });

  it("accepts a valid empty object (legitimate no-open-times)", () => {
    expect(isValidAvailabilityShape({})).toBe(true);
  });

  it("rejects null", () => {
    expect(isValidAvailabilityShape(null)).toBe(false);
  });

  it("rejects arrays", () => {
    expect(isValidAvailabilityShape([])).toBe(false);
  });

  it("rejects malformed nested day records (missing slots array)", () => {
    expect(isValidAvailabilityShape({ broken: true })).toBe(false);
  });

  it("rejects a day record whose slots is not an array", () => {
    expect(isValidAvailabilityShape({ "2026-09-25": { slots: "not-array" } })).toBe(false);
  });

  it("rejects a day record that is null", () => {
    expect(isValidAvailabilityShape({ "2026-09-25": null })).toBe(false);
  });

  it("rejects a slots array containing a null entry", () => {
    expect(
      isValidAvailabilityShape({ "2026-09-25": { slots: ["2026-09-25T09:30:00-07:00", null] } }),
    ).toBe(false);
  });

  it("rejects a slots array containing a number entry", () => {
    expect(
      isValidAvailabilityShape({ "2026-09-25": { slots: [123] } }),
    ).toBe(false);
  });

  it("rejects a slots array containing an offsetless string entry", () => {
    expect(
      isValidAvailabilityShape({ "2026-09-25": { slots: ["2026-09-25T09:30:00"] } }),
    ).toBe(false);
  });

  it("rejects a slots array containing an empty string entry", () => {
    expect(
      isValidAvailabilityShape({ "2026-09-25": { slots: [""] } }),
    ).toBe(false);
  });

  it("accepts a slots array with multiple valid ISO entries", () => {
    expect(
      isValidAvailabilityShape({
        "2026-09-25": {
          slots: ["2026-09-25T09:30:00-07:00", "2026-09-25T10:00:00-07:00", "2026-09-25T16:30:00Z"],
        },
      }),
    ).toBe(true);
  });
});

describe("toDayGroups", () => {
  it("returns empty for null/undefined", () => {
    expect(toDayGroups(null)).toEqual([]);
    expect(toDayGroups(undefined)).toEqual([]);
  });

  it("returns empty for an empty object", () => {
    expect(toDayGroups({})).toEqual([]);
  });

  it("groups and orders valid days", () => {
    const groups = toDayGroups({
      "2026-09-26": { slots: ["2026-09-26T10:00:00-07:00"] },
      "2026-09-25": { slots: ["2026-09-25T09:30:00-07:00"] },
    });
    expect(groups).toHaveLength(2);
    expect(groups[0]!.dateKey).toBe("2026-09-25");
    expect(groups[1]!.dateKey).toBe("2026-09-26");
  });
});

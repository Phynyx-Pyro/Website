import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearch } from "@tanstack/react-router";
import {
  ArrowRight,
  Clock,
  Activity,
  ShieldX,
  Globe,
  Download,
  AlertCircle,
  Loader2,
  TrendingUp,
  CheckCircle2,
} from "lucide-react";
import {
  trackGrowthSnapshotIntake,
  trackGrowthSnapshotCompletion,
  type TrackingResult,
} from "../lib/growth-snapshot-tracking";
import {
  type FunnelMetric,
  EMPTY_METRIC,
  loadPersisted,
  persistState,
  clearPersisted,
  metricNum,
  metricFloat,
  freeNum,
  round1,
  pct,
  buildRates,
  costPer,
  formatMoney,
  formatRate,
  computeScenario,
  buildSummary,
  downloadSnapshot,
  validateFunnelSequence,
  validateFreeSequence,
} from "../lib/growth-snapshot-calc";
import {
  MetaItem,
  FreeInput,
  RateStat,
  Field,
  SelectField,
  ConsentCheck,
  MetricInput,
  KpiTile,
  SequenceIssueBanner,
  ErrorBanner,
  Card,
  PRIMARY_BUTTON,
  FULL_BUTTON,
} from "./growth-snapshot-ui";

const CTA_FALLBACK = "growth-assessment-contact";
const CTA_RE = /^[a-zA-Z0-9_-]+$/;

function parseCtaSource(raw: unknown): string {
  if (typeof raw !== "string") return CTA_FALLBACK;
  if (raw.length === 0 || raw.length > 64) return CTA_FALLBACK;
  if (!CTA_RE.test(raw)) return CTA_FALLBACK;
  return raw;
}

type Step = "free" | "contact" | "business" | "funnel" | "snapshot";

const STEP_LABEL: Record<Step, string> = {
  free: "",
  contact: "Step 1 of 4",
  business: "Step 2 of 4",
  funnel: "Step 3 of 4",
  snapshot: "Step 4 of 4",
};

const STEP_SUB: Record<Exclude<Step, "free">, string> = {
  contact: "Save your snapshot",
  business: "Business context",
  funnel: "Funnel numbers",
  snapshot: "Your snapshot",
};

const STEP_WIDTH: Record<Exclude<Step, "free">, string> = {
  contact: "25%",
  business: "50%",
  funnel: "75%",
  snapshot: "100%",
};

const CONSENT_TEXT = {
  appointment:
    "I agree to non-marketing texts from PhynyxPro about diagnostic appointment confirmations, reminders, and changes. Frequency varies. Message and data rates may apply. Reply STOP to opt out, HELP for help.",
  marketing:
    "I agree to automated marketing texts from PhynyxPro about its services, my snapshot, and booking a diagnostic at the number provided. Frequency varies. Message and data rates may apply. Reply STOP to opt out, HELP for help. Consent is not required to buy.",
  aiVoice:
    "I agree to marketing calls from PhynyxPro at the number provided about its services, my snapshot, and diagnostic, using an automated system and an artificial or AI-generated voice. Consent is not required to buy. Ask us to stop anytime.",
};

export function GrowthAssessmentFunnel({
  defaultIndustry = "chiropractic",
}: {
  defaultIndustry?: string;
}) {
  const search = useSearch({ strict: false }) as Record<string, unknown>;
  const ctaSource = parseCtaSource(search["cta"]);

  const restored = useRef(loadPersisted());
  const r = (restored.current ?? {}) as Partial<ReturnType<typeof loadPersisted>>;

  const [step, setStep] = useState<Step>((r.step as Step) ?? "free");

  const [leads, setLeads] = useState(r.leads ?? "");
  const [booked, setBooked] = useState(r.booked ?? "");
  const [showed, setShowed] = useState(r.showed ?? "");

  const leadsNum = freeNum(leads);
  const bookedNum = freeNum(booked);
  const showedNum = freeNum(showed);
  const hasAllThree = leadsNum !== null && bookedNum !== null && showedNum !== null;

  const bookedRate = leadsNum !== null && bookedNum !== null ? pct(bookedNum, leadsNum) : null;
  const showRate = bookedNum !== null && showedNum !== null ? pct(showedNum, bookedNum) : null;
  const dropoff =
    bookedNum !== null && showedNum !== null && showedNum <= bookedNum && bookedNum > 0
      ? round1(((bookedNum - showedNum) / bookedNum) * 100)
      : null;

  const freeSequenceIssues = useMemo(
    () => validateFreeSequence(leadsNum, bookedNum, showedNum),
    [leadsNum, bookedNum, showedNum],
  );
  const freeSequenceOk = freeSequenceIssues.length === 0;

  const [businessName, setBusinessName] = useState(r.businessName ?? "");
  const [firstName, setFirstName] = useState(r.firstName ?? "");
  const [lastName, setLastName] = useState(r.lastName ?? "");
  const [email, setEmail] = useState(r.email ?? "");
  const [phone, setPhone] = useState(r.phone ?? "");
  const [appointmentTexts, setAppointmentTexts] = useState(r.appointmentTexts ?? false);
  const [marketingTexts, setMarketingTexts] = useState(r.marketingTexts ?? false);
  const [aiPhoneCalls, setAiPhoneCalls] = useState(r.aiPhoneCalls ?? false);

  const [practiceName, setPracticeName] = useState(r.practiceName ?? "");
  const [role, setRole] = useState(r.role ?? "Owner / Chiropractor");
  const [locations, setLocations] = useState(r.locations ?? "1");
  const [adSpend, setAdSpend] = useState(r.adSpend ?? "$1,000 - $3,000/mo");
  const [avgStartValue, setAvgStartValue] = useState(r.avgStartValue ?? "");
  const [industry, setIndustry] = useState(r.industry ?? defaultIndustry);

  const [mInquiries, setMInquiries] = useState<FunnelMetric>(r.mInquiries ?? EMPTY_METRIC);
  const [mContacted, setMContacted] = useState<FunnelMetric>(r.mContacted ?? EMPTY_METRIC);
  const [mBooked, setMBooked] = useState<FunnelMetric>(r.mBooked ?? EMPTY_METRIC);
  const [mConfirmed, setMConfirmed] = useState<FunnelMetric>(r.mConfirmed ?? EMPTY_METRIC);
  const [mShowed, setMShowed] = useState<FunnelMetric>(r.mShowed ?? EMPTY_METRIC);
  const [mStarted, setMStarted] = useState<FunnelMetric>(r.mStarted ?? EMPTY_METRIC);
  const [mAdSpend, setMAdSpend] = useState<FunnelMetric>(r.mAdSpend ?? EMPTY_METRIC);
  const [mAvgStartValue, setMAvgStartValue] = useState<FunnelMetric>(
    r.mAvgStartValue ?? EMPTY_METRIC,
  );

  const [intakeStatus, setIntakeStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [intakeResult, setIntakeResult] = useState<TrackingResult | null>(null);
  const intakeSubmittingRef = useRef(false);

  const [completionStatus, setCompletionStatus] = useState<
    "idle" | "submitting" | "done" | "error"
  >("idle");
  const [completionResult, setCompletionResult] = useState<TrackingResult | null>(null);
  const completionSubmittingRef = useRef(false);

  useEffect(() => {
    persistState({
      version: 1,
      savedAt: Date.now(),
      step,
      leads,
      booked,
      showed,
      businessName,
      firstName,
      lastName,
      email,
      phone,
      appointmentTexts,
      marketingTexts,
      aiPhoneCalls,
      practiceName,
      role,
      locations,
      adSpend,
      avgStartValue,
      industry,
      mInquiries,
      mContacted,
      mBooked,
      mConfirmed,
      mShowed,
      mStarted,
      mAdSpend,
      mAvgStartValue,
    });
  }, [
    step,
    leads,
    booked,
    showed,
    businessName,
    firstName,
    lastName,
    email,
    phone,
    appointmentTexts,
    marketingTexts,
    aiPhoneCalls,
    practiceName,
    role,
    locations,
    adSpend,
    avgStartValue,
    industry,
    mInquiries,
    mContacted,
    mBooked,
    mConfirmed,
    mShowed,
    mStarted,
    mAdSpend,
    mAvgStartValue,
  ]);

  const nInquiries = metricNum(mInquiries);
  const nContacted = metricNum(mContacted);
  const nBooked = metricNum(mBooked);
  const nConfirmed = metricNum(mConfirmed);
  const nShowed = metricNum(mShowed);
  const nStarted = metricNum(mStarted);
  const nAdSpend = metricFloat(mAdSpend);
  const nAvgStartValue = metricFloat(mAvgStartValue);

  const rates = useMemo(
    () =>
      buildRates({
        inquiries: nInquiries,
        contacted: nContacted,
        booked: nBooked,
        confirmed: nConfirmed,
        showed: nShowed,
        started: nStarted,
      }),
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed, nStarted],
  );
  const validRates = rates.filter((rr) => rr.rate !== null);
  const trackedCount = [
    nInquiries,
    nContacted,
    nBooked,
    nConfirmed,
    nShowed,
    nStarted,
    nAdSpend,
    nAvgStartValue,
  ].filter((n) => n !== null).length;
  const weakest =
    validRates.length > 0
      ? validRates.reduce((min, rr) => (rr.rate! < min.rate! ? rr : min))
      : null;
  const sequenceIssues = useMemo(
    () =>
      validateFunnelSequence({
        inquiries: nInquiries,
        contacted: nContacted,
        booked: nBooked,
        confirmed: nConfirmed,
        showed: nShowed,
        started: nStarted,
      }),
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed, nStarted],
  );
  const scenario = computeScenario(
    rates,
    [nInquiries, nContacted, nBooked, nConfirmed, nShowed],
    nStarted,
  );
  const cpl = costPer(nInquiries, nAdSpend);
  const cpb = costPer(nBooked, nAdSpend);
  const cps = costPer(nShowed, nAdSpend);
  const cpStart = costPer(nStarted, nAdSpend);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (intakeSubmittingRef.current) return;
    intakeSubmittingRef.current = true;
    setIntakeStatus("submitting");
    setIntakeResult(null);
    const result = await trackGrowthSnapshotIntake({
      businessName,
      firstName,
      lastName,
      email,
      phone,
      appointmentTexts,
      marketingTexts,
      aiPhoneCalls,
      ctaSource,
    });
    setIntakeResult(result);
    intakeSubmittingRef.current = false;
    if (result.ok) {
      setIntakeStatus("idle");
      setStep("business");
    } else {
      setIntakeStatus("error");
    }
  };

  const handleShowSnapshot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (completionSubmittingRef.current) return;
    completionSubmittingRef.current = true;
    setCompletionStatus("submitting");
    setCompletionResult(null);

    const summary = buildSummary({
      industry,
      businessName,
      practiceName,
      firstName,
      lastName,
      email,
      phone,
      role,
      locations,
      adSpend,
      avgStartValue,
      leadsNum,
      bookedNum,
      showedNum,
      bookedRate,
      showRate,
      dropoff,
      metrics: [
        ["Inquiries", nInquiries, mInquiries.quality],
        ["Contacted", nContacted, mContacted.quality],
        ["Booked", nBooked, mBooked.quality],
        ["Confirmed", nConfirmed, mConfirmed.quality],
        ["Showed", nShowed, mShowed.quality],
        ["Started (care)", nStarted, mStarted.quality],
        ["Ad spend", nAdSpend, mAdSpend.quality],
        ["Avg start value", nAvgStartValue, mAvgStartValue.quality],
      ],
      rates,
      cpl,
      cpb,
      cps,
      cpStart,
      weakest,
      scenario,
      sequenceIssues,
    });

    const result = await trackGrowthSnapshotCompletion({
      businessName: businessName || practiceName,
      firstName,
      lastName,
      email,
      phone,
      ctaSource,
      status: "Completed",
      completedAt: new Date().toISOString(),
      summary,
      industry,
      primaryChallenge: weakest
        ? `${weakest.label} (${weakest.from}→${weakest.to}) at ${weakest.rate}%`
        : "Not enough data to identify",
    });
    setCompletionResult(result);
    setCompletionStatus(result.ok ? "done" : "error");
    completionSubmittingRef.current = false;
  };

  const handleDownload = () =>
    downloadSnapshot({
      industry,
      leadsNum,
      bookedNum,
      showedNum,
      bookedRate,
      showRate,
      dropoff,
      nInquiries,
      nContacted,
      nBooked,
      nConfirmed,
      nShowed,
      nStarted,
      nAdSpend,
      nAvgStartValue,
      mInquiries,
      mContacted,
      mBooked,
      mConfirmed,
      mShowed,
      mStarted,
      mAdSpend,
      mAvgStartValue,
      rates,
      cpl,
      cpb,
      cps,
      cpStart,
      weakest,
      scenario,
      sequenceIssues,
    });

  const handleStartOver = () => {
    clearPersisted();
    setStep("free");
    setLeads("");
    setBooked("");
    setShowed("");
    setBusinessName("");
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
    setAppointmentTexts(false);
    setMarketingTexts(false);
    setAiPhoneCalls(false);
    setPracticeName("");
    setRole("Owner / Chiropractor");
    setLocations("1");
    setAdSpend("$1,000 - $3,000/mo");
    setAvgStartValue("");
    setIndustry(defaultIndustry);
    setMInquiries(EMPTY_METRIC);
    setMContacted(EMPTY_METRIC);
    setMBooked(EMPTY_METRIC);
    setMConfirmed(EMPTY_METRIC);
    setMShowed(EMPTY_METRIC);
    setMStarted(EMPTY_METRIC);
    setMAdSpend(EMPTY_METRIC);
    setMAvgStartValue(EMPTY_METRIC);
    setIntakeStatus("idle");
    setIntakeResult(null);
    setCompletionStatus("idle");
    setCompletionResult(null);
  };

  const scheduleLink = (
    <Link
      to="/schedule"
      search={{ cta: "growth-snapshot-complete" }}
      className="inline-flex items-center gap-2 px-6 py-3.5 bg-phoenix hover:bg-ember text-white font-semibold text-sm rounded-lg transition-colors shadow-[0_12px_28px_-12px_rgba(184,68,32,0.95)]"
    >
      Schedule My Growth Call <ArrowRight className="w-4 h-4" />
    </Link>
  );

  return (
    <div className="mx-auto w-full max-w-[720px]">
      {step === "free" ? (
        <div className="text-center mb-12 lg:mb-14">
          <h1 className="text-3xl sm:text-4xl lg:text-[52px] font-bold tracking-tight leading-[1.08]">
            See Where Demand <span className="text-phoenix">Stops Moving</span>
          </h1>
          <p className="mt-5 text-base text-warm leading-relaxed max-w-xl mx-auto">
            Use three numbers from a recent 30-day period to see two handoffs in your acquisition
            funnel. Try it free, without sharing contact details.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-warm">
            <MetaItem icon={Clock} label="About 30 seconds" />
            <MetaItem icon={Activity} label="Live conversion math" />
            <MetaItem icon={ShieldX} label="No performance guarantee" />
          </div>
        </div>
      ) : (
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl lg:text-[52px] font-bold tracking-tight leading-[1.08]">
            Build Your Acquisition <span className="text-phoenix">Growth Snapshot</span>
          </h1>
          <p className="mt-5 text-base text-warm leading-relaxed max-w-xl mx-auto">
            Use your most recent complete 30-day period. Exact numbers are best, estimates are
            useful, and &ldquo;not tracked&rdquo; is a valid answer.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-warm">
            <MetaItem icon={Clock} label="About 3 minutes" />
            <MetaItem icon={Activity} label="Immediate KPI snapshot" />
            <MetaItem icon={ShieldX} label="No performance guarantee" />
            <MetaItem icon={Globe} label="Website" />
          </div>
          <div className="mt-8 max-w-md mx-auto text-left">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-widest text-warm mb-2">
              <span>{STEP_LABEL[step]}</span>
              <span>{STEP_SUB[step]}</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-linen overflow-hidden">
              <div
                className="h-full rounded-full bg-phoenix transition-all"
                style={{ width: STEP_WIDTH[step] }}
              />
            </div>
          </div>
        </div>
      )}

      {step === "free" && (
        <Card className="p-6 lg:p-8 mx-auto w-full max-w-[720px]">
          <p className="text-[11px] font-bold uppercase tracking-widest text-phoenix mb-3">
            Free Funnel Check
          </p>
          <h2 className="text-[22px] font-bold tracking-tight text-ink leading-[1.2]">
            Your last complete 30 days
          </h2>
          <p className="mt-3 text-sm text-warm leading-relaxed">
            Estimates are fine. Leave these blank if you do not track them yet.
          </p>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <FreeInput
              id="free-leads"
              label="New Leads & Inquiries"
              hint="Calls, forms, chats, and other new leads"
              placeholder="80"
              value={leads}
              onChange={setLeads}
            />
            <FreeInput
              id="free-booked"
              label="Appointments Booked"
              hint="New prospects who selected a time"
              placeholder="28"
              value={booked}
              onChange={setBooked}
            />
            <FreeInput
              id="free-showed"
              label="Showed"
              hint="Booked prospects who actually showed up"
              placeholder="20"
              value={showed}
              onChange={setShowed}
            />
          </div>
          <div className="mt-5">
            {hasAllThree && freeSequenceOk ? (
              <div className="rounded-xl bg-night text-white grain-dark p-4 border border-white/10 grid grid-cols-3 gap-3 text-center">
                <RateStat label="Booked Rate" value={bookedRate} sub="Inquiry → Booked" />
                <RateStat label="Show Rate" value={showRate} sub="Booked → Attended" />
                <RateStat label="Drop-off" value={dropoff} sub="Booked → Show gap" />
              </div>
            ) : hasAllThree && !freeSequenceOk ? (
              <SequenceIssueBanner
                title="Check your counts"
                issues={freeSequenceIssues}
                footer="Rates are hidden until the sequence is valid (Showed ≤ Booked ≤ Leads)."
              />
            ) : (
              <p className="text-sm text-warm leading-relaxed">
                Enter all three counts to see your conversion rates. No contact details are needed.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={() => setStep("contact")}
            className={`mt-6 ${FULL_BUTTON}`}
          >
            Continue Without Numbers <ArrowRight className="w-4 h-4" />
          </button>
          <p className="mt-4 text-[12px] text-warm/80 leading-relaxed text-center">
            This calculation stays in your browser until you choose to continue. It is not a
            forecast or performance guarantee.
          </p>
        </Card>
      )}

      {step === "contact" && (
        <form onSubmit={handleContactSubmit} className="space-y-5 p-6 lg:p-8">
          <Card className="p-6 lg:p-8 space-y-5">
            <div>
              <h2 className="text-lg font-bold text-ink">Save Your Snapshot</h2>
              <p className="mt-1 text-[12px] text-warm leading-relaxed">
                Tell us about you and your business so we can save your progress.
              </p>
            </div>
            {intakeStatus === "error" && intakeResult && (
              <ErrorBanner
                title="Your details could not be saved"
                message={intakeResult.message}
                detail="Your entries are preserved. You can retry without losing progress."
              />
            )}
            <Field
              id="snap-business"
              label="Business Name"
              required
              value={businessName}
              onChange={setBusinessName}
              type="text"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field
                id="snap-first"
                label="First Name"
                required
                value={firstName}
                onChange={setFirstName}
                type="text"
              />
              <Field
                id="snap-last"
                label="Last Name"
                required
                value={lastName}
                onChange={setLastName}
                type="text"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field
                id="snap-email"
                label="Work Email"
                required
                value={email}
                onChange={setEmail}
                type="email"
              />
              <Field
                id="snap-phone"
                label="Phone"
                required
                value={phone}
                onChange={setPhone}
                type="tel"
              />
            </div>
            <div className="pt-2">
              <p className="text-[11px] font-bold text-warm uppercase tracking-wider">
                Stay in touch (optional)
              </p>
              <p className="mt-1 text-[12px] text-warm leading-relaxed">
                Choose any, or skip and continue.
              </p>
              <div className="mt-3 space-y-3">
                <ConsentCheck
                  title="Appointment texts"
                  checked={appointmentTexts}
                  onChange={setAppointmentTexts}
                  text={CONSENT_TEXT.appointment}
                />
                <ConsentCheck
                  title="Marketing texts"
                  checked={marketingTexts}
                  onChange={setMarketingTexts}
                  text={CONSENT_TEXT.marketing}
                />
                <ConsentCheck
                  title="AI phone calls"
                  checked={aiPhoneCalls}
                  onChange={setAiPhoneCalls}
                  text={CONSENT_TEXT.aiVoice}
                />
              </div>
            </div>
            <p className="text-[11px] text-warm/80 leading-relaxed pt-1">
              We&rsquo;ll email you about your snapshot and requested follow-up.{" "}
              <Link to="/privacy-policy" className="underline hover:text-ink">
                Privacy Policy
              </Link>{" "}
              ·{" "}
              <Link to="/terms" className="underline hover:text-ink">
                Terms
              </Link>
            </p>
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => setStep("free")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to free check
            </button>
            <button
              type="submit"
              disabled={intakeStatus === "submitting"}
              className={PRIMARY_BUTTON}
            >
              {intakeStatus === "submitting" ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Saving…
                </>
              ) : (
                <>
                  Continue to Practice Baseline <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {step === "business" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setStep("funnel");
          }}
          className="space-y-5"
        >
          <Card className="p-6 lg:p-8 space-y-5">
            <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
              Step 2 of 4 · Business context
            </p>
            <h2 className="text-lg font-bold text-ink">Practice & Readiness Details</h2>
            <Field
              id="snap-practice-name"
              label="Practice Name"
              required
              value={practiceName}
              onChange={setPracticeName}
              type="text"
            />
            <div>
              <label htmlFor="snap-industry" className="block text-xs font-semibold text-ink mb-1">
                Industry
              </label>
              <select
                id="snap-industry"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-black/15 text-sm focus:outline-none focus:border-phoenix bg-white"
              >
                <option value="chiropractic">Chiropractic</option>
                <option value="home-services">Home Services</option>
                <option value="dental-medspa">Dental & Medspa</option>
                <option value="other-service">Other Service Business</option>
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <SelectField
                id="snap-role"
                label="Role"
                value={role}
                onChange={setRole}
                options={[
                  "Owner / Chiropractor",
                  "Practice Manager",
                  "Marketing Director",
                  "Other Staff",
                ]}
              />
              <SelectField
                id="snap-locations"
                label="Locations"
                value={locations}
                onChange={setLocations}
                options={["1", "2-3", "4+"]}
              />
              <SelectField
                id="snap-adspend"
                label="Monthly Ad Budget"
                value={adSpend}
                onChange={setAdSpend}
                options={[
                  "Under $1,000/mo",
                  "$1,000 - $3,000/mo",
                  "$3,000 - $5,000/mo",
                  "$5,000+/mo",
                ]}
              />
            </div>
            <Field
              id="snap-avg-start"
              label="Average start-of-care / service value (optional)"
              value={avgStartValue}
              onChange={setAvgStartValue}
              type="text"
            />
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => setStep("contact")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to contact
            </button>
            <button type="submit" className={PRIMARY_BUTTON}>
              Continue to Funnel Numbers <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {step === "funnel" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleShowSnapshot(e); setStep("snapshot");
          }}
          className="space-y-5"
        >
          <Card className="p-6 lg:p-8 space-y-5">
            <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
              Step 3 of 4 · Funnel numbers
            </p>
            <h2 className="text-lg font-bold text-ink">Your Recent 30-Day Metrics</h2>
            <p className="text-[12px] text-warm leading-relaxed">
              Enter what you track. Each field accepts a number plus whether it is Exact, an
              Estimate, or Not tracked. Missing data is valid and part of what we&rsquo;ll map.
            </p>
            <div className="space-y-4">
              <MetricInput
                label="Inquiries"
                hint="Calls, forms, chats, and other new leads"
                metric={mInquiries}
                onChange={setMInquiries}
              />
              <MetricInput
                label="Contacted"
                hint="Leads you actually reached/responded to"
                metric={mContacted}
                onChange={setMContacted}
              />
              <MetricInput
                label="Booked"
                hint="Prospects who selected a time"
                metric={mBooked}
                onChange={setMBooked}
              />
              <MetricInput
                label="Confirmed"
                hint="Booked appointments with a confirmed time"
                metric={mConfirmed}
                onChange={setMConfirmed}
              />
              <MetricInput
                label="Showed"
                hint="Confirmed appointments that were attended"
                metric={mShowed}
                onChange={setMShowed}
              />
              <MetricInput
                label="Started (care/services)"
                hint="New patients/clients who started care or service"
                metric={mStarted}
                onChange={setMStarted}
              />
              <MetricInput
                label="Ad Spend ($)"
                hint="Total media spend in the period (decimals allowed)"
                metric={mAdSpend}
                onChange={setMAdSpend}
              />
              <MetricInput
                label="Average Start Value ($)"
                hint="Average revenue per start of care/service (decimals allowed)"
                metric={mAvgStartValue}
                onChange={setMAvgStartValue}
              />
            </div>
          </Card>
          <div className="flex items-center justify-between pt-4 border-t border-black/10 gap-3">
            <button
              type="button"
              onClick={() => setStep("business")}
              className="text-[12px] font-semibold text-warm hover:text-ink"
            >
              ← Back to business context
            </button>
            <button type="submit" className={PRIMARY_BUTTON}>
              Show My Growth Snapshot <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {step === "snapshot" && (
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 space-y-6">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-widest text-warm">
                Step 4 of 4 · Your snapshot
              </p>
              <h2 className="text-2xl font-bold text-ink mt-2">Your Growth Snapshot</h2>
              <p className="mt-2 text-sm text-warm leading-relaxed">
                Live KPIs from the numbers you entered. Missing or inconsistent data shows as
                &ldquo;Not enough data&rdquo; — we never invent numbers.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <KpiTile label="Metrics Tracked" value={`${trackedCount}/8`} />
              <KpiTile label="Valid Rates" value={`${validRates.length}/5`} />
              <KpiTile label="Cost / Lead" value={formatMoney(cpl)} />
              <KpiTile label="Cost / Start" value={formatMoney(cpStart)} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-ink mb-3">Conversion Rates</h3>
              <div className="space-y-2">
                {rates.map((rr) => (
                  <div
                    key={rr.label}
                    className="flex items-center justify-between rounded-lg bg-ivory/60 px-4 py-2.5 border border-black/5"
                  >
                    <div>
                      <p className="text-sm font-semibold text-ink">{rr.label}</p>
                      <p className="text-[11px] text-warm">
                        {rr.from} → {rr.to}
                      </p>
                    </div>
                    <p
                      className={`text-lg font-bold ${rr.rate === null ? "text-warm/50" : "text-phoenix"}`}
                    >
                      {formatRate(rr.rate)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-ink mb-3">Cost Metrics</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <KpiTile label="Cost / Lead" value={formatMoney(cpl)} />
                <KpiTile label="Cost / Booked" value={formatMoney(cpb)} />
                <KpiTile label="Cost / Show" value={formatMoney(cps)} />
                <KpiTile label="Cost / Start" value={formatMoney(cpStart)} />
              </div>
            </div>
            {sequenceIssues.length > 0 && (
              <SequenceIssueBanner
                title="Check your funnel counts"
                issues={sequenceIssues}
                footer="Rates for inconsistent stages are hidden. Fix the counts and the scenario will update."
              />
            )}
            <div className="rounded-xl bg-linen border border-black/10 p-4">
              <p className="text-[11px] font-bold uppercase tracking-wider text-warm mb-1">
                Primary Challenge
              </p>
              {weakest ? (
                <p className="text-sm text-ink">
                  <span className="font-bold">{weakest.label}</span> ({weakest.from} → {weakest.to})
                  at <span className="text-phoenix font-bold">{weakest.rate}%</span> — the weakest
                  observed handoff.
                </p>
              ) : (
                <p className="text-sm text-warm">
                  Not enough data to identify a primary challenge. Add more tracked metrics to see
                  this.
                </p>
              )}
            </div>
            <div className="rounded-xl bg-night text-white grain-dark border border-white/10 p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-flame" />
                <p className="text-[11px] font-bold uppercase tracking-wider text-white/70">
                  Illustrative Scenario
                </p>
              </div>
              {scenario ? (
                <div className="space-y-1.5 text-sm">
                  <p>
                    If <span className="font-bold text-flame">{scenario.stage}</span> improved by{" "}
                    <span className="font-bold">+10 percentage points</span> (to{" "}
                    {scenario.improvedRate}%), propagating your observed downstream conversion:
                  </p>
                  {scenario.additionalStarts !== null ? (
                    <p className="text-white/90">
                      Estimated additional starts of care:{" "}
                      <span className="font-bold text-flame">{scenario.additionalStarts}</span>
                    </p>
                  ) : (
                    <p className="text-white/70">
                      Start count not tracked — scenario shows rate impact only.
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-sm text-white/70">
                  Not enough data to compute a scenario. Track more adjacent stages to see an
                  illustrative improvement.
                </p>
              )}
              <p className="mt-3 text-[11px] text-white/50 leading-relaxed">
                This is a conservative, illustrative scenario — not a forecast or performance
                guarantee. Inputs marked Estimate are approximations.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownload}
              className="w-full px-6 py-3.5 bg-ink hover:bg-night text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> Download My Snapshot
            </button>
            <p className="text-[11px] text-warm/70 text-center -mt-3">
              A readable .txt of your actual results, generated in your browser. No emailed PDF.
            </p>
          </Card>

          <Card className="p-6 lg:p-8 space-y-5">
            {completionStatus === "done" ? (
              <div className="text-center space-y-4">
                <div className="w-12 h-12 bg-phoenix/10 text-phoenix rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-ink">Snapshot Saved</h2>
                  <p className="text-sm text-warm mt-2 max-w-md mx-auto">
                    Your growth snapshot was submitted successfully, {firstName || "there"}.
                    We&rsquo;ll review your numbers and follow up by email.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleStartOver}
                    className="text-[12px] font-semibold text-warm hover:text-ink underline"
                  >
                    ← Start over
                  </button>
                  {scheduleLink}
                </div>
              </div>
            ) : (
              <>
                <div>
                  <h2 className="text-lg font-bold text-ink">Save Your Completed Snapshot</h2>
                  <p className="mt-1 text-[12px] text-warm leading-relaxed">
                    Submit your snapshot so we can review your numbers and follow up. Your contact
                    details from Step 1 are included; consent selections are not re-sent.
                  </p>
                </div>
                {completionStatus === "error" && completionResult && (
                  <div className="rounded-xl border border-phoenix/30 bg-phoenix/5 p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-phoenix shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-bold text-ink">Snapshot not yet saved</p>
                      <p className="text-[12px] text-warm mt-1 leading-relaxed">
                        {completionResult.message}
                      </p>
                      <p className="text-[12px] text-warm mt-1">
                        Your calculated results above are still visible and downloadable. Retry the
                        save when you&rsquo;re ready — booking and download remain available.
                      </p>
                    </div>
                  </div>
                )}
                <button
                  type="button"
                  onClick={handleShowSnapshot}
                  disabled={completionStatus === "submitting"}
                  className={FULL_BUTTON}
                >
                  {completionStatus === "submitting" ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Saving Snapshot…
                    </>
                  ) : completionStatus === "error" ? (
                    <>
                      <AlertCircle className="w-4 h-4" /> Retry Save
                    </>
                  ) : (
                    <>
                      Submit My Snapshot <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-black/10">
                  <button
                    type="button"
                    onClick={() => setStep("funnel")}
                    className="text-[12px] font-semibold text-warm hover:text-ink"
                  >
                    ← Back to funnel numbers
                  </button>
                  <Link
                    to="/schedule"
                    search={{ cta: "growth-snapshot-complete" }}
                    className="text-[12px] font-semibold text-phoenix hover:underline"
                  >
                    Skip to Schedule My Growth Call →
                  </Link>
                </div>
              </>
            )}
          </Card>
          <p className="text-[11px] text-warm/70 text-center leading-relaxed">
            Your progress is saved in this browser tab for 24 hours so an accidental reload resumes
            where you left off. This is same-browser progress, not cross-device retrieval.
          </p>
        </div>
      )}
    </div>
  );
}
